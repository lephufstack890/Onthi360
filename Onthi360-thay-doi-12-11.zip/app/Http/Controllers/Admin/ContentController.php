<?php

namespace App\Http\Controllers\Admin;

use App\Enums\UploadedDocumentStatus;
use App\Http\Controllers\Controller;
use App\Models\Assessment;
use App\Models\AssessmentCodingItem;
use App\Models\Material;
use App\Models\Question;
use App\Models\Tag;
use App\Services\Admin\ContentService;
use App\Services\Admin\DocumentImportService;
use App\Support\AnswerKeySheet;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\StreamedResponse;
use App\Support\ProvinceCatalog;
use App\Support\QuestionDifficulty;
use App\Support\UploadLimit;

class ContentController extends Controller
{
    public function __construct(
        private ContentService $contentService,
        private DocumentImportService $documentImportService,
    ) {}

    public function index(Request $request): View
    {
        $tab = $request->query('tab', 'questions');

        if ($tab === 'materials') {
            return redirect()->route('admin.content.index', ['tab' => 'questions']);
        }

        $filters = [
            'subject' => $request->query('subject') ?: null,
            'grade' => $request->query('grade') ?: null,
            // SỬA 1/10 (khách: "chỗ lọc danh sách trong admin cũng cho lọc theo tỉnh thành và
            // năm luôn nha") — xem QuestionRepository::applyQuestionBankFilters(); 'none' =
            // chưa gán.
            'province' => $request->query('province') ?: null,
            'exam_year' => $request->query('exam_year') ?: null,
            'type' => $request->query('type') ?: null,
            // SỬA 28/10 — lọc câu Lập trình theo cách vào/ra: 'file' (đọc từ tệp) | 'std' (bàn phím / màn hình).
            'io' => in_array($request->query('io'), ['file', 'std'], true) ? $request->query('io') : null,
            'status' => $request->query('status') ?: null,
            // SỬA 18/9 (khách: "admin thêm lọc theo độ khó nữa nha") — xem
            // QuestionRepository::applyDifficultyFilter(); 'none' = chưa ai đặt độ khó.
            'difficulty' => $request->query('difficulty') ?: null,
            // SỬA 30/9 (khách: "nên thêm phần lọc theo chuyên đề vào") — id tag, hoặc 'none'.
            'tag' => $request->query('tag') ?: null,
            // SỬA 4/10 (khách: "thêm phần lọc câu hỏi: câu hỏi xuất hiện trong đề, và câu hỏi
            // không xuất hiện trong đề") — 'used' / 'unused', xem applyQuestionBankFilters().
            // SỬA 7/10 (khách: tách tab "đã dùng / chưa dùng trong đề") — đây giờ là HAI TAB, không
            // còn là ô lọc. Không có hoặc giá trị lạ -> tab "Bài chung" (tab đầu tiên, SỬA 9/10).
            'in_exam' => in_array($request->query('in_exam'), ['used', 'unused'], true) ? $request->query('in_exam') : 'unused',
            'q' => $request->query('q') ?: null,
        ];

        // SỬA 7/10 (khách: "quá 10 item thì phân trang") — số trang lấy từ ?page=, mặc định 1;
        // service tự chặn khi vượt quá trang cuối.
        $page = max(1, (int) $request->query('page', 1));

        $data = $this->contentService->indexData($tab, $filters, $page);

        // SỬA 27/10 — tab "Bài của tài liệu" (sách / chuyên đề / bộ đề), bộ lọc riêng: loai, tai_lieu, phan, dang, trang_thai, q.
        if ($tab === 'material_exercises') {
            $svc = app(\App\Services\Admin\MaterialExerciseIndexService::class);
            // Lỗi dựng danh sách thì vẫn mở trang (kèm thông báo), chi tiết lỗi ghi vào storage/logs/laravel.log.
            $data += rescue(
                fn () => $svc->indexData($request->query(), $page),
                fn () => $svc->emptyData('Chưa tải được danh sách bài của tài liệu — lỗi đã ghi vào nhật ký hệ thống (storage/logs/laravel.log).'),
            );
        }

        return view('admin.content.index', $data);
    }

    /** admin.content.show — 6.2 (chặn phát hành khi thiếu cấu hình). */
    public function show(Request $request, int $content): View
    {
        // SỬA 23/9 — 'kind' nói rõ đang xem Học liệu / Câu hỏi / Đề, vì 3 bảng đánh id riêng
        // nên chỉ có id là đoán sai loại (xem ContentService::showData()).
        return view('admin.content.show', $this->contentService->showData($content, $request->query('kind')));
    }

    // ================= Học liệu (Material) =================

    /** SỬA 26/8 ("gộp Học liệu vào Sản phẩm & quyền") — ?product_id= khi vào từ nút "+ Thêm học liệu" ở trang chi tiết 1 sản phẩm, để form tự điền sẵn (xem ContentService::materialCreateFormData()). */
    public function materialsCreate(Request $request): View
    {
        $productId = $request->integer('product_id') ?: null;

        return view('admin.content.materials.create', $this->contentService->materialCreateFormData($productId));
    }

    public function materialsStore(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'product_id' => ['required', 'integer', 'exists:products,id'],
            'parent_id' => ['nullable', 'integer', 'exists:materials,id'],
            'type' => ['required', 'string', 'in:chapter,section,assessment_ref'],
            'title' => ['required', 'string', 'max:255'],
            'order' => ['nullable', 'integer', 'min:0'],
            'assessment_id' => ['nullable', 'integer', 'exists:assessments,id'],
            'status' => ['required', 'string', 'in:draft,pending_review,published,archived'],
            // SỬA 25/8 (tải bài — cả 2 đều TÙY CHỌN, không phá form tạo mục lục cũ không cần
            // mã/PDF): mã trùng trong CÙNG sản phẩm được ContentService::materialStore() ném
            // ValidationException riêng (không kiểm tra được bằng rule 'unique' đơn giản vì
            // phạm vi trùng lặp lồng theo product_id, xem assertMaterialCodeAvailable()).
            'code' => ['nullable', 'string', 'max:60'],
            'pdf' => ['nullable', 'file', 'mimes:pdf', 'max:'.ContentService::maxPdfKb()],
            // SỬA 4/9 (khách yêu cầu: "file học liệu có thể là audio, pdf, ảnh động... đính
            // nhiều loại cùng lúc") — cả 2 đều TÙY CHỌN, độc lập với pdf ở trên.
            'audio' => ['nullable', 'file', 'mimes:mp3,wav,ogg,m4a,aac', 'max:'.ContentService::maxMaterialAudioKb()],
            'image' => ['nullable', 'file', 'mimes:jpg,jpeg,png,gif,webp', 'max:'.ContentService::maxMaterialImageKb()],
        ], [], ['code' => 'Mã bài', 'pdf' => 'Tệp PDF bài học', 'audio' => 'Tệp audio', 'image' => 'Tệp ảnh']);

        try {
            $material = $this->contentService->materialStore($data);
        } catch (ValidationException $e) {
            return back()->withErrors($e->errors())->withInput();
        }

        // SỬA 4/9 — quay về đúng trang tài liệu vừa thêm học liệu (đồng bộ với
        // materialsUpdate()/materialsDestroy() bên dưới) thay vì trang "content.show" chung.
        return redirect()->route('admin.products.show', $material->product_id)->with('status', 'material-created');
    }

    public function materialsEdit(int $material): View
    {
        return view('admin.content.materials.edit', $this->contentService->materialEditFormData($material));
    }

    public function materialsUpdate(Request $request, Material $material): RedirectResponse
    {
        $data = $request->validate([
            'product_id' => ['required', 'integer', 'exists:products,id'],
            'parent_id' => ['nullable', 'integer', 'exists:materials,id'],
            'type' => ['required', 'string', 'in:chapter,section,assessment_ref'],
            'title' => ['required', 'string', 'max:255'],
            'order' => ['nullable', 'integer', 'min:0'],
            'assessment_id' => ['nullable', 'integer', 'exists:assessments,id'],
            'status' => ['required', 'string', 'in:draft,pending_review,published,archived'],
            // SỬA 25/8 (tải bài — "cần có cơ chế sửa sau khi nhập"): để trống 'pdf' thì GIỮ
            // NGUYÊN file cũ (materialUpdate() chỉ đụng vào pdf_path khi có tải file mới).
            'code' => ['nullable', 'string', 'max:60'],
            'pdf' => ['nullable', 'file', 'mimes:pdf', 'max:'.ContentService::maxPdfKb()],
            // SỬA 4/9 — xem materialsStore() ở trên.
            'audio' => ['nullable', 'file', 'mimes:mp3,wav,ogg,m4a,aac', 'max:'.ContentService::maxMaterialAudioKb()],
            'image' => ['nullable', 'file', 'mimes:jpg,jpeg,png,gif,webp', 'max:'.ContentService::maxMaterialImageKb()],
        ], [], ['code' => 'Mã bài', 'pdf' => 'Tệp PDF bài học', 'audio' => 'Tệp audio', 'image' => 'Tệp ảnh']);

        try {
            $updated = $this->contentService->materialUpdate($material, $data);
        } catch (ValidationException $e) {
            return back()->withErrors($e->errors())->withInput();
        }

        // SỬA 26/8: sau khi lưu, quay về trang chi tiết sản phẩm của học liệu đó (giống
        // materialsDestroy()/materialsBulkImportStore()) thay vì trang "content.show" chung —
        // dùng product_id của bản ghi ĐÃ CẬP NHẬT vì admin có thể đổi "Thuộc sản phẩm" ngay
        // trong form sửa này.
        return redirect()->route('admin.products.show', $updated->product_id)->with('status', 'material-updated');
    }

    public function materialsPublish(Material $material): RedirectResponse
    {
        $this->contentService->materialPublish($material);

        return redirect()->route('admin.content.show', ['content' => $material->id, 'kind' => 'material'])->with('status', 'material-published');
    }

    public function materialsReject(Request $request, Material $material): RedirectResponse
    {
        $data = $request->validate(['reason' => ['required', 'string', 'max:1000']]);
        $this->contentService->materialReject($material, $data['reason']);

        return redirect()->route('admin.content.show', ['content' => $material->id, 'kind' => 'material'])->with('status', 'material-rejected');
    }

    public function materialsArchive(Request $request, Material $material): RedirectResponse
    {
        $data = $request->validate(['reason' => ['required', 'string', 'max:1000']]);
        $this->contentService->materialArchive($material, $data['reason']);

        return redirect()->route('admin.content.show', ['content' => $material->id, 'kind' => 'material'])->with('status', 'material-archived');
    }

    public function materialsDestroy(Material $material): RedirectResponse
    {
       
        $productId = $material->product_id;

        $this->contentService->materialDelete($material);

        return redirect()->route('admin.products.show', $productId)->with('status', 'material-deleted');
    }

    /**
     * SỬA 4/10 (khách: "phần danh sách bài không thấy nút xoá… khi xoá item nào là tất cả các
     * file liên quan lưu trong thư mục phải xoá hết") — xoá câu hỏi + toàn bộ tệp của nó.
     *
     * Service tự từ chối khi câu hỏi đã có người làm hoặc đang nằm trong đề; ở đây chỉ chuyển
     * câu trả lời của nó thành thông báo trên màn hình.
     */
    public function questionsDestroy(Question $question): RedirectResponse
    {
        [$ok, $message] = $this->contentService->questionDestroy($question);

        return $ok
            ? back()->with('status', 'question-deleted')->with('statusMessage', $message)
            : back()->withErrors(['delete' => $message]);
    }

    /**
     * SỬA 7/10 — đổi nhanh "Thứ tự hiển thị" ngay trên danh sách (gọi bằng fetch, trả JSON).
     *   mode=set    + value (0..65535)  : đặt đúng số đó.
     *   mode=before + before_id         : đưa câu này lên NGAY TRƯỚC câu before_id (câu liền trên).
     *   mode=after  + after_id          : đưa câu này xuống NGAY SAU câu after_id (câu liền dưới).
     * visible_ids = các câu đang hiện trên trang, để trả lại số mới của chúng cho ô số.
     */
    public function questionsDisplayOrder(Request $request, Question $question): JsonResponse
    {
        $data = $request->validate([
            'mode' => ['required', 'in:set,before,after'],
            'value' => ['required_if:mode,set', 'nullable', 'integer', 'min:0', 'max:65535'],
            'before_id' => ['required_if:mode,before', 'nullable', 'integer', 'exists:questions,id'],
            'after_id' => ['required_if:mode,after', 'nullable', 'integer', 'exists:questions,id'],
            'visible_ids' => ['nullable', 'array', 'max:200'],
            'visible_ids.*' => ['integer'],
        ], [], ['value' => 'Thứ tự hiển thị']);

        // SỬA 10/10 — mode=after + after_id: đưa câu này xuống NGAY SAU câu after_id (câu liền dưới) = đưa câu liền dưới lên trước câu này.
        $result = match ($data['mode']) {
            'before' => $this->contentService->questionMoveBefore($question, Question::query()->findOrFail((int) $data['before_id'])),
            'after' => $this->contentService->questionMoveBefore(Question::query()->findOrFail((int) $data['after_id']), $question),
            default => $this->contentService->questionSetDisplayOrder($question, (int) $data['value']),
        };

        if (! $result['ok']) {
            return response()->json(['ok' => false, 'message' => $result['message'] ?? 'Không đổi được thứ tự.'], 422);
        }

        $ids = array_values(array_unique(array_merge([$question->id], array_map('intval', $data['visible_ids'] ?? []))));

        return response()->json(['ok' => true] + $this->contentService->displayOrderSnapshot($ids));
    }

    /** SỬA 4/10 — xoá đề thi + 4 tệp của nó (đề, lời giải, bản xem trước, ảnh bìa). */
    public function assessmentsDestroy(Assessment $assessment): RedirectResponse
    {
        // SỬA 3/11 (khách: "xoá đề là xoá luôn câu hỏi trong đề và mọi file") — xem ContentService::assessmentDestroyWithContent().
        [$ok, $message] = $this->contentService->assessmentDestroyWithContent($assessment);

        return $ok
            ? back()->with('status', 'assessment-deleted')->with('statusMessage', $message)
            : back()->withErrors(['delete' => $message]);
    }

    public function materialsBulkImportCreate(Request $request): View
    {
        $productId = $request->integer('product_id') ?: null;

        return view('admin.content.materials.bulk', $this->contentService->materialsBulkImportFormData($productId));
    }

    public function materialsBulkImportStore(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'product_id' => ['required', 'integer', 'exists:products,id'],
            'parent_id' => ['nullable', 'integer', 'exists:materials,id'],
            'type' => ['required', 'string', 'in:chapter,section'],
            'status' => ['required', 'string', 'in:draft,pending_review,published,archived'],
            'zip_package' => ['required', 'file', 'mimes:zip', 'max:'.ContentService::maxBulkMaterialZipKb()],
        ], [], ['zip_package' => 'Gói ZIP']);

        try {
            $created = $this->contentService->materialsBulkImportFromZip(
                (int) $data['product_id'],
                $data['type'],
                $data['parent_id'] ? (int) $data['parent_id'] : null,
                $data['status'],
                $request->file('zip_package'),
            );
        } catch (ValidationException $e) {
            return back()->withErrors($e->errors())->withInput();
        }

        // SỬA 26/8 ("gộp Học liệu vào Sản phẩm & quyền"): quay về đúng trang sản phẩm thay vì
        // tab "Học liệu" đã bỏ.
        return redirect()->route('admin.products.show', (int) $data['product_id'])
            ->with('status', 'materials-bulk-imported')
            ->with('bulkCreatedCount', $created->count());
    }

    // ================= Câu hỏi kho chung (Question) =================

    public function questionsCreate(): View
    {
        return view('admin.content.questions.create', $this->contentService->questionCreateFormData());
    }

    private function questionGradingRules(): array
    {
        return [
            'options' => ['nullable', 'array'],
            'options.*' => ['nullable', 'string', 'max:255'],
            'correct_option' => ['nullable', 'integer', 'min:0', 'max:3'],
            'accepted_answers' => ['nullable', 'string', 'max:2000'],
            'case_sensitive' => ['nullable', 'boolean'],
            'test_cases_raw' => ['nullable', 'string', 'max:10000'],
            // SỬA 9/10 — bộ test dựng từ cặp tệp .in/.out ở khối "Bộ test" (JSON [{input, output}]).
            // Xem testCasesFromJson() bên dưới: đổi sang 'test_cases_parsed' — cùng đường nhập ZIP.
            'test_cases_json' => ['nullable', 'string', 'max:8000000'],
            'time_limit_ms' => ['nullable', 'integer', 'min:1'],
            'memory_limit_mb' => ['nullable', 'integer', 'min:1'],
            'checker_mode' => ['nullable', 'string', 'in:default,tokens,float,ignore_case,unordered'], // SỬA 21/10 — Cách chấm
            'checker_epsilon' => ['nullable', 'numeric', 'gt:0', 'max:1'],
        ];
    }

    /**
     * SỬA 9/10 (khách: "chỉ thêm chỗ nhập bộ test… đừng ảnh hưởng gì đến máy chấm") — đổi ô ẩn
     * `test_cases_json` của khối "Bộ test" thành 'test_cases_parsed' = [{input, output}, …].
     *
     * Vì sao KHÔNG cần sửa gì ở máy chấm: 'test_cases_parsed' chính là khoá mà nhập gói ZIP đã
     * dùng từ lâu (ContentService::buildGradingConfig() ưu tiên nó trước ô "Test cases" cũ), nên
     * grading_config.test_cases ra đúng cấu trúc cũ {input, output} và giữ NGUYÊN xuống dòng —
     * CodeJudgingService / PracticeByQuestionService đọc y như trước.
     *
     * Không gửi ô này (form Sửa khi không đổi bộ test) -> trả nguyên $data, server giữ test cũ.
     * Gửi sai định dạng -> báo lỗi, KHÔNG lưu gì (không âm thầm bỏ test).
     *
     * @throws ValidationException
     */
    private function testCasesFromJson(array $data): array
    {
        $json = $data['test_cases_json'] ?? null;
        unset($data['test_cases_json']);

        if ($json === null || $json === '') {
            return $data;
        }

        $fail = fn (string $message) => ValidationException::withMessages(['test_cases_json' => $message]);

        $decoded = json_decode((string) $json, true);
        if (! is_array($decoded) || ! array_is_list($decoded)) {
            throw $fail('Bộ test gửi lên không đọc được — chưa lưu gì. Hãy nhập lại cặp tệp .in/.out rồi lưu lại.');
        }
        if (count($decoded) > 500) {
            throw $fail('Bộ test có quá 500 test — chưa lưu gì. Hãy chia nhỏ bài hoặc giảm số test.');
        }

        $cases = [];
        foreach ($decoded as $index => $case) {
            if (! is_array($case) || ! is_string($case['input'] ?? null) || ! is_string($case['output'] ?? null)) {
                throw $fail('Test thứ '.($index + 1).' không đúng định dạng (cần có dữ liệu vào và kết quả) — chưa lưu gì.');
            }
            $cases[] = ['input' => $case['input'], 'output' => $case['output']];
        }

        $data['test_cases_parsed'] = $cases;

        return $data;
    }

    /**
     * SỬA 1/10 (khách: "chỗ nhập thủ công đang thiếu vài trường… thiếu chọn file pdf") — luật
     * kiểm tra cho các ô MỚI ở form Tạo/Sửa câu hỏi, trước đây chỉ gói ZIP mới điền được:
     *
     *   - statement_file / solution_file / reference_file: 3 tệp đính kèm cố định. 'statement'
     *     là tệp QUAN TRỌNG NHẤT — nó nuôi tab "Đề bài PDF" của học sinh lúc làm bài (xem
     *     Question::attachmentInfo() + Student\AssessmentService), thiếu nó thì học sinh chỉ
     *     thấy phần đề gõ tay.
     *   - remove_attachments[] / remove_assets[]: ô bỏ chọn tệp đang có ở form Sửa.
     *   - asset_files[]: ảnh/âm thanh cần để trả lời (Question::findAsset()).
     *   - file_io_input / file_io_output: quy ước tên tệp vào/ra của câu Lập trình. Khớp ĐÚNG
     *     regex mà CodeJudgingService::withFileIo() dùng để lọc tên tệp — sai regex ở đây thì
     *     tên lưu được nhưng máy chấm lặng lẽ bỏ qua.
     *
     * 3 action Tạo / Sửa / Tạo phiên bản mới dùng chung bộ luật này để không chỗ nào thiếu.
     */
    private function questionUploadRules(): array
    {
        return [
            'statement_file' => ['nullable', 'file', 'mimes:pdf', 'max:20480'],
            'solution_file' => ['nullable', 'file', 'mimes:pdf', 'max:20480'],
            'reference_file' => ['nullable', 'file', 'max:2048', 'extensions:cpp,cc,c,py,pas,java,js,ts,txt,md'],
            'remove_attachments' => ['nullable', 'array'],
            'remove_attachments.*' => ['string', 'in:statement,solution,reference'],
            'asset_files' => ['nullable', 'array', 'max:20'],
            'asset_files.*' => ['file', 'max:20480', 'mimetypes:image/jpeg,image/png,image/gif,image/webp,audio/mpeg,audio/mp4,audio/aac,audio/ogg,audio/wav,audio/x-wav,audio/webm'],
            'remove_assets' => ['nullable', 'array'],
            'remove_assets.*' => ['string', 'max:64'],
            // SỬA 10/10 — chế độ đọc/ghi người dùng CHỌN ở form: 'std' = bàn phím/màn hình, 'file' = tệp có tên.
            'io_mode' => ['nullable', 'in:std,file'],
            'file_io_input' => ['nullable', 'string', 'max:64', 'regex:/^[A-Za-z0-9._-]+$/'],
            'file_io_output' => ['nullable', 'string', 'max:64', 'regex:/^[A-Za-z0-9._-]+$/'],
        ];
    }

    /** SỬA 19/8 (Giai đoạn 6) — tag có sẵn (tick chọn) + tag mới gõ tay, xem ContentService::resolveTagIds(). */
    private function tagRules(): array
    {
        return [
            'tag_ids' => ['nullable', 'array'],
            'tag_ids.*' => ['integer', 'exists:tags,id'],
            'new_tags' => ['nullable', 'string', 'max:500'],
        ];
    }

    public function questionsStore(Request $request): RedirectResponse
    {
        $data = $request->validate(array_merge([
            'code' => ['required', 'string', 'max:40'],
            'type' => ['required', 'string', 'in:coding,mcq,fill_blank'],
            // SỬA 18/9 — ô "Độ khó" mới ở form câu hỏi. Rỗng = chưa đặt (hệ thống tự suy
            // theo điểm), 4 khoá còn lại khớp đúng bộ lọc ngoài trang Luyện tập.
            'difficulty' => ['nullable', 'string', QuestionDifficulty::validationRule()],
            'title' => ['required', 'string', 'max:255'],
            'subject' => ['nullable', 'string', 'max:20'],
            // SỬA 3/10 (khách: "chỗ chọn khối lớp thì cho chọn nhiều nha") — ô khối lớp giờ là
            // các ô tick, gửi lên mảng 'grades'. Vẫn nhận 'grade' (1 số) cho các chỗ gọi cũ
            // (nhập ZIP, tự phân loại) — xem SubjectCatalog::normalizeGrades().
            'grades' => ['nullable', 'array', 'max:12'],
            'grades.*' => ['integer', 'min:6', 'max:12'],
            'grade' => ['nullable', 'integer', 'min:6', 'max:12'],
            // SỬA 1/10 — Tỉnh thành (MÃ trong App\Support\ProvinceCatalog) + Năm của đề. Cố ý
            // KHÔNG dùng 'in:...' danh sách mã: ContentService chuẩn hoá lại qua
            // ProvinceCatalog::normalize()/normalizeYear(), mã lạ thành null = "Chưa gán" thay vì
            // chặn cả form chỉ vì 1 ô phân loại tuỳ chọn.
            'province' => ['nullable', 'string', 'max:20'],
            'exam_year' => ['nullable', 'integer', 'min:'.ProvinceCatalog::MIN_YEAR, 'max:'.((int) date('Y') + 1)],
            'source_name' => ['nullable', 'string', 'max:255'],
            'body' => ['nullable', 'string'],
            'points' => ['nullable', 'integer', 'min:0'],
            // SỬA 30/9 — "thứ tự ưu tiên hiển thị": số càng lớn càng hiện trước, 0 = bình thường.
            'display_order' => ['nullable', 'integer', 'min:0', 'max:65535'],
            'visibility' => ['required', 'string', 'in:public,private'],
        ], $this->questionGradingRules(), $this->questionUploadRules(), $this->tagRules()));

        $data = $this->testCasesFromJson($data);

        $question = $this->contentService->questionStore(Auth::user(), $data);

        // SỬA 3/11 (khách: "tạo câu hỏi là tạo và phát hành luôn") — tạo xong phát hành ngay, vẫn qua QuestionPublishGuard như nút
        // Phát hành. Chưa đủ điều kiện (vd bài lập trình chưa có bộ test) thì câu vẫn được tạo (Nháp) và báo rõ lý do.
        $result = $this->contentService->questionPublish($question->refresh());

        return redirect()->route('admin.content.show', ['content' => $question->id, 'kind' => 'question'])
            ->with('status', $result['ok'] ? 'question-saved-published' : 'question-saved-not-published')
            ->with('statusMessage', $result['ok']
                ? 'Đã tạo và phát hành câu hỏi '.$question->code.'.'
                : 'Đã tạo câu hỏi '.$question->code.' (Nháp) nhưng CHƯA phát hành được: '.($result['message'] ?? 'chưa đủ điều kiện.'));
    }

    public function questionsEdit(Request $request, int $question): View
    {
        // SỬA 16/10 (khách: "nút Quay lại là quay lại trang trước đó người dùng đứng") — nhớ ĐÚNG trang đã bấm "Sửa"
        // (danh sách Kho, trang chi tiết đề, màn Chọn câu hỏi…), không chỉ trang danh sách như trước.
        return view('admin.content.questions.edit',
            $this->contentService->questionEditFormData($question)
            + ['returnTo' => $this->rememberAdminBackUrl($request, route('admin.content.index', ['tab' => 'questions']))]);
    }

    public function questionsUpdate(Request $request, Question $question): RedirectResponse
    {
        $data = $request->validate(array_merge([
            'code' => ['required', 'string', 'max:40'],
            // SỬA 18/9 — Độ khó sửa được ở màn Sửa, không chỉ lúc tạo.
            'difficulty' => ['nullable', 'string', QuestionDifficulty::validationRule()],
            'title' => ['required', 'string', 'max:255'],
            'subject' => ['nullable', 'string', 'max:20'],
            // SỬA 3/10 (khách: "chỗ chọn khối lớp thì cho chọn nhiều nha") — ô khối lớp giờ là
            // các ô tick, gửi lên mảng 'grades'. Vẫn nhận 'grade' (1 số) cho các chỗ gọi cũ
            // (nhập ZIP, tự phân loại) — xem SubjectCatalog::normalizeGrades().
            'grades' => ['nullable', 'array', 'max:12'],
            'grades.*' => ['integer', 'min:6', 'max:12'],
            'grade' => ['nullable', 'integer', 'min:6', 'max:12'],
            // SỬA 1/10 — Tỉnh thành (MÃ trong App\Support\ProvinceCatalog) + Năm của đề. Cố ý
            // KHÔNG dùng 'in:...' danh sách mã: ContentService chuẩn hoá lại qua
            // ProvinceCatalog::normalize()/normalizeYear(), mã lạ thành null = "Chưa gán" thay vì
            // chặn cả form chỉ vì 1 ô phân loại tuỳ chọn.
            'province' => ['nullable', 'string', 'max:20'],
            'exam_year' => ['nullable', 'integer', 'min:'.ProvinceCatalog::MIN_YEAR, 'max:'.((int) date('Y') + 1)],
            'source_name' => ['nullable', 'string', 'max:255'],
            'body' => ['nullable', 'string'],
            'points' => ['nullable', 'integer', 'min:0'],
            // SỬA 30/9 — "thứ tự ưu tiên hiển thị": số càng lớn càng hiện trước, 0 = bình thường.
            'display_order' => ['nullable', 'integer', 'min:0', 'max:65535'],
            'visibility' => ['required', 'string', 'in:public,private'],
        ], $this->questionGradingRules(), $this->questionUploadRules(), $this->tagRules()));

        $data = $this->testCasesFromJson($data);

        $this->contentService->questionUpdate($question, $data);

        // SỬA 16/10 (khách: "nhập file ZIP mà bấm Lưu thay đổi là nó tự phát hành luôn") — câu vừa nhập từ gói ZIP (màn Sửa
        // gửi kèm publish_after_save=1, xem questions/edit.blade.php) và đang Nháp: lưu xong phát hành luôn, vẫn qua
        // QuestionPublishGuard như nút Phát hành. Chưa đủ điều kiện thì vẫn lưu, báo lý do để admin bổ sung.
        $status = 'question-updated';
        $statusMessage = 'Đã lưu câu hỏi '.$question->code.'.';
        $question->refresh();
        // SỬA 3/11 (khách: "chỉnh sửa cũng lưu cái là phát hành luôn") — mọi câu chưa phát hành (Nháp / Chờ duyệt) lưu xong là phát
        // hành luôn (trước đây chỉ câu vừa nhập ZIP). Câu đã Lưu trữ thì giữ nguyên, không tự mở lại.
        if (in_array($question->status, [\App\Enums\ContentStatus::Draft, \App\Enums\ContentStatus::PendingReview], true)) {
            $result = $this->contentService->questionPublish($question);
            $status = $result['ok'] ? 'question-saved-published' : 'question-saved-not-published';
            $statusMessage = $result['ok']
                ? 'Đã lưu và phát hành câu hỏi '.$question->code.'.'
                : 'Đã lưu câu hỏi '.$question->code.' nhưng CHƯA phát hành được: '.($result['message'] ?? 'chưa đủ điều kiện.');
        }

        // SỬA 4/10 — về thẳng danh sách (giữ nguyên tab + bộ lọc) thay vì màn chi tiết.
        // SỬA 16/10 — về đúng trang đã bấm "Sửa" (vd trang chi tiết đề Luyện tập), kiểm tra an toàn ở safeAdminBackUrl().
        return redirect()->to($this->safeAdminBackUrl((string) $request->input('return_to', ''), route('admin.content.index', ['tab' => 'questions'])))
            ->with('status', $status)->with('statusMessage', $statusMessage);
    }

    /** admin.content.questions.newVersion — 6.2: câu đã có người làm phải tạo version mới. */
    public function questionsNewVersion(Request $request, Question $question): RedirectResponse
    {
        $data = $request->validate(array_merge([
            'title' => ['required', 'string', 'max:255'],
            'subject' => ['nullable', 'string', 'max:20'],
            // SỬA 3/10 (khách: "chỗ chọn khối lớp thì cho chọn nhiều nha") — ô khối lớp giờ là
            // các ô tick, gửi lên mảng 'grades'. Vẫn nhận 'grade' (1 số) cho các chỗ gọi cũ
            // (nhập ZIP, tự phân loại) — xem SubjectCatalog::normalizeGrades().
            'grades' => ['nullable', 'array', 'max:12'],
            'grades.*' => ['integer', 'min:6', 'max:12'],
            'grade' => ['nullable', 'integer', 'min:6', 'max:12'],
            // SỬA 1/10 — Tỉnh thành (MÃ trong App\Support\ProvinceCatalog) + Năm của đề. Cố ý
            // KHÔNG dùng 'in:...' danh sách mã: ContentService chuẩn hoá lại qua
            // ProvinceCatalog::normalize()/normalizeYear(), mã lạ thành null = "Chưa gán" thay vì
            // chặn cả form chỉ vì 1 ô phân loại tuỳ chọn.
            'province' => ['nullable', 'string', 'max:20'],
            'exam_year' => ['nullable', 'integer', 'min:'.ProvinceCatalog::MIN_YEAR, 'max:'.((int) date('Y') + 1)],
            'source_name' => ['nullable', 'string', 'max:255'],
            'body' => ['nullable', 'string'],
            'points' => ['nullable', 'integer', 'min:0'],
            // SỬA 30/9 — "thứ tự ưu tiên hiển thị": số càng lớn càng hiện trước, 0 = bình thường.
            'display_order' => ['nullable', 'integer', 'min:0', 'max:65535'],
            'visibility' => ['required', 'string', 'in:public,private'],
            // SỬA 18/9 — PHẢI có ở đây nữa: form "Tạo phiên bản mới" dùng CHUNG màn Sửa (có ô
            // Độ khó). Thiếu luật này thì giá trị gửi lên bị validate() loại bỏ, và
            // questionCreateNewVersion() hiểu là "bỏ trống" -> XOÁ mất độ khó của bản mới.
            'difficulty' => ['nullable', 'string', QuestionDifficulty::validationRule()],
        ], $this->questionGradingRules(), $this->questionUploadRules(), $this->tagRules()));

        $data = $this->testCasesFromJson($data);

        $newQuestion = $this->contentService->questionCreateNewVersion($question, $data);

        // SỬA 3/11 (khách: "chỉnh sửa lưu cái là phát hành luôn") — phiên bản mới cũng phát hành luôn (câu gốc giữ nguyên như cũ).
        $result = $this->contentService->questionPublish($newQuestion->refresh());

        return redirect()->route('admin.content.show', ['content' => $newQuestion->id, 'kind' => 'question'])
            ->with('status', $result['ok'] ? 'question-saved-published' : 'question-saved-not-published')
            ->with('statusMessage', $result['ok']
                ? 'Đã tạo và phát hành phiên bản mới của câu hỏi '.$newQuestion->code.' (câu gốc giữ nguyên).'
                : 'Đã tạo phiên bản mới (Nháp) nhưng CHƯA phát hành được: '.($result['message'] ?? 'chưa đủ điều kiện.'));
    }

    public function questionsPublish(Question $question): RedirectResponse
    {
        \App\Services\GeneralSetBankService::fixQuestionZeroPoints($question); // SỬA 3/11 — chỉ tác dụng với câu con "Bài phổ thông"
        \App\Support\ExamItemPoints::fixForQuestion($question); // SỬA 3/11 — câu của đề có điểm lẻ < 1 (vd 0,25) bị làm tròn 0
        $result = $this->contentService->questionPublish($question);

        if (! $result['ok']) {
            return redirect()->route('admin.content.show', ['content' => $question->id, 'kind' => 'question'])->withErrors(['publish' => $result['message']]);
        }

        return redirect()->route('admin.content.show', ['content' => $question->id, 'kind' => 'question'])->with('status', 'question-published');
    }

    public function questionsReject(Request $request, Question $question): RedirectResponse
    {
        $data = $request->validate(['reason' => ['required', 'string', 'max:1000']]);
        $this->contentService->questionReject($question, $data['reason']);

        return redirect()->route('admin.content.show', ['content' => $question->id, 'kind' => 'question'])->with('status', 'question-rejected');
    }

    public function questionsArchive(Request $request, Question $question): RedirectResponse
    {
        $data = $request->validate(['reason' => ['required', 'string', 'max:1000']]);
        $this->contentService->questionArchive($question, $data['reason']);

        return redirect()->route('admin.content.show', ['content' => $question->id, 'kind' => 'question'])->with('status', 'question-archived');
    }

    // ================= Câu hỏi lập trình — "Nhập từ gói ZIP" (24/8) =================
    // Xem App\Services\Admin\ContentService::questionStoreFromZipPackage() — tái sử dụng
    // questionStore() nguyên vẹn nên KHÔNG đụng gì tới questionsCreate/questionsStore ở trên.

    /** admin.content.questions.zipImport — tải 1 gói ZIP OT360-QPACK, tự điền, redirect sang Sửa. */
    public function questionsZipImportStore(Request $request): RedirectResponse
    {
        $request->validate([
            'zip_package' => ['required', 'file', 'mimes:zip', 'max:'.ContentService::maxQuestionZipKb()],
        ], [], ['zip_package' => 'Gói ZIP']);

        try {
            $question = $this->contentService->questionStoreFromZipPackage(Auth::user(), $request->file('zip_package'));
        } catch (ValidationException $e) {
            return redirect()->route('admin.content.questions.create')->withErrors($e->errors());
        }

        return redirect()->route('admin.content.questions.edit', $question->id)->with('status', 'question-zip-imported');
    }

    /** admin.content.questions.attachment — tải lại 1 tệp đính kèm (đề/lời giải/code mẫu) đã nhập từ ZIP. */
    public function questionsAttachmentDownload(Request $request, Question $question, string $kind): StreamedResponse
    {
        $info = $this->contentService->questionAttachmentInfo($question, $kind);

        return Storage::disk('local')->download($info['path'], $info['filename']);
    }

    // ================= Nhập đề Word/PDF/OCR -> Kho chung (6.4) =================

    /** admin.content.questions.import (ADM-03, TEA-05 tương đương phía admin) — trạng thái xử lý OCR thật. */
    public function questionsImport(Request $request): View
    {
        return view('admin.content.questions.import', [
            'documents' => $this->contentService->indexData('drafts')['documents'],
            'maxFileKb' => DocumentImportService::maxFileKb(),
        ]);
    }

    /**
     * admin.content.questions.import.store — tải Word/PDF lên và xử lý ngay (6.4): quét
     * chữ ký định dạng, trích xuất văn bản (OCR nếu là PDF scan/ảnh), phân rã thành câu
     * nháp vào "Kho chung". Có thể mất vài chục giây với tệp scan nhiều trang.
     */
    public function questionsImportStore(Request $request): RedirectResponse
    {
        $request->validate([
            'file' => ['required', 'file', 'mimes:docx,pdf', 'max:'.DocumentImportService::maxFileKb()],
        ], [], ['file' => 'Tệp']);

        set_time_limit(300);

        $document = $this->documentImportService->import(Auth::user(), $request->file('file'));

        if ($document->status === UploadedDocumentStatus::Failed) {
            return redirect()->route('admin.content.questions.import')
                ->with('status', 'import-failed')
                ->with('importError', $document->error_log);
        }

        return redirect()->route('admin.content.questions.reviewDraft', ['document' => $document->id])
            ->with('status', 'import-parsed');
    }

    /** admin.content.documents.download — tải lại đúng tệp gốc đã upload để đối chiếu. */
    public function downloadDocument(Request $request, int $document): StreamedResponse
    {
        $documentModel = $this->documentImportService->findDocument($document);

        return Storage::disk('local')->download($documentModel->storage_path, $documentModel->original_filename);
    }

    /**
     * admin.content.questions.reviewDraft — truyền $document + $drafts thật (6.4). Nhận
     * ?document=<id>; nếu không có, lấy tài liệu "cần rà soát" gần nhất trên toàn Kho chung.
     */
    public function questionsReviewDraft(Request $request): View
    {
        $documentId = $request->filled('document') ? (int) $request->query('document') : null;

        return view('admin.content.questions.review-draft', $this->contentService->reviewDraftFor($documentId));
    }

    /** admin.content.drafts.store — "+ Thêm câu thủ công" ở màn rà soát (6.4). */
    public function draftStore(Request $request, int $document): RedirectResponse
    {
        $documentModel = $this->documentImportService->findDocument($document);
        $this->documentImportService->addManualDraft($documentModel);

        return redirect()->route('admin.content.questions.reviewDraft', ['document' => $documentModel->id])
            ->with('status', 'draft-added');
    }

    /**
     * admin.content.drafts.update — sửa nội dung/đáp án/loại của 1 câu nháp (6.4). Nếu câu
     * đủ điều kiện, lưu là chuyển thẳng vào Kho chung (dạng Nháp) luôn — không cần bước
     * "Chuyển vào Kho chung" riêng nữa. Sửa lại 1 câu đã ở trong Kho chung sẽ cập nhật
     * đúng câu đó, không tạo bản sao.
     */
    public function draftUpdate(Request $request, int $draft): RedirectResponse
    {
        $draftModel = $this->documentImportService->findDraft($draft);
        $type = $request->input('type_guess', 'mcq');
        $data = $request->validate($this->draftValidationRules($type));

        $result = $this->documentImportService->reviewSave(Auth::user(), $draftModel, $type, $data);

        $redirect = redirect()->route('admin.content.questions.reviewDraft', ['document' => $draftModel->uploaded_document_id]);

        return $result['promoted']
            ? $redirect->with('status', 'draft-promoted-one')
            : $redirect->with('status', 'draft-saved-pending')->with('draftPendingReason', $result['reason']);
    }

    /** admin.content.drafts.merge — gộp 2 câu bị OCR/tách sai thành 1 (6.4). */
    public function draftMerge(Request $request, int $draft): RedirectResponse
    {
        $draftModel = $this->documentImportService->findDraft($draft);
        $documentId = $draftModel->uploaded_document_id;
        $data = $request->validate(['merge_with_id' => ['required', 'integer']]);

        try {
            $this->documentImportService->mergeDrafts($draftModel, (int) $data['merge_with_id']);
        } catch (ValidationException $e) {
            return redirect()->route('admin.content.questions.reviewDraft', ['document' => $documentId])->withErrors($e->errors());
        }

        return redirect()->route('admin.content.questions.reviewDraft', ['document' => $documentId])->with('status', 'draft-merged');
    }

    /** admin.content.drafts.discard — bỏ 1 câu nháp (không xóa cứng, giữ lịch sử — 6.4). */
    public function draftDiscard(Request $request, int $draft): RedirectResponse
    {
        $draftModel = $this->documentImportService->findDraft($draft);
        $documentId = $draftModel->uploaded_document_id;

        $this->documentImportService->discardDraft($draftModel);

        return redirect()->route('admin.content.questions.reviewDraft', ['document' => $documentId])->with('status', 'draft-discarded');
    }

    private function draftValidationRules(string $type): array
    {
        $common = [
            'type_guess' => ['required', 'in:mcq,fill_blank,coding'],
            'title' => ['required', 'string', 'max:255'],
            'body' => ['required', 'string'],
            'points' => ['required', 'integer', 'min:1', 'max:100'],
        ];

        return match ($type) {
            'mcq' => $common + [
                'options' => ['nullable', 'array'],
                'options.*' => ['nullable', 'string', 'max:500'],
                'correct_option' => ['nullable', 'string', 'max:10'],
            ],
            'fill_blank' => $common + [
                'accepted_answers' => ['nullable', 'string', 'max:1000'],
                'case_sensitive' => ['nullable', 'boolean'],
            ],
            'coding' => $common + [
                'time_limit_ms' => ['nullable', 'integer', 'min:100', 'max:60000'],
                'memory_limit_mb' => ['nullable', 'integer', 'min:16', 'max:2048'],
                'test_cases' => ['nullable', 'string', 'max:20000'],
            ],
            default => $common,
        };
    }

    // ================= Tag/Chuyên đề (Giai đoạn 6, 19/8) =================
    // Quản lý ở đúng tab "Tag/Chuyên đề" trong admin.content.index (tab=tags) — không tạo
    // trang riêng, xem ContentService::indexData()/tagStore()/tagUpdate()/tagDestroy().

    public function tagsStore(Request $request): RedirectResponse
    {
        // SỬA 12/11 — bắt buộc chọn loại (Lập trình / Phổ thông) khi thêm tag.
        $data = $request->validate([
            'name' => ['required', 'string', 'max:120'],
            'kind' => ['required', 'string', 'in:'.implode(',', array_keys(Tag::KINDS))],
        ], ['kind.required' => 'Hãy chọn loại tag (Lập trình hoặc Phổ thông).'], ['kind' => 'loại tag']);
        $this->contentService->tagStore($data['name'], $data['kind']);

        return redirect()->route('admin.content.index', ['tab' => 'tags'])->with('status', 'tag-created');
    }

    public function tagsUpdate(Request $request, Tag $tag): RedirectResponse
    {
        $data = $request->validate([
            'name' => ['required', 'string', 'max:120'],
            'kind' => ['required', 'string', 'in:'.implode(',', array_keys(Tag::KINDS))],
        ], ['kind.required' => 'Hãy chọn loại tag (Lập trình hoặc Phổ thông).'], ['kind' => 'loại tag']);

        try {
            $this->contentService->tagUpdate($tag, $data['name'], $data['kind']);
        } catch (ValidationException $e) {
            return redirect()->route('admin.content.index', ['tab' => 'tags'])->withErrors($e->errors());
        }

        return redirect()->route('admin.content.index', ['tab' => 'tags'])->with('status', 'tag-updated');
    }

    public function tagsDestroy(Tag $tag): RedirectResponse
    {
        $this->contentService->tagDestroy($tag);

        return redirect()->route('admin.content.index', ['tab' => 'tags'])->with('status', 'tag-deleted');
    }

    // ================= Đề/bộ bài (Assessment) =================

    public function assessmentsCreate(): View
    {
        return view('admin.content.assessments.create', $this->contentService->assessmentCreateFormData());
    }

    /**
     * SỬA 16/10 (khách: "thêm phần nhập file ZIP chỗ tạo đề / bộ bài") — admin.content.assessments.zipImport: tạo hẳn 1 đề
     * PDF (Kho chung, Nháp) từ gói OT360-EPACK — mỗi câu trong exam.json tự khai dạng (trắc nghiệm, đúng/sai, điền từ, nhiều
     * ý, lập trình). Xem App\Services\ExamZipImportService. Xong chuyển sang "Quản lý đề PDF" để rà lại.
     */
    public function assessmentsZipImportStore(Request $request): RedirectResponse
    {
        $request->validate([
            // SỬA 22/10 — trần riêng cho gói ZIP (config/uploads.php, mặc định 200MB), trước dùng chung 20MB của tệp PDF.
            'exam_zip' => ['required', 'file', 'mimes:zip', 'max:'.UploadLimit::zipKilobytes()],
        ], ['exam_zip.max' => 'Gói ZIP đề vượt quá '.\App\Support\UploadLimit::zipLabel().' mà máy chủ nhận được.'], ['exam_zip' => 'Gói ZIP đề']);

        try {
            $result = app(\App\Services\ExamZipImportService::class)->importForAdmin(Auth::user(), $request->file('exam_zip'));
        } catch (ValidationException $e) {
            return redirect()->route('admin.content.assessments.create')->withErrors($e->errors());
        }

        // SỬA 16/10 — đề Luyện tập (câu hỏi rời) mở trang chi tiết đề, đúng chỗ "Câu hỏi trong đề"; đề thi PDF mở "Quản lý đề PDF".
        if (($result['mode'] ?? 'pdf') === 'practice') {
            return redirect()
                ->to(route('admin.content.show', ['content' => $result['assessment']->id, 'kind' => 'assessment']).'#assessment-items')
                ->with('status', 'assessment-zip-imported')
                ->with('zipImportSummary', $result['summary']);
        }

        return redirect()->route('admin.content.assessments.pdf.edit', $result['assessment']->id)
            ->with('status', 'assessment-zip-imported')
            ->with('zipImportSummary', $result['summary']);
    }

    /**
     * SỬA 16/10 (khách: "có nút sửa, xoá, phát hành ngay trong danh sách câu của đề") — BỎ 1 câu khỏi đề (câu vẫn còn
     * trong Kho câu hỏi), đánh lại thứ tự và cộng lại tổng điểm.
     */
    public function assessmentsItemsDestroy(Assessment $assessment, \App\Models\AssessmentItem $item): RedirectResponse
    {
        abort_unless((int) $item->assessment_id === (int) $assessment->id, 404);

        $this->contentService->assessmentItemRemove($assessment, $item);

        return redirect()
            ->to(route('admin.content.show', ['content' => $assessment->id, 'kind' => 'assessment']).'#assessment-items')
            ->with('status', 'assessment-item-removed');
    }

    /** SỬA 16/10 — phát hành 1 câu hỏi ngay trong danh sách câu của đề (cùng điều kiện như nút Phát hành ở trang câu hỏi). */
    public function assessmentsItemsPublishQuestion(Assessment $assessment, \App\Models\AssessmentItem $item): RedirectResponse
    {
        abort_unless((int) $item->assessment_id === (int) $assessment->id, 404);
        abort_if($item->question === null, 404);

        \App\Support\ExamItemPoints::fixForQuestion($item->question); // SỬA 3/11 — điểm lẻ < 1 bị làm tròn 0
        $result = $this->contentService->questionPublish($item->question->refresh());
        $back = redirect()->to(route('admin.content.show', ['content' => $assessment->id, 'kind' => 'assessment']).'#assessment-items');

        return $result['ok']
            ? $back->with('status', 'assessment-item-question-published')
            : $back->withErrors(['publish' => 'Câu "'.$item->question->title.'": '.$result['message']]);
    }

    /** SỬA 16/10 — phát hành MỘT LẦN mọi câu còn Nháp trong đề (câu chưa đủ điều kiện thì báo lại, không chặn các câu khác). */
    public function assessmentsItemsPublishAll(Assessment $assessment): RedirectResponse
    {
        \App\Services\GeneralSetBankService::fixZeroPoints($assessment); // SỬA 3/11 — chỉ tác dụng với "Bài phổ thông"
        \App\Support\ExamItemPoints::fixForAssessment($assessment); // SỬA 3/11 — câu của đề có điểm lẻ < 1 (vd 0,25) bị làm tròn 0
        $result = $this->contentService->assessmentPublishAllQuestions($assessment);
        $back = redirect()->to(route('admin.content.show', ['content' => $assessment->id, 'kind' => 'assessment']).'#assessment-items')
            ->with('status', 'assessment-items-published')
            ->with('publishedCount', $result['published']);

        return $result['failed'] === [] ? $back : $back->withErrors(['publish' => $result['failed']]);
    }

    public function assessmentsStore(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'title' => ['required', 'string', 'max:255'],
            'type' => ['required', 'string', 'in:practice,assignment,exam,competition_paper'],
            'duration_minutes' => ['nullable', 'integer', 'min:0'],
            'publish_answer_rule' => ['required', 'string', 'in:never,after_deadline,immediately'],
            // SỬA 2/10 — 6 trường mô tả đề cho bản mẫu UI mới. 'province'/'exam_category' cố ý
            // KHÔNG dùng 'in:...' danh sách mã: ContentService chuẩn hoá lại qua catalog, mã lạ
            // thành null = "chưa gán" thay vì chặn cả form chỉ vì một ô phân loại tuỳ chọn.
            'subtitle' => ['nullable', 'string', 'max:255'],
            'author' => ['nullable', 'string', 'max:120'],
            'province' => ['nullable', 'string', 'max:20'],
            'academic_year' => ['nullable', 'string', 'max:20'],
            // SỬA 7/10 — độ khó 1-5 của đề (hiện thành số sao ngoài trang Luyện tập).
            'difficulty_level' => ['nullable', 'integer', 'between:1,5'],
            // SỬA 7/10 — điểm sao (0-5, tối đa 1 chữ số lẻ) + số lượt đánh giá nhập tay. Đã nhập điểm thì
            // phải có số lượt (>= 1), nếu không "4,5/5 (0 đánh giá)" là vô nghĩa.
            'rating_score' => ['nullable', 'numeric', 'between:0,5'],
            'rating_count' => ['nullable', 'integer', 'min:1', 'max:1000000', 'required_with:rating_score'],
            'exam_category' => ['nullable', 'string', 'max:30'],
            'exam_level' => ['nullable', 'string', 'max:10'], // SỬA 12/10 — khối THCS/THPT/Khác, xem App\Support\ExamLevel
            // SỬA 2/10 lần 3 — BẢN XEM TRƯỚC: một tệp PDF do người ra đề tải lên. Không nhận
            // preview_page_from/to ở form này (đó là của màn "Quản lý đề PDF") — xem ghi chú
            // trong partials/assessment-detail-fields.
            // max lấy theo giới hạn THẬT của máy chủ (upload_max_filesize/post_max_size), không
            // ghi cứng — xem App\Support\UploadLimit.
            'preview_pdf' => ['nullable', 'file', 'mimes:pdf', 'max:'.UploadLimit::maxKilobytes()],
            'remove_preview_pdf' => ['nullable', 'boolean'],
            // SỬA 11/10 — PDF Hướng dẫn / Bài mẫu (hiện ở tab Hướng dẫn, Bài mẫu khi làm đề).
            'guide_pdf' => ['nullable', 'file', 'mimes:pdf', 'max:'.UploadLimit::maxKilobytes()],
            'remove_guide_pdf' => ['nullable', 'boolean'],
            'sample_pdf' => ['nullable', 'file', 'mimes:pdf', 'max:'.UploadLimit::maxKilobytes()],
            'remove_sample_pdf' => ['nullable', 'boolean'],
            'cover' => ['nullable', 'image', 'mimes:jpeg,png,webp', 'max:'.UploadLimit::maxKilobytes(4096)],
            'cover_catalog' => ['nullable', 'string', 'max:40'], // SỬA 10/10 — id ảnh trong App\Support\AssessmentCover
            'remove_cover' => ['nullable', 'boolean'],
        ]);

        $assessment = $this->contentService->assessmentStore(Auth::user(), $data, $request->file('cover'));

        return redirect()->route('admin.content.show', ['content' => $assessment->id, 'kind' => 'assessment'])->with('status', 'assessment-created');
    }

    public function assessmentsEdit(Request $request, int $assessment): View
    {
        return view('admin.content.assessments.edit',
            $this->contentService->assessmentEditFormData($assessment)
            + ['returnTo' => $this->rememberContentListUrl($request, 'assessments')]);
    }

    /**
     * SỬA 4/10 (khách: "lưu chỉnh sửa xong thì nó quay lại trang danh sách đúng tab đó luôn nha")
     * — GHI NHỚ địa chỉ danh sách lúc MỞ màn Sửa, để lúc Lưu quay về đúng chỗ đó.
     *
     * Dùng lại chính địa chỉ người dùng vừa đứng nên giữ nguyên cả BỘ LỌC họ đang đặt (môn, khối,
     * tỉnh, năm, ô tìm kiếm), không riêng đúng tab. Sửa 20 câu trong một bộ lọc mà mỗi lần lưu
     * lại văng về danh sách trắng thì phải lọc lại 20 lần.
     *
     * Vào thẳng màn Sửa bằng link (không qua danh sách) thì rơi về danh sách đúng tab.
     */
    /**
     * SỬA 16/10 — trang người dùng vừa đứng TRƯỚC khi mở form (nút Quay lại / sau khi Lưu quay về đó). Chỉ nhận trang trong khu
     * admin của CHÍNH hệ thống và không phải chính form đang mở; không có thì dùng $fallback.
     */
    private function rememberAdminBackUrl(Request $request, string $fallback): string
    {
        $previous = url()->previous();
        $path = (string) parse_url($previous, PHP_URL_PATH);

        // SỬA 16/10 (khách: "nhập file ZIP, lưu câu hỏi xong phải chuyển qua trang DANH SÁCH") — đến từ màn TẠO / NHẬP ZIP
        // (…/create, …/zip-import) thì không quay lại form đó nữa mà về danh sách ($fallback).
        if ($path === $request->getPathInfo() || preg_match('#/(create|zip-import)/?$#', $path)) {
            return $fallback;
        }

        return $this->safeAdminBackUrl($previous, $fallback);
    }

    /** Địa chỉ quay về an toàn: cùng tên miền + nằm trong /admin (chặn chuyển hướng ra trang ngoài qua ô ẩn return_to). */
    private function safeAdminBackUrl(string $url, string $fallback): string
    {
        if ($url === '') {
            return $fallback;
        }

        $parts = parse_url($url);
        if (! is_array($parts) || str_starts_with($url, '//')) {
            return $fallback;
        }

        $host = $parts['host'] ?? null;
        $ownHost = parse_url(route('admin.content.index'), PHP_URL_HOST);
        if ($host !== null && strcasecmp((string) $host, (string) $ownHost) !== 0) {
            return $fallback;
        }

        return str_starts_with((string) ($parts['path'] ?? ''), '/admin/') ? $url : $fallback;
    }

    private function rememberContentListUrl(Request $request, string $tab): string
    {
        $previous = url()->previous();

        return $this->isContentListUrl($previous)
            ? $previous
            : route('admin.content.index', ['tab' => $tab]);
    }

    /**
     * Địa chỉ quay về sau khi Lưu.
     *
     * KIỂM LẠI giá trị form gửi lên chứ không tin thẳng: 'return_to' là ô ẩn, ai cũng sửa được.
     * Nhận bừa là mở đường cho chuyển hướng ra ngoài (gửi cho admin một link kèm
     * return_to=http://trang-gia…, bấm Lưu xong văng sang trang giả mạo). Chỉ chấp nhận địa chỉ
     * trỏ đúng trang danh sách của chính hệ thống này.
     */
    private function contentListRedirect(Request $request, string $tab): string
    {
        $candidate = (string) $request->input('return_to', '');

        return $this->isContentListUrl($candidate)
            ? $candidate
            : route('admin.content.index', ['tab' => $tab]);
    }

    /** Có đúng là địa chỉ trang danh sách Kho bài tập của chính hệ thống này không. */
    private function isContentListUrl(string $url): bool
    {
        if ($url === '') {
            return false;
        }

        $listUrl = route('admin.content.index');

        return parse_url($url, PHP_URL_HOST) === parse_url($listUrl, PHP_URL_HOST)
            && parse_url($url, PHP_URL_PATH) === parse_url($listUrl, PHP_URL_PATH);
    }

    public function assessmentsItemsEdit(Assessment $assessment): View
    {
        return view('admin.content.assessments.items', $this->contentService->assessmentItemsFormData($assessment));
    }

    public function assessmentsItemsUpdate(Request $request, Assessment $assessment): RedirectResponse
    {
        $data = $request->validate([
            'question_ids' => ['required', 'array', 'min:1'],
            'question_ids.*' => ['integer', 'exists:questions,id'],
            // SỬA 11/10 (khách: "điểm từng câu để người dùng nhập") — points[<question_id>] là điểm
            // người ra đề nhập cho từng câu (số nguyên hoặc thập phân). Gửi kèm question_ids[]
            // theo đúng thứ tự trong đề; service ghi vào assessment_items.points_override.
            ...\App\Support\AssessmentPoints::rules(),
        ], [], ['question_ids' => 'Câu hỏi'] + \App\Support\AssessmentPoints::attributeNames());

        $this->contentService->assessmentItemsUpdate($assessment, $data);

        return redirect()->route('admin.content.show', ['content' => $assessment->id, 'kind' => 'assessment'])->with('status', 'assessment-updated');
    }

    /**
     * SỬA 11/10 (khách: "điểm từng câu hỏi trong đề cho nhập chứ không lấy từ độ khó") — đổi điểm
     * MỘT câu ngay trên trang chi tiết đề (danh sách "Câu hỏi trong đề"). Số nguyên hoặc thập
     * phân; tổng điểm đề được cộng lại ngay.
     */
    public function assessmentsItemsPoints(Request $request, Assessment $assessment, \App\Models\AssessmentItem $item): RedirectResponse
    {
        abort_unless((int) $item->assessment_id === (int) $assessment->id, 404);

        $data = $request->validate(
            ['points' => ['required', 'numeric', 'min:0', 'max:'.\App\Support\AssessmentPoints::MAX]],
            [],
            ['points' => 'Điểm']
        );

        $this->contentService->assessmentItemSetPoints($assessment, $item, (float) $data['points']);

        return redirect()
            ->to(route('admin.content.show', ['content' => $assessment->id, 'kind' => 'assessment']).'#assessment-items')
            ->with('status', 'assessment-updated');
    }

    /**
     * SỬA 9/10 (khách: "có nút đưa lên trước … cho từng câu hỏi để tôi thay đổi thứ tự") — dời
     * một câu trong đề lên/xuống một vị trí; thứ tự này chính là "Câu 1, Câu 2…" học sinh thấy.
     */
    public function assessmentsItemsMove(Request $request, Assessment $assessment, \App\Models\AssessmentItem $item): RedirectResponse
    {
        abort_unless((int) $item->assessment_id === (int) $assessment->id, 404);

        $data = $request->validate(['direction' => ['required', 'in:up,down,top']]);

        $this->contentService->assessmentItemMove($assessment, $item, $data['direction']);

        return redirect()
            ->to(route('admin.content.show', ['content' => $assessment->id, 'kind' => 'assessment']).'#assessment-items')
            ->with('status', 'assessment-updated');
    }

    public function assessmentsUpdate(Request $request, Assessment $assessment): RedirectResponse
    {
        $data = $request->validate([
            'title' => ['required', 'string', 'max:255'],
            'type' => ['required', 'string', 'in:practice,assignment,exam,competition_paper'],
            'duration_minutes' => ['nullable', 'integer', 'min:0'],
            'publish_answer_rule' => ['required', 'string', 'in:never,after_deadline,immediately'],
            // SỬA 2/10 — 6 trường mô tả đề cho bản mẫu UI mới. 'province'/'exam_category' cố ý
            // KHÔNG dùng 'in:...' danh sách mã: ContentService chuẩn hoá lại qua catalog, mã lạ
            // thành null = "chưa gán" thay vì chặn cả form chỉ vì một ô phân loại tuỳ chọn.
            'subtitle' => ['nullable', 'string', 'max:255'],
            'author' => ['nullable', 'string', 'max:120'],
            'province' => ['nullable', 'string', 'max:20'],
            'academic_year' => ['nullable', 'string', 'max:20'],
            // SỬA 7/10 — độ khó 1-5 của đề (hiện thành số sao ngoài trang Luyện tập).
            'difficulty_level' => ['nullable', 'integer', 'between:1,5'],
            // SỬA 7/10 — điểm sao (0-5, tối đa 1 chữ số lẻ) + số lượt đánh giá nhập tay. Đã nhập điểm thì
            // phải có số lượt (>= 1), nếu không "4,5/5 (0 đánh giá)" là vô nghĩa.
            'rating_score' => ['nullable', 'numeric', 'between:0,5'],
            'rating_count' => ['nullable', 'integer', 'min:1', 'max:1000000', 'required_with:rating_score'],
            'exam_category' => ['nullable', 'string', 'max:30'],
            'exam_level' => ['nullable', 'string', 'max:10'], // SỬA 12/10 — khối THCS/THPT/Khác, xem App\Support\ExamLevel
            // SỬA 2/10 lần 3 — BẢN XEM TRƯỚC: một tệp PDF do người ra đề tải lên. Không nhận
            // preview_page_from/to ở form này (đó là của màn "Quản lý đề PDF") — xem ghi chú
            // trong partials/assessment-detail-fields.
            // max lấy theo giới hạn THẬT của máy chủ (upload_max_filesize/post_max_size), không
            // ghi cứng — xem App\Support\UploadLimit.
            'preview_pdf' => ['nullable', 'file', 'mimes:pdf', 'max:'.UploadLimit::maxKilobytes()],
            'remove_preview_pdf' => ['nullable', 'boolean'],
            // SỬA 11/10 — PDF Hướng dẫn / Bài mẫu (hiện ở tab Hướng dẫn, Bài mẫu khi làm đề).
            'guide_pdf' => ['nullable', 'file', 'mimes:pdf', 'max:'.UploadLimit::maxKilobytes()],
            'remove_guide_pdf' => ['nullable', 'boolean'],
            'sample_pdf' => ['nullable', 'file', 'mimes:pdf', 'max:'.UploadLimit::maxKilobytes()],
            'remove_sample_pdf' => ['nullable', 'boolean'],
            'cover' => ['nullable', 'image', 'mimes:jpeg,png,webp', 'max:'.UploadLimit::maxKilobytes(4096)],
            'cover_catalog' => ['nullable', 'string', 'max:40'], // SỬA 10/10 — id ảnh trong App\Support\AssessmentCover
            'remove_cover' => ['nullable', 'boolean'],
        ]);

        $this->contentService->assessmentUpdate($assessment, $data, $request->file('cover'), $request->boolean('remove_cover'));

        // SỬA 4/10 — về thẳng danh sách (giữ nguyên tab + bộ lọc) thay vì màn chi tiết.
        // CỐ Ý không đổi assessmentsItemsUpdate() ở trên: đó là màn sửa CÁC CÂU TRONG ĐỀ, sửa
        // xong phải thấy lại chính cái đề vừa sửa chứ không phải văng ra danh sách.
        return redirect()->to($this->contentListRedirect($request, 'assessments'))->with('status', 'assessment-updated');
    }

    public function assessmentsPublish(Assessment $assessment): RedirectResponse
    {
        $result = $this->contentService->assessmentPublish($assessment);

        if (! $result['ok']) {
            return redirect()->route('admin.content.show', ['content' => $assessment->id, 'kind' => 'assessment'])->withErrors(['publish' => $result['message']]);
        }

        return redirect()->route('admin.content.show', ['content' => $assessment->id, 'kind' => 'assessment'])->with('status', 'assessment-published');
    }

    public function assessmentsReject(Request $request, Assessment $assessment): RedirectResponse
    {
        $data = $request->validate(['reason' => ['required', 'string', 'max:1000']]);
        $this->contentService->assessmentReject($assessment, $data['reason']);

        return redirect()->route('admin.content.show', ['content' => $assessment->id, 'kind' => 'assessment'])->with('status', 'assessment-rejected');
    }

    public function assessmentsArchive(Request $request, Assessment $assessment): RedirectResponse
    {
        $data = $request->validate(['reason' => ['required', 'string', 'max:1000']]);
        $this->contentService->assessmentArchive($assessment, $data['reason']);

        return redirect()->route('admin.content.show', ['content' => $assessment->id, 'kind' => 'assessment'])->with('status', 'assessment-archived');
    }

    /**
     * SỬA 19/8 (Giai đoạn 4) — nút "Duyệt đưa vào kho chung" ở ngay bảng danh sách tab
     * "Đề/bộ bài" (admin.content.index?tab=assessments), KHÁC assessmentsPublish/Reject/
     * Archive ở trên vốn redirect về trang chi tiết 1 đề (admin.content.show) — hành động
     * này bấm thẳng từ bảng danh sách nên quay lại đúng bảng đó, không cần vào chi tiết.
     */
    public function assessmentsPromoteToShared(Assessment $assessment): RedirectResponse
    {
        $this->contentService->assessmentPromoteToShared($assessment);

        return redirect()->route('admin.content.index', ['tab' => 'assessments'])->with('status', 'assessment-promoted-shared');
    }

    // ================= "Bộ đề" — nhập hàng loạt nhiều đề PDF (Giai đoạn 3, 19/8) ==========
    // Khác assessmentsCreate/Store ở trên (tạo TỪNG đề PDF trống 1 lần) — bulk tạo NHIỀU đề
    // cùng lúc, theo 2 cách: tách từ 1 file PDF lớn theo khoảng trang, hoặc tải nhiều file PDF
    // riêng lẻ cùng lúc. Đáp án vẫn phải vào "Quản lý đề PDF" nhập tay từng đề sau khi tạo.

    public function assessmentsBulkCreate(): View
    {
        return view('admin.content.assessments.bulk', $this->contentService->assessmentBulkCreateFormData());
    }

    public function assessmentsBulkSplit(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'source_pdf' => ['required', 'file', 'mimes:pdf', 'max:'.ContentService::maxBulkSourcePdfKb()],
            'rows' => ['required', 'array', 'min:1'],
            'rows.*.exam_code' => ['nullable', 'string', 'max:60'],
            'rows.*.title' => ['required', 'string', 'max:255'],
            'rows.*.type' => ['required', 'string', 'in:practice,assignment,exam,competition_paper'], // SỬA 16/10 — thêm Luyện tập
            'rows.*.from_page' => ['required', 'integer', 'min:1'],
            'rows.*.to_page' => ['required', 'integer', 'min:1', 'gte:rows.*.from_page'],
        ], [], ['source_pdf' => 'File PDF gốc']);

        $created = $this->contentService->assessmentBulkSplit(Auth::user(), $data['source_pdf'], $data['rows']);

        return redirect()->route('admin.content.index', ['tab' => 'assessments'])
            ->with('status', 'assessments-bulk-created')
            ->with('bulkCreatedCount', $created->count());
    }

    public function assessmentsBulkMulti(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'files' => ['required', 'array', 'min:1'],
            'files.*' => ['file', 'mimes:pdf', 'max:'.ContentService::maxPdfKb()],
            'meta' => ['required', 'array', 'min:1'],
            'meta.*.exam_code' => ['nullable', 'string', 'max:60'],
            'meta.*.title' => ['required', 'string', 'max:255'],
            'meta.*.type' => ['required', 'string', 'in:practice,assignment,exam,competition_paper'], // SỬA 16/10 — thêm Luyện tập
        ]);

        $created = $this->contentService->assessmentBulkMulti(Auth::user(), $data['files'], $data['meta']);

        return redirect()->route('admin.content.index', ['tab' => 'assessments'])
            ->with('status', 'assessments-bulk-created')
            ->with('bulkCreatedCount', $created->count());
    }

    // ================= Đề PDF + phiếu đáp án (18/8, 16/8 mục 1.2/5/6) =================
    // Chỉ áp dụng cho Assessment content_mode=pdf_answer_sheet (mọi type trừ Practice — xem
    // App\Services\Admin\ContentService::contentModeForType()). Không dùng chung route/hàm
    // với assessmentsItemsEdit/Update ở trên — đó là cho content_mode=structured (gắn Question
    // rời), đề PDF không có Question nào cả.

    /** admin.content.assessments.pdf.edit — màn cấu hình PDF + đáp án + bài lập trình con. */
    public function assessmentsPdfEdit(Assessment $assessment): View
    {
        return view('admin.content.assessments.pdf', $this->contentService->assessmentPdfFormData($assessment));
    }

    /**
     * admin.content.assessments.pdf.update — lưu mã đề/phạm vi xem thử, thay file PDF/lời
     * giải nếu có tải mới, và THAY TOÀN BỘ đáp án đúng từng câu (khách chốt 16/8 mục 1.2:
     * "đáp án nhập trực tiếp trên form", KHÔNG làm nhập bằng Excel/CSV).
     */
    public function assessmentsPdfUpdate(Request $request, Assessment $assessment): RedirectResponse
    {
        $data = $request->validate([
            'exam_code' => ['nullable', 'string', 'max:60', 'unique:assessments,exam_code,'.$assessment->id],
            'preview_page_from' => ['nullable', 'integer', 'min:1'],
            'preview_page_to' => ['nullable', 'integer', 'min:1', 'gte:preview_page_from'],
            'pdf' => ['nullable', 'file', 'mimes:pdf', 'max:'.ContentService::maxPdfKb()],
            'solution_pdf' => ['nullable', 'file', 'mimes:pdf', 'max:'.ContentService::maxPdfKb()],
            'answer_keys' => ['nullable', 'array'],
            'answer_keys.*.question_no' => ['required_with:answer_keys', 'integer', 'min:1'],
            'answer_keys.*.question_type' => ['required_with:answer_keys', 'string', 'in:single_choice,true_false,true_false_group,short_answer,multi_part'],
            'answer_keys.*.correct_answer' => ['required_with:answer_keys'],
            'answer_keys.*.points' => ['nullable', 'numeric', 'min:0', 'max:1000'], // SỬA 16/10 — điểm lẻ 0,25
        ], [], [
            'exam_code' => 'Mã đề',
            'pdf' => 'Tệp PDF đề',
            'solution_pdf' => 'Tệp PDF lời giải',
        ]);

        // SỬA 9/9 (3) — LỖI CŨ (khách báo: "dạng đúng/sai, đúng sai 4 ý, câu nhiều ý không lưu
        // được"): chỗ này viết `$row + [...]`. Toán tử "+" của PHP CHỈ thêm khoá còn THIẾU, không
        // ghi đè khoá đã có — mà $row đã có sẵn 'correct_answer' từ form, nên giá trị đã chuẩn hoá
        // bị vứt đi, thứ lưu xuống là giá trị thô của form:
        //   · Đúng/Sai 4 ý  -> lưu ["a"=>"1","b"=>"0"…] (chuỗi) thay vì true/false: mở lại thấy cả
        //     4 ý đều "Đúng" (chuỗi "0" vẫn là truthy) và chấm bài không bao giờ khớp;
        //   · Câu nhiều ý   -> lưu nguyên chuỗi "a:A-b:Đ-c:123" thay vì cấu trúc từng ý: mở lại ô
        //     nhập trống trơn;
        //   · Đúng/Sai      -> lưu chuỗi "1"/"0" thay vì bool.
        // Trắc nghiệm và Trả lời ngắn không lộ lỗi vì giá trị thô vốn đã đúng dạng cần lưu.
        // array_replace() ghi đè đúng khoá 'correct_answer'.
        $answerKeyRows = array_map(
            fn (array $row) => array_replace($row, [
                'correct_answer' => AnswerKeySheet::normalizeFormAnswer($row['question_type'], $row['correct_answer']),
            ]),
            $data['answer_keys'] ?? [],
        );

        $this->contentService->assessmentPdfUpdate(
            $assessment,
            $data,
            $answerKeyRows,
            $request->file('pdf'),
            $request->file('solution_pdf'),
        );

        return redirect()->route('admin.content.assessments.pdf.edit', $assessment->id)->with('status', 'assessment-pdf-updated');
    }

    /**
     * Chuẩn hoá $correct_answer thô từ form (mọi giá trị đều là string/array of string, HTML
     * form không tự biết kiểu) về đúng hình dạng App\Models\AssessmentAnswerKey::isCorrect()
     * mong đợi theo từng question_type — quan trọng nhất là true_false_group: input đến từ
     * checkbox qua field ẩn ("1"/"0" dạng chuỗi) phải đổi thành bool thật, nếu không phép so
     * sánh !== trong trueFalseGroupMatches() sẽ luôn sai kiểu dù đúng giá trị.
     */

    /** admin.content.assessments.coding-items.store — thêm 1 bài lập trình con vào đề PDF. */
    public function assessmentsCodingItemsStore(Request $request, Assessment $assessment): RedirectResponse
    {
        $data = $request->validate($this->codingItemRules(), [], ['code' => 'Mã bài']);

        $this->contentService->codingItemStore($assessment, $data);

        return redirect()->route('admin.content.assessments.pdf.edit', $assessment->id)->with('status', 'coding-item-created');
    }

    public function assessmentsCodingItemsUpdate(Request $request, AssessmentCodingItem $codingItem): RedirectResponse
    {
        $data = $request->validate($this->codingItemRules(), [], ['code' => 'Mã bài']);

        $this->contentService->codingItemUpdate($codingItem, $data);

        return redirect()->route('admin.content.assessments.pdf.edit', $codingItem->assessment_id)->with('status', 'coding-item-updated');
    }

    public function assessmentsCodingItemsDestroy(AssessmentCodingItem $codingItem): RedirectResponse
    {
        $assessmentId = $codingItem->assessment_id;
        $this->contentService->codingItemDestroy($codingItem);

        return redirect()->route('admin.content.assessments.pdf.edit', $assessmentId)->with('status', 'coding-item-deleted');
    }

    private function codingItemRules(): array
    {
        return [
            'code' => ['required', 'string', 'max:40'],
            'title' => ['required', 'string', 'max:255'],
            'pdf_page' => ['nullable', 'integer', 'min:1'],
            'allowed_languages' => ['nullable', 'array'],
            'allowed_languages.*' => ['string', 'in:cpp,python'],
            'time_limit_ms' => ['nullable', 'integer', 'min:100', 'max:60000'],
            'memory_limit_kb' => ['nullable', 'integer', 'min:16384', 'max:1048576'],
            'points' => ['nullable', 'numeric', 'min:0', 'max:1000'], // SỬA 16/10 — điểm lẻ
            // SỬA 30/9 — "thứ tự ưu tiên hiển thị": số càng lớn càng hiện trước, 0 = bình thường.
            'display_order' => ['nullable', 'integer', 'min:0', 'max:65535'],
        ];
    }

    /**
     * admin.content.assessments.coding-items.test-cases.import — tải gói ZIP chứa nhiều cặp
     * file input/output cho 1 bài lập trình con (16/8 mục 1.2 — không phải nhập đáp án bằng
     * Excel/CSV, chỉ là tệp kèm theo cho việc chấm code).
     */
    public function assessmentsCodingItemsTestCasesImport(Request $request, AssessmentCodingItem $codingItem): RedirectResponse
    {
        $request->validate([
            'test_cases_zip' => ['required', 'file', 'mimes:zip', 'max:'.ContentService::maxPdfKb()],
        ], [], ['test_cases_zip' => 'Gói ZIP test case']);

        $created = $this->contentService->codingItemImportTestCasesZip($codingItem, $request->file('test_cases_zip'));

        return redirect()->route('admin.content.assessments.pdf.edit', $codingItem->assessment_id)
            ->with('status', 'test-cases-imported')
            ->with('testCasesImportedCount', $created);
    }
}
