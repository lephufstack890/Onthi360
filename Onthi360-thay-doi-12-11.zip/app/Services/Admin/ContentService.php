<?php

namespace App\Services\Admin;

use App\Enums\AssessmentContentMode;
use App\Enums\AssessmentType;
use App\Enums\ContentStatus;
use App\Enums\OwnerType;
use App\Enums\ProgressUnitType;
use App\Enums\UploadedDocumentStatus;
use App\Enums\Visibility;
use App\Models\Assessment;
use App\Models\AssessmentCodingItem;
use App\Models\AttemptAnswer;
use App\Models\Material;
use App\Models\Product;
use App\Models\Question;
use App\Models\QuestionBank;
use App\Models\RatingSummary;
use App\Models\Review;
use App\Models\Tag;
use App\Models\UploadedDocument;
use App\Models\User;
use App\Enums\ReviewTargetType;
use App\Repositories\Contracts\AssessmentRepositoryInterface;
use App\Repositories\Contracts\DraftQuestionRepositoryInterface;
use App\Repositories\Contracts\MaterialRepositoryInterface;
use App\Repositories\Contracts\ProductRepositoryInterface;
use App\Repositories\Contracts\QuestionRepositoryInterface;
use App\Repositories\Contracts\TagRepositoryInterface;
use App\Repositories\Contracts\UploadedDocumentRepositoryInterface;
use App\Services\PdfAssessmentEditingService;
use App\Services\PdfAssessmentPublishGuard;
use App\Services\PdfBulkImportService;
use App\Services\PdfTextExtractor;
use App\Services\QuestionPublishGuard;
use App\Support\AssessmentPoints;
use App\Support\QuestionDifficulty;
use App\Support\ExamCategory;
use App\Support\ImageOptimizer;
use App\Support\ProvinceCatalog;
use App\Support\QuestionZipPackage;
use App\Support\SubjectCatalog;
use App\Support\UniqueCodeFromFilename;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use ZipArchive;

/**
 * Gom truy vấn/nhãn cho admin.content.* (ADM-03, 6.2/6.4/6.5).
 */
class ContentService
{
    /** SỬA 2/10 — nơi cất ảnh bìa đề, cùng disk 'public' với ảnh khoá học để link asset() chạy. */
    private const ASSESSMENT_COVER_DIR = 'assessments/covers';

    private const ASSESSMENT_COVER_DISK = 'public';

    // Tệp PDF xem trước nằm ở disk RIÊNG TƯ (local), không nằm trong public/ — ra ngoài qua
    // route practice.exam.preview, giống đường đi của assessments.pdf_path.
    private const ASSESSMENT_PREVIEW_DIR = 'assessments/previews';
    private const ASSESSMENT_PREVIEW_DISK = 'local';

    public function __construct(
        private MaterialRepositoryInterface $materials,
        private QuestionRepositoryInterface $questions,
        private AssessmentRepositoryInterface $assessments,
        private DraftQuestionRepositoryInterface $draftQuestions,
        private ProductRepositoryInterface $products,
        private QuestionPublishGuard $publishGuard,
        private UploadedDocumentRepositoryInterface $uploadedDocuments,
        private PdfAssessmentPublishGuard $pdfAssessmentGuard,
        // SỬA 18/8 (2): logic soạn đề PDF (file/đáp án/bài lập trình con) chuyển hết sang
        // App\Services\PdfAssessmentEditingService — dùng CHUNG với Teacher\AssessmentService
        // (Giáo viên cũng tải đề PDF riêng, 16/8 mục 1.2) thay vì lặp lại ở 2 nơi.
        private PdfAssessmentEditingService $pdfEditing,
        // SỬA 19/8 (Giai đoạn 3 — "Bộ đề"): nhập hàng loạt nhiều đề PDF cùng lúc, dùng CHUNG
        // với Teacher\AssessmentService — xem App\Services\PdfBulkImportService.
        private PdfBulkImportService $pdfBulkImport,
        // SỬA 19/8 (Giai đoạn 6 — "Gắn tag/chủ đề cho câu hỏi"): xem App\Models\Tag.
        private TagRepositoryInterface $tags,
        // SỬA 3/9 (nối trích PDF thành text cho đề bài nhập ZIP) — xem
        // placeholderBodyForZipImport() bên dưới.
        private PdfTextExtractor $pdfTextExtractor,
    ) {}

    public static function maxPdfKb(): int
    {
        return PdfAssessmentEditingService::maxPdfKb();
    }

    public static function maxBulkSourcePdfKb(): int
    {
        return PdfBulkImportService::maxSourcePdfKb();
    }

    // SỬA 4/9 ("file học liệu có thể là audio, pdf, ảnh động... đính nhiều loại cùng lúc") —
    // giới hạn riêng cho 2 loại file mới, xem materialsCreate/materialsUpdate() ở
    // ContentController + storeMaterialAudio()/storeMaterialImage() ở dưới.
    private const MAX_MATERIAL_AUDIO_KB = 20480; // 20MB

    private const MAX_MATERIAL_IMAGE_KB = 15360; // 15MB — đủ cho ảnh GIF động dung lượng lớn

    public static function maxMaterialAudioKb(): int
    {
        return self::MAX_MATERIAL_AUDIO_KB;
    }

    public static function maxMaterialImageKb(): int
    {
        return self::MAX_MATERIAL_IMAGE_KB;
    }

    // SỬA 25/8 (tải bài hàng loạt qua ZIP, xem materialsBulkImportFromZip()) — 50MB vì gói
    // này gồm NHIỀU tệp PDF nội dung (mỗi bài 1 tệp), khác MAX_ZIP_PACKAGE_KB (20MB) của gói
    // OT360-QPACK chỉ có 1 câu hỏi + test case.
    private const MAX_BULK_MATERIAL_ZIP_KB = 51200;

    public static function maxBulkMaterialZipKb(): int
    {
        return self::MAX_BULK_MATERIAL_ZIP_KB;
    }

    private const TYPE_LABELS = [
        'material' => 'Học liệu',
        'question' => 'Câu hỏi (kho chung)',
        'assessment' => 'Đề/bộ bài',
    ];

    /**
     * Nhãn tiếng Việt cho Material::type — nguồn DUY NHẤT, dùng cả ở dropdown tạo/sửa học
     * liệu (materialCreateFormData()) lẫn cột "Loại" của bảng Nội dung (indexData()). Trước
     * đây bảng Nội dung hiện thẳng $m->type (chuỗi thô "assessment_ref"...) — khó hiểu với
     * người dùng, đã báo lại và sửa ở đây.
     */
    private const MATERIAL_TYPE_LABELS = [
        'chapter' => 'Chương',
        'section' => 'Bài/Mục',
        'assessment_ref' => 'Tham chiếu đề/bộ bài',
    ];

    /** Nhãn tiếng Việt cho Question::type — nguồn DUY NHẤT, dùng cả ở dropdown tạo/sửa câu hỏi (questionCreateFormData()) lẫn cột "Loại" của bảng Nội dung (indexData()), cùng lý do như MATERIAL_TYPE_LABELS ở trên. */
    private const QUESTION_TYPE_LABELS = [
        'coding' => 'Lập trình (OJ)',
        'mcq' => 'Trắc nghiệm',
        'fill_blank' => 'Điền khuyết',
        // SỬA 31/8 (2, "mở rộng ZIP bài tập") — chỉ tạo được qua nhập ZIP, xem QuestionType::Composite.
        'composite' => 'Nhiều phần (composite)',
    ];

    /**
     * SỬA 8/9 (3) — nhãn trạng thái cho dropdown BỘ LỌC ở tab "Câu hỏi". Cố ý tách khỏi
     * statusLabel() (hàm đó còn trả kèm 'tone' màu cho badge từng dòng, và nhận enum chứ không
     * phải chuỗi) — ở đây chỉ cần cặp giá trị=>nhãn để dựng thẻ <option>.
     */
    private const CONTENT_STATUS_OPTIONS = [
        'draft' => 'Nháp',
        'pending_review' => 'Chờ duyệt',
        'published' => 'Phát hành',
        'archived' => 'Lưu trữ',
    ];

    /**
     * Kho câu hỏi chung dùng chung cho toàn hệ thống (6.5: "Kho chung: Editor/Admin/Super
     * Admin quản lý"). Tự tạo nếu chưa seed sẵn (môi trường mới/production chưa chạy
     * DemoDataSeeder) — không bắt admin phải tự quản lý khái niệm "bank" khi tạo câu hỏi.
     */
    private function sharedBank(): QuestionBank
    {
        return QuestionBank::firstOrCreate(
            ['owner_type' => OwnerType::Shared->value, 'name' => 'Kho chung'],
        );
    }

    private function statusLabel(ContentStatus $status): array
    {
        return match ($status) {
            ContentStatus::Draft => ['Nháp', 'neutral'],
            ContentStatus::PendingReview => ['Chờ duyệt', 'warning'],
            ContentStatus::Published => ['Phát hành', 'success'],
            ContentStatus::Archived => ['Lưu trữ', 'neutral'],
        };
    }

    /**
     * Tài liệu OCR đang chờ rà soát/xử lý — hiển thị ở tab "Câu hỏi chờ rà soát (OCR)"
     * (6.4). KHÔNG lọc theo người tải lên: tài liệu thuộc "Kho chung", cả nhóm
     * Admin/Editor cùng thấy và rà soát được (khác Teacher — nơi mỗi giáo viên chỉ
     * thấy tài liệu của chính mình).
     */
    private function pendingDocuments(): array
    {
        $statuses = [
            UploadedDocumentStatus::Uploaded,
            UploadedDocumentStatus::Scanning,
            UploadedDocumentStatus::QueuedOcr,
            UploadedDocumentStatus::Processing,
            UploadedDocumentStatus::NeedsReview,
            UploadedDocumentStatus::Failed,
        ];

        return $this->uploadedDocuments->query()
            ->whereIn('status', $statuses)
            ->with('uploader')
            ->latest()
            ->limit(20)
            ->get()
            ->map(function (UploadedDocument $doc) {
                [$label, $tone, $progress] = match ($doc->status) {
                    UploadedDocumentStatus::Uploaded => ['Đã tải lên — đang chờ quét', 'info', 10],
                    UploadedDocumentStatus::Scanning => ['Đang quét định dạng...', 'info', 25],
                    UploadedDocumentStatus::QueuedOcr => ['Trong hàng chờ OCR...', 'info', 40],
                    UploadedDocumentStatus::Processing => ['Đang trích xuất/OCR...', 'info', 70],
                    UploadedDocumentStatus::NeedsReview => ['Cần rà soát', 'warning', 100],
                    UploadedDocumentStatus::Failed => ['Xử lý lỗi', 'danger', 100],
                    default => ['Không rõ', 'neutral', 0],
                };

                return [
                    'id' => $doc->id,
                    'name' => $doc->original_filename,
                    'uploader' => $doc->uploader->name ?? '?',
                    'status' => $label,
                    'tone' => $tone,
                    'progress' => $progress,
                    'reviewable' => $doc->status === UploadedDocumentStatus::NeedsReview,
                    'errorLog' => $doc->status === UploadedDocumentStatus::Failed ? $doc->error_log : null,
                ];
            })->all();
    }

    /** SỬA 7/10 (khách: "quá 10 item thì phân trang") — số câu hỏi mỗi trang ở Kho bài tập. */
    public const QUESTIONS_PER_PAGE = 10;

    /**
     * @param  array  $filters  SỬA 8/9 (3) ("phân loại kho câu hỏi theo môn") — bộ lọc của tab
     *                          "Câu hỏi", xem QuestionRepositoryInterface::allWithOwnerFiltered().
     *                          Tab khác bỏ qua tham số này.
     * @param int $page  SỬA 7/10 — trang hiện tại của tab Câu hỏi (QUESTIONS_PER_PAGE câu/trang).
     * @return array{tab: string, tabs: array, rows: array, total: int, documents: array}
     */
    /** SỬA 27/10 — chuỗi so khớp ô tìm đề: chữ thường, bỏ dấu tiếng Việt (đ → d), gộp khoảng trắng. */
    private static function searchKey(string $text): string
    {
        $t = mb_strtolower(trim($text));
        $t = Str::ascii(str_replace('đ', 'd', $t));

        return (string) preg_replace('/\s+/', ' ', $t);
    }

    public function indexData(string $tab, array $filters = [], int $page = 1): array
    {
        $counts = [
            // SỬA 31/8 — đếm đúng số lượng hiện ở tab "Câu hỏi (Kho chung + Giáo viên)":
            // loại các câu hỏi là "bài tập đính kèm sản phẩm" (product_id khác null, quản lý
            // riêng ở trang Sản phẩm), khớp với allLatestWithOwner() bên dưới.
            'questions' => $this->questions->query()->whereNull('product_id')->count(),
            // SỬA 3/11 — "Bài phổ thông" hiện ở tab Bài chung (1 dòng / bài), không đếm vào tab Đề thi.
            'assessments' => Assessment::supportsPracticeKind()
                ? Assessment::query()->where(fn ($q) => $q->whereNull('practice_kind')->orWhere('practice_kind', '!=', Assessment::PRACTICE_KIND_GENERAL))
                    // SỬA 3/11 — nhóm mã đề chỉ đếm ĐỀ GỐC (các mã con hiện trong ô "Mã đề" của đề gốc).
                    ->when(\App\Services\ExamVariantService::ready(), fn ($q) => $q->whereNull('variant_of_id'))
                    ->count()
                : $this->assessments->count(),
            'drafts' => $this->draftQuestions->countPendingReview(),
            // SỬA 19/8 (Giai đoạn 6): xem nhánh $tab === 'tags' bên dưới.
            'tags' => $this->tags->count(),
        ];

        // SỬA 26/8 ("gộp Học liệu vào Sản phẩm & quyền"): tab "Học liệu" đã bỏ khỏi đây —
        // thêm/sửa/xoá học liệu giờ làm ngay trong trang chi tiết từng sản phẩm (admin
        // Sản phẩm & quyền), xem ProductService::showData()/buildMaterialsTree(). Link cũ
        // ?tab=materials được ContentController::index() tự đưa về tab mặc định bên dưới.
        // SỬA 7/10 (khách: "tách thành 2 tab câu hỏi đã dùng trong đề và câu hỏi chưa dùng trong
        // đề") — tab "Câu hỏi" cũ tách đôi theo việc câu đã nằm trong đề nào chưa. Hai tab dùng
        // chung tab=questions, phân biệt bằng in_exam (xem ContentController::index()).
        // SỬA 9/10 (khách: "chuyển tab Bài chung lên đầu") — tab đầu tiên là "Bài chung" nên đây cũng là mặc định.
        $inExamTab = ($filters['in_exam'] ?? 'unused') === 'used' ? 'used' : 'unused';
        $usedCount = $this->questions->countAllFiltered(['in_exam' => 'used']);
        // SỬA 3/11 (khách: "Bài chung phải là 367") — tính cả "Bài phổ thông" (mỗi bài = 1) vào tab Bài chung.
        $generalSetSubjects = \App\Services\GeneralSetBankService::countsBySubject();
        $generalSetTotal = array_sum($generalSetSubjects);
        $unusedCount = $this->questions->countAllFiltered(['in_exam' => 'unused']) + $generalSetTotal;
        $tabs = [
            ['label' => 'Bài chung', 'href' => route('admin.content.index', ['tab' => 'questions', 'in_exam' => 'unused']), 'active' => $tab === 'questions' && $inExamTab === 'unused', 'count' => $unusedCount],
            ['label' => 'Bài của đề', 'href' => route('admin.content.index', ['tab' => 'questions', 'in_exam' => 'used']), 'active' => $tab === 'questions' && $inExamTab === 'used', 'count' => $usedCount],
            // SỬA 27/10 (khách: "thêm tab Bài của tài liệu: bài tập của sách, chuyên đề, bộ đề") — dữ liệu & bộ lọc ở
            // App\Services\Admin\MaterialExerciseIndexService (ContentController::index() ghép vào khi mở tab này).
            ['label' => 'Bài của tài liệu', 'href' => route('admin.content.index', ['tab' => 'material_exercises']), 'active' => $tab === 'material_exercises', 'count' => rescue(fn () => app(\App\Services\Admin\MaterialExerciseIndexService::class)->count(), null)],
            ['label' => 'Đề thi', 'href' => route('admin.content.index', ['tab' => 'assessments']), 'active' => $tab === 'assessments', 'count' => $counts['assessments']],
            // ['label' => 'Câu hỏi chờ rà soát (OCR)', 'href' => route('admin.content.index', ['tab' => 'drafts']), 'active' => $tab === 'drafts', 'count' => $counts['drafts']],
            ['label' => 'Tag/Chuyên đề', 'href' => route('admin.content.index', ['tab' => 'tags']), 'active' => $tab === 'tags', 'count' => $counts['tags']],
        ];

        $documents = [];
        $rows = [];
        $tags = [];
        $pagination = null;
        if ($tab === 'questions') {
            // Admin xem được toàn bộ câu hỏi — cả Kho chung lẫn kho riêng từng giáo viên
            // (chỉ xem để nắm tình hình; ranh giới sở hữu/sửa vẫn theo 6.5, giống cách
            // tab "Đề/bộ bài" đã hiển thị cả đề của giáo viên bên dưới).
            // SỬA 8/9 (3) ("phân loại kho câu hỏi theo môn") — trước đây đổ phẳng 50 câu mới
            // nhất, không lọc không tìm; giờ đi qua allWithOwnerFiltered() với bộ lọc Môn/Khối/
            // Dạng/Trạng thái + ô tìm theo tên hoặc mã. Giới hạn nâng 50 -> 100 vì đã có bộ lọc
            // để thu hẹp (vẫn là giới hạn cứng, chưa phân trang thật — xem x-pagination-note).
            //
            // SỬA 7/10 (khách: "quá 10 item thì phân trang") — PHÂN TRANG THẬT, 10 câu/trang, thay
            // cho giới hạn cứng 100 câu (câu thứ 101 trở đi trước giờ không cách nào nhìn thấy).
            // Đếm trước để chặn $page vượt trang cuối — vd đang ở trang 3, xoá nốt câu cuối của
            // trang đó rồi quay lại: trang 3 không còn, phải rơi về trang 2 chứ không hiện bảng rỗng.
            $filteredTotal = $this->questions->countAllFiltered($filters);
            $perPage = self::QUESTIONS_PER_PAGE;
            $lastPage = max(1, (int) ceil($filteredTotal / $perPage));
            $page = min(max(1, $page), $lastPage);
            $pagination = ['page' => $page, 'perPage' => $perPage, 'lastPage' => $lastPage, 'total' => $filteredTotal];

            // SỬA 7/10 — câu đứng NGAY TRƯỚC câu đầu trang này (ở trang trước), để nút "Đưa lên
            // trước" của dòng đầu trang 2+ biết phải chen lên trước câu nào.
            $leadPrev = $page > 1
                ? $this->questions->allWithOwnerFiltered($filters, 1, ($page - 1) * $perPage - 1, true)->first()
                : null;
            $leadPrevId = $leadPrev?->id;
            $leadPrevType = $leadPrev?->type->value;

            // SỬA 10/10 — câu đứng NGAY SAU câu cuối trang này (ở trang sau), để nút "Đưa xuống dưới" của dòng cuối trang biết đảo với câu nào.
            $leadNext = $page < $lastPage
                ? $this->questions->allWithOwnerFiltered($filters, 1, $page * $perPage, true)->first()
                : null;
            $leadNextId = $leadNext?->id;
            $leadNextType = $leadNext?->type->value;

            // SỬA 3/11 (khách: "chuyển trang / lọc chậm") — chỉ nạp cột nhẹ (không kéo grading_config chứa bộ test), xem QuestionRepository.
            $pageQuestions = $this->questions->allWithOwnerFiltered($filters, $perPage, ($page - 1) * $perPage, true);
            // SỬA 12/11 (khách: "thêm 1 cột Tag chuyên đề, hiển thị ra trang danh sách") — nạp tag 1 lần cho cả trang (không N+1).
            if ($pageQuestions instanceof \Illuminate\Database\Eloquent\Collection) {
                $pageQuestions->loadMissing('tags');
            }
            $rows = $pageQuestions->map(function ($q) {
                [$label, $tone] = $this->statusLabel($q->status);

                return [
                    'id' => $q->id,
                    'title' => $q->title,
                    'code' => $q->code,
                    'subject' => $q->subjectLabel(),
                    'grade' => $q->gradeLabel(),
                    // SỬA 1/10 — hiện luôn Tỉnh thành/Năm trên bảng để nhìn là kiểm chứng được
                    // ngay 2 ô lọc mới (giống lý do đã hiện Độ khó từ 18/9).
                    'province' => $q->provinceLabel(),
                    'examYear' => $q->examYearLabel(),
                    // SỬA 18/9 — hiện luôn Độ khó để nhìn bảng là kiểm chứng được ngay bộ lọc mới.
                    // 'difficultySet' = false: chưa ai đặt, đang SUY theo điểm (view hiện mờ đi).
                    'difficulty' => QuestionDifficulty::label(QuestionDifficulty::resolve($q->metadata, (int) $q->points)),
                    'difficultySet' => QuestionDifficulty::stored($q->metadata) !== null,
                    // SỬA 28/10 — cột Input/Output (null = không phải câu Lập trình).
                    'io' => $q->ioInfo(),
                    // SỬA 12/11 — cột Tag chuyên đề.
                    'tags' => $q->relationLoaded('tags')
                        ? $q->tags->sortBy('name')->map(fn ($t) => ['name' => (string) $t->name, 'kind' => $t->kind ?? null])->values()->all()
                        : [],
                    'type' => self::QUESTION_TYPE_LABELS[$q->type->value] ?? $q->type->value,
                    'status' => $label,
                    'tone' => $tone,
                    'owner' => $q->owner_type === OwnerType::Shared ? 'Kho chung' : ('GV '.($q->owner->name ?? '')),
                    // SỬA 23/9 — loại nội dung của dòng này, để link "Xem" trỏ đúng bảng.
                    'kind' => 'question',
                    // SỬA 30/9 (khách: "thêm nút sửa bên này nữa cho tiện sửa câu hỏi") — trước
                    // đây muốn sửa phải bấm "Xem" rồi tìm nút Sửa trong trang chi tiết.
                    'editHref' => route('admin.content.questions.edit', $q->id),
                    // SỬA 7/10 (khách: "hiển thị cột thứ tự hiển thị ra ngoài danh sách, sửa trực tiếp
                    // trên từng dòng") — số thứ tự hiện tại + địa chỉ lưu nhanh (PATCH, trả JSON).
                    'typeValue' => $q->type->value,
                    'displayOrder' => (int) $q->display_order,
                    'orderHref' => route('admin.content.questions.displayOrder', $q->id),
                    // SỬA 4/10 — nút Xoá trên từng dòng. Bày cho mọi dòng; việc có xoá được hay
                    // không do questionDestroy() quyết ở phía máy chủ (đã có người làm / đang nằm
                    // trong đề thì từ chối kèm lý do). Ẩn nút theo điều kiện thì phải đếm
                    // attempt_answers cho cả 100 dòng — 100 truy vấn cho một cái nút.
                    'canDelete' => true,
                    'deleteHref' => route('admin.content.questions.destroy', $q->id),
                    'deleteLabel' => 'Xoá vĩnh viễn câu hỏi này cùng MỌI dữ liệu liên quan: bài làm của học sinh, câu trong các đề, bài mẫu và tệp đính kèm (đề bài, lời giải, audio, ảnh)? Điểm các lượt làm cũ và tổng điểm đề sẽ bị trừ tương ứng. Không thể khôi phục.',
                ];
            })->all();

            // Tổng khớp bộ lọc ($filteredTotal, đã đếm ở đầu nhánh) khác $counts['questions'] = tổng toàn kho.
        } elseif ($tab === 'assessments') {
            // SỬA 8/10 (khách: "phân trang đầy đủ cho từng tab, quá 10 item thì phân trang") — nâng giới hạn cứng 50 -> 500
            // để tab Đề thi có đủ dòng cho phần chia trang (10 đề/trang, chia ngay trên view). Không đổi thứ tự/nội dung dòng.
            // SỬA 3/11 (khách: "danh sách ngoài chỉ hiện 1 đề gốc, các mã gắn vào thì xem/sửa trong ô Mã đề") — số mã của từng đề gốc.
            $vxReady = \App\Services\ExamVariantService::ready();
            $vxCounts = $vxReady
                ? Assessment::query()->whereNotNull('variant_of_id')->groupBy('variant_of_id')->selectRaw('variant_of_id, COUNT(*) as n')->pluck('n', 'variant_of_id')->all()
                : [];
            $rows = $this->assessments->latestWithCreator(500)->reject(fn ($a) => $a->isGeneralSet())->values()->map(function ($a) use ($vxReady, $vxCounts) { // SỬA 3/11 — bỏ "Bài phổ thông"
                [$label, $tone] = $this->statusLabel($a->status);
                $isTeacherOwned = $a->owner_type !== OwnerType::Shared;

                return [
                    'id' => $a->id, 'title' => $a->title, 'type' => $a->type->label(), 'status' => $label, 'tone' => $tone,
                    'owner' => $isTeacherOwned ? 'GV '.($a->creator->name ?? '') : 'Kho chung',
                    // SỬA 19/8 (Giai đoạn 4 — "Admin duyệt đưa đề GV ra kho chung"): chỉ đề
                    // của giáo viên mới cần nút duyệt — đề đã ở Kho chung thì không có gì để
                    // duyệt thêm (xem assessmentPromoteToShared() bên dưới + nút bấm ở
                    // admin/content/index.blade.php).
                    'canPromoteToShared' => $isTeacherOwned,
                    'kind' => 'assessment',
                    // SỬA 30/9 — nút Sửa ngay trên bảng, cùng lý do với dòng câu hỏi ở trên.
                    'editHref' => route('admin.content.assessments.edit', $a->id),
                    'canDelete' => true,
                    'deleteHref' => route('admin.content.assessments.destroy', $a->id),
                    // SỬA 3/11 — nhóm mã đề: số mã của đề gốc (0 = đề lẻ) / đề này là mã con của đề gốc nào.
                    'variantCount' => isset($vxCounts[$a->id]) ? (int) $vxCounts[$a->id] + 1 : 0,
                    'variantOf' => $vxReady && $a->variant_of_id ? (int) $a->variant_of_id : null,
                    'variantCode' => $vxReady ? $a->variant_code : null,
                    // SỬA 3/11 (khách: "xoá đề là xoá luôn câu hỏi trong đề và mọi file") — xem assessmentDestroyWithContent().
                    'deleteLabel' => 'Xoá vĩnh viễn đề này cùng TOÀN BỘ câu hỏi trong đề (kèm đề bài, lời giải, ảnh, bộ test), file PDF, ảnh bìa và mọi lượt làm của học sinh? Câu nào còn nằm trong đề khác thì giữ lại. Không thể khôi phục.',
                ];
            })->all();

            // SỬA 27/10 (khách: "thêm tìm kiếm theo tên đề thi") — lọc theo tên đề, không phân biệt hoa/thường và
            // có dấu/không dấu ("hung yen" vẫn ra "HƯNG YÊN"). Lọc trên danh sách đã lấy (tối đa 500 đề) nên không đổi truy vấn.
            if (($kw = self::searchKey((string) ($filters['q'] ?? ''))) !== '') {
                $rows = array_values(array_filter($rows, fn ($r) => str_contains(self::searchKey((string) $r['title']), $kw)));
            } else {
                // SỬA 3/11 — không tìm kiếm thì chỉ hiện ĐỀ GỐC của mỗi nhóm mã đề (tìm theo tên thì vẫn ra cả mã con).
                $rows = array_values(array_filter($rows, fn ($r) => empty($r['variantOf'])));
            }
        } elseif ($tab === 'drafts') {
            $documents = $this->pendingDocuments();
        } elseif ($tab === 'material_exercises') {
            // SỬA 27/10 — tab "Bài của tài liệu": dữ liệu do MaterialExerciseIndexService dựng (ContentController::index()).
        } elseif ($tab === 'tags') {
            // SỬA 19/8 (Giai đoạn 6) — withCount('questions') để hiện rõ tag nào đang được
            // dùng cho bao nhiêu câu hỏi trước khi admin lỡ tay xoá (xem tagDestroy() bên dưới,
            // xoá KHÔNG chặn dù đang dùng — chỉ là nhãn, không phải nội dung theo 6.2).
            $tags = $this->tags->query()->withCount('questions')->orderBy('name')->get()
                ->map(fn (Tag $t) => ['id' => $t->id, 'name' => $t->name, 'questionsCount' => $t->questions_count, 'kind' => $t->kind, 'kindLabel' => $t->kindLabel()])
                ->all();
        } else {
            $rows = $this->materials->latestWithProduct(50)->map(function ($m) {
                [$label, $tone] = $this->statusLabel($m->status);

                // SỬA 25/8 (7) — "thêm tính năng xóa cho admin": chỉ tab Học liệu mới có nút
                // Xoá (khách xác nhận phạm vi CHỈ Học liệu, không áp dụng Câu hỏi/Đề/Tag) —
                // xem materialDelete() bên dưới + nút bấm ở admin/content/index.blade.php.
                return ['id' => $m->id, 'title' => $m->title, 'type' => self::MATERIAL_TYPE_LABELS[$m->type] ?? $m->type, 'status' => $label, 'tone' => $tone, 'owner' => $m->product?->owner_type === OwnerType::Teacher ? 'Giáo viên' : 'Kho chung', 'canDelete' => true, 'kind' => 'material', 'editHref' => route('admin.content.materials.edit', $m->id),
                    'deleteHref' => route('admin.content.materials.destroy', $m->id),
                    'deleteLabel' => 'Xoá vĩnh viễn học liệu này cùng toàn bộ bài con và file PDF liên quan? Không thể khôi phục.'];
            })->all();
        }

        return [
            'tab' => $tab,
            'tabs' => $tabs,
            'rows' => $rows,
            // SỬA 7/10 — chỉ có ở tab Câu hỏi (null ở các tab khác): trang hiện tại / tổng số trang.
            'pagination' => $pagination,
            // SỬA 7/10 — số thứ tự LỚN NHẤT toàn kho: nút "Đưa lên đầu" và nhãn "Đang ở đầu".
            'orderMax' => $tab === 'questions' ? $this->displayOrderMax() : 0,
            'leadPrevId' => $leadPrevId ?? null,
            'leadPrevType' => $leadPrevType ?? null,
            'leadNextId' => $leadNextId ?? null,
            'leadNextType' => $leadNextType ?? null,
            'documents' => $documents,
            'tags' => $tags,
            'total' => match (true) {
                $tab === 'drafts' => count($documents),
                // SỬA 8/9 (3) — tab Câu hỏi hiện tổng ĐÃ LỌC, không phải tổng toàn kho.
                $tab === 'questions' => $filteredTotal ?? count($rows),
                $tab === 'assessments' && ! empty($filters['q']) => count($rows),
                default => $counts[$tab] ?? count($rows),
            },
            // SỬA 8/9 (3) — dữ liệu dựng thanh bộ lọc ở admin/content/index.blade.php.
            'filters' => [
                'subject' => $filters['subject'] ?? null,
                'grade' => $filters['grade'] ?? null,
                // SỬA 1/10 — 2 ô lọc mới, xem QuestionRepository::applyQuestionBankFilters().
                'province' => $filters['province'] ?? null,
                'exam_year' => $filters['exam_year'] ?? null,
                'type' => $filters['type'] ?? null,
                'io' => $filters['io'] ?? null,
                'status' => $filters['status'] ?? null,
                // SỬA 18/9 — ô lọc Độ khó mới, xem QuestionRepository::applyDifficultyFilter().
                'difficulty' => $filters['difficulty'] ?? null,
                // SỬA 30/9 — ô lọc Chuyên đề (tag), xem applyQuestionBankFilters().
                'tag' => $filters['tag'] ?? null,
                // SỬA 4/10 — ô lọc "Dùng trong đề", xem applyQuestionBankFilters().
                'in_exam' => $inExamTab,
                'q' => $filters['q'] ?? null,
            ],
            'subjectOptions' => $tab === 'questions' ? SubjectCatalog::SUBJECTS : [],
            'gradeOptions' => $tab === 'questions' ? SubjectCatalog::GRADES : [],
            // SỬA 1/10 — nguồn cho 2 ô lọc mới. provinceGroups chia <optgroup> (hiện hành / tên
            // cũ trước sáp nhập 2025) để danh sách 63 mục không thành một khối rối mắt.
            'provinceGroups' => $tab === 'questions' ? ProvinceCatalog::groups() : [],
            'examYearOptions' => $tab === 'questions' ? ProvinceCatalog::years() : [],
            'questionTypeOptions' => $tab === 'questions' ? self::QUESTION_TYPE_LABELS : [],
            'statusOptions' => $tab === 'questions' ? self::CONTENT_STATUS_OPTIONS : [],
            'difficultyOptions' => $tab === 'questions' ? QuestionDifficulty::LEVELS : [],
            /*
             * SỬA 4/10 — nguồn cho ô lọc "Dùng trong đề".
             *
             * ĐẶT TÊN: khách nói "câu hỏi xuất hiện trong đề / không xuất hiện trong đề". Chọn
             * chữ "Đã dùng / Chưa dùng" thay vì "xuất hiện": ngắn hơn, vừa ô lọc, và đúng việc
             * admin đang làm ở màn này — tìm câu còn rảnh để đưa vào đề, hoặc tìm câu đã nằm
             * trong đề rồi (những câu đó không xoá được, xem questionDestroy()).
             */
            'inExamOptions' => $tab === 'questions' ? [
                'used' => 'Đã dùng trong đề',
                'unused' => 'Chưa dùng trong đề',
            ] : [],
            'subjectCounts' => $tab === 'questions'
                ? \App\Services\GeneralSetBankService::addSubjectCounts($this->questions->countsBySubject(['in_exam' => $inExamTab]), $inExamTab === 'unused' ? $generalSetSubjects : [])
                : [],
            // SỬA 3/11 — số "Bài phổ thông" cộng vào chip "Tất cả dạng" / "Phổ thông" (chỉ tab Bài chung).
            'generalSetCount' => $tab === 'questions' && $inExamTab === 'unused' ? $generalSetTotal : 0,
            // SỬA 30/9 — dữ liệu cho 2 thứ mới ở thanh lọc: dải TAB theo dạng câu (kèm số
            // lượng từng dạng) và ô lọc Chuyên đề.
            'typeCounts' => $tab === 'questions' ? $this->questions->countsByType(['in_exam' => $inExamTab]) : [],
            'tagOptions' => $tab === 'questions'
                ? $this->tags->query()->orderBy('name')->pluck('name', 'id')->all()
                : [],
        ];
    }

    /**
     * admin.content.tags.store — tạo tag mới. findOrCreateByName() (không phải create() thẳng)
     * để tự khớp/không tạo trùng nếu admin lỡ gõ lại đúng tên đã có (không phân biệt hoa/
     * thường, xem TagRepository::findOrCreateByName()).
     */
    public function tagStore(string $name, ?string $kind = null): Tag
    {
        $tag = $this->tags->findOrCreateByName($name);

        // SỬA 12/11 — loại tag (Lập trình / Phổ thông). Gõ lại đúng tên tag đã có thì cập nhật luôn loại theo lựa chọn mới.
        if ($kind !== null && $tag->kind !== $kind && \Illuminate\Support\Facades\Schema::hasColumn('tags', 'kind')) {
            $tag = $this->tags->update($tag, ['kind' => $kind]);
        }

        return $tag;
    }

    /**
     * admin.content.tags.update — đổi tên tag. Ảnh hưởng NGAY tới mọi câu hỏi/bộ lọc đang
     * dùng tag này (tag chỉ là 1 nhãn dùng chung, không phải nội dung riêng của câu hỏi nào —
     * không cần tạo version mới như Question/Assessment, 6.2 không áp dụng ở đây).
     *
     * @throws ValidationException nếu tên mới trùng 1 tag KHÁC đã có sẵn.
     */
    public function tagUpdate(Tag $tag, string $name, ?string $kind = null): Tag
    {
        $name = trim($name);
        $existing = Tag::where('name', $name)->where('id', '!=', $tag->id)->first();

        if ($existing !== null) {
            throw ValidationException::withMessages(['name' => 'Đã có tag khác trùng tên này — gộp bằng cách xoá 1 trong 2 thay vì đổi tên trùng.']);
        }

        $fields = ['name' => $name];
        if ($kind !== null && \Illuminate\Support\Facades\Schema::hasColumn('tags', 'kind')) {
            $fields['kind'] = $kind; // SỬA 12/11 — sửa tag cho đổi cả loại
        }

        return $this->tags->update($tag, $fields);
    }

    /**
     * admin.content.tags.destroy — xoá hẳn (KHÔNG lưu trữ/soft-delete như Material/Question/
     * Assessment, vì tag chỉ là 1 nhãn phân loại, không phải nội dung học tập theo 6.2) —
     * cascadeOnDelete ở bảng question_tag tự gỡ tag khỏi mọi câu hỏi đang gắn, KHÔNG xoá câu
     * hỏi. Cố ý KHÔNG chặn xoá dù đang có câu hỏi dùng (khác Assessment/Material vốn chặn xoá
     * khi có phụ thuộc dữ liệu xếp hạng) — gỡ nhãn khỏi câu hỏi không làm mất/sai dữ liệu gì.
     */
    public function tagDestroy(Tag $tag): void
    {
        $this->tags->delete($tag);
    }

    /**
     * admin.content.questions.reviewDraft — nhận ?document=<id>; nếu không có thì lấy
     * tài liệu "cần rà soát" gần nhất TRÊN TOÀN "Kho chung" (không giới hạn theo người
     * tải lên — khác Teacher). Trả đủ dữ liệu để màn rà soát sửa/gộp/xóa/thêm tay và
     * chuyển vào Kho chung.
     */
    public function reviewDraftFor(?int $documentId): array
    {
        $document = null;
        if ($documentId !== null) {
            $document = $this->uploadedDocuments->query()->find($documentId);
        }
        $document ??= $this->uploadedDocuments->query()
            ->where('status', UploadedDocumentStatus::NeedsReview)
            ->latest()
            ->first();

        $drafts = [];
        if ($document) {
            $allDrafts = $document->draftQuestions()->where('review_status', '!=', 'discarded')->orderBy('order')->get();

            $drafts = $allDrafts->values()->map(function ($d) use ($allDrafts) {
                $confidenceLabel = match ($d->confidence) {
                    'high' => 'Cao',
                    'medium' => 'Trung bình',
                    'low' => 'Thấp — cần kiểm tra kỹ',
                    default => 'Chưa rõ',
                };
                $tone = match ($d->confidence) {
                    'high' => 'success',
                    'medium' => 'warning',
                    'low' => 'danger',
                    default => 'neutral',
                };

                $s = $d->structured_draft ?? [];
                $type = $d->type_guess instanceof \App\Enums\QuestionType ? $d->type_guess->value : $d->type_guess;

                return [
                    'id' => $d->id,
                    'no' => $d->order + 1,
                    'type' => $type,
                    'confidence' => $confidenceLabel,
                    'tone' => $tone,
                    'flagged' => $d->needsManualReview(),
                    'promoted' => $d->promoted_question_id !== null,
                    'title' => $s['title'] ?? ($d->raw_text ? mb_substr($d->raw_text, 0, 160) : '(chưa có nội dung)'),
                    'body' => $s['body'] ?? $d->raw_text ?? '',
                    'points' => $s['points'] ?? 1,
                    'options' => $s['options'] ?? ['', '', '', ''],
                    'correctOption' => $s['correct_option'] ?? null,
                    'acceptedAnswers' => $s['accepted_answers'] ?? '',
                    'caseSensitive' => $s['case_sensitive'] ?? false,
                    'testCases' => $s['test_cases'] ?? '',
                    'timeLimitMs' => $s['time_limit_ms'] ?? 1000,
                    'memoryLimitMb' => $s['memory_limit_mb'] ?? 256,
                    'otherDrafts' => $allDrafts->reject(fn ($other) => $other->id === $d->id || $other->promoted_question_id !== null)
                        ->map(fn ($other) => ['id' => $other->id, 'label' => 'Câu '.($other->order + 1)])
                        ->values()->all(),
                ];
            })->all();
        }

        return ['document' => $document, 'drafts' => $drafts];
    }

    /**
     * admin.content.show dùng chung MỘT route cho cả 3 loại nội dung (Material/Question/
     * Assessment) — route chỉ nhận int $content, không có route-model-binding theo loại vì
     * mỗi tab ở admin.content.index đều trỏ "Xem" vào cùng route với id riêng của loại đó.
     * Ta không thể biết chắc id thuộc loại nào chỉ từ con số (hạn chế thiết kế route có sẵn,
     * không sửa route ở đây) nên tra cứu tuần tự Material -> Question -> Assessment.
     *
     * QuestionPublishGuard::canPublish() chỉ áp dụng cho Question (6.2/6.4 quy định điều kiện
     * phát hành CÂU HỎI). Material và Assessment không đi qua guard này — không có quy tắc
     * publish tương ứng nào được đặc tả cho 2 loại đó, nên $publishErrors luôn ræủ ġ{ 2
     * nhánh đó thay vì ép một Material/Assessment qua guard nhận Question làm tham số.
     *
     * @return array{type: string, typeLabel: string, model: mixed, item: array, publishErrors: array, hasBeenAttempted: bool}
     */
    public function showData(int $id, ?string $kind = null): array
    {
        /*
         * SỬA 23/9 (khách: "thêm xong bấm Xem nó lại ra trang khác, sai rồi") — LỖI THẬT:
         * route admin.content.show dùng CHUNG cho 3 loại nội dung (Học liệu / Câu hỏi / Đề) mà
         * chỉ nhận mỗi con số id, nên hàm này phải ĐOÁN: dò bảng materials trước, rồi questions,
         * cuối cùng mới tới assessments. Ba bảng đánh id riêng nên id trùng nhau là chuyện
         * thường — bấm "Xem" đề số 1 lại ra câu hỏi số 1, đúng như khách gặp.
         *
         * Giờ nơi gọi truyền kèm $kind ('material' | 'question' | 'assessment') để tra đúng một
         * bảng, hết đoán. Vẫn giữ nhánh đoán cũ khi $kind rỗng để link cũ (bookmark, thông báo)
         * không gãy.
         */
        if ($kind === 'question') {
            return $this->showQuestionData($id) ?? $this->showNotFoundData($id);
        }

        if ($kind === 'assessment') {
            return $this->showAssessmentData($id) ?? $this->showNotFoundData($id);
        }

        if ($kind === 'material') {
            return $this->showMaterialData($id) ?? $this->showNotFoundData($id);
        }

        return $this->showMaterialData($id)
            ?? $this->showQuestionData($id)
            ?? $this->showAssessmentData($id)
            ?? $this->showNotFoundData($id);
    }

    /** @return array<string, mixed>|null */
    private function showMaterialData(int $id): ?array
    {
        $material = $this->materials->findWithProduct($id);
        if ($material !== null) {
            [$label, $tone] = $this->statusLabel($material->status);

            return [
                'type' => 'material',
                'typeLabel' => self::TYPE_LABELS['material'],
                'model' => $material,
                'item' => ['id' => $material->id, 'title' => $material->title, 'status' => $label, 'tone' => $tone, 'statusValue' => $material->status->value],
                'publishErrors' => [],
                'hasBeenAttempted' => false,
            ];
        }

        return null;
    }

    /** @return array<string, mixed>|null */
    private function showQuestionData(int $id): ?array
    {
        /** @var Question|null $question */
        $question = $this->questions->query()->with('bank')->find($id);
        if ($question !== null) {
            [$label, $tone] = $this->statusLabel($question->status);
            $decision = $this->publishGuard->canPublish($question);

            return [
                'type' => 'question',
                'typeLabel' => self::TYPE_LABELS['question'],
                'model' => $question,
                'item' => ['id' => $question->id, 'title' => $question->title, 'status' => $label, 'tone' => $tone, 'statusValue' => $question->status->value],
                'publishErrors' => $decision->allowed ? [] : [$decision->message ?? 'Chưa đủ điều kiện phát hành.'],
                'hasBeenAttempted' => $this->publishGuard->requiresNewVersion($question),
            ];
        }

        return null;
    }

    /** @return array<string, mixed>|null */
    /**
     * SỬA 20/10 (khách: "chỗ đề thi cũng add từng câu hỏi vô như luyện tập") — Đề thi / Luyện tập còn ở chế độ PDF (tạo
     * trước khi Đề thi chuyển sang câu hỏi rời) mà CHƯA có gì của đề PDF (0 câu đáp án, 0 bài lập trình) và chưa ai làm thì
     * tự chuyển sang câu hỏi rời khi mở trang chi tiết, để thêm câu như Luyện tập. Đề PDF đã có đáp án / bài lập trình /
     * lượt làm thì GIỮ NGUYÊN (không mất dữ liệu). Tệp PDF đã tải vẫn nằm nguyên trên đề, không bị xoá.
     */
    private function convertEmptyPdfToQuestions(Assessment $assessment): void
    {
        $type = $assessment->type?->value ?? $assessment->type;
        if (! $assessment->isPdfMode() || ! in_array($type, [AssessmentType::Practice->value, AssessmentType::Exam->value], true)) {
            return;
        }
        if ($assessment->answerKeys->isNotEmpty() || $assessment->codingItems->isNotEmpty() || $assessment->attempts()->exists()) {
            return;
        }

        $assessment->forceFill(['content_mode' => AssessmentContentMode::Structured->value])->save();
    }

    private function showAssessmentData(int $id): ?array
    {
        // SỬA 18/8: thêm eager-load items.question — trước đây chỉ load 'creator', nên màn
        // show.blade.php không có gì để hiện danh sách câu hỏi trong đề (chỉ hiện được TODO).
        // SỬA 18/8 (2, đề PDF): thêm eager-load answerKeys/codingItems.testCases — chỉ có dữ
        // liệu khi content_mode = pdf_answer_sheet, rỗng (không lỗi) khi content_mode = structured.
        $assessment = $this->assessments->query()
            ->with(['creator', 'items.question', 'answerKeys', 'codingItems.testCases'])
            ->find($id);
        if ($assessment !== null) {
            $this->convertEmptyPdfToQuestions($assessment);
            [$label, $tone] = $this->statusLabel($assessment->status);

            $publishErrors = [];
            if ($assessment->isPdfMode()) {
                $decision = $this->pdfAssessmentGuard->canPublish($assessment);
                $publishErrors = $decision->allowed ? [] : [$decision->message ?? 'Chưa đủ điều kiện phát hành.'];
            }

            return [
                'type' => 'assessment',
                'typeLabel' => self::TYPE_LABELS['assessment'],
                'model' => $assessment,
                'item' => ['id' => $assessment->id, 'title' => $assessment->title, 'status' => $label, 'tone' => $tone, 'statusValue' => $assessment->status->value],
                'publishErrors' => $publishErrors,
                'hasBeenAttempted' => false,
            ];
        }

        return null;
    }

    /** @return array<string, mixed> */
    private function showNotFoundData(int $id): array
    {
        return [
            'type' => null,
            'typeLabel' => '',
            'model' => null,
            'item' => ['id' => $id, 'title' => 'Không tìm thấy nội dung', 'status' => '', 'tone' => 'neutral', 'statusValue' => null],
            'publishErrors' => [],
            'hasBeenAttempted' => false,
        ];
    }

    // ================= Học liệu (Material) =================

    /**
     * SỬA 26/8 ("gộp Học liệu vào Sản phẩm & quyền") — $selectedProductId: khi bấm "+ Thêm
     * học liệu" từ NGAY trang chi tiết 1 sản phẩm (admin/products/show.blade.php), sản phẩm
     * đó được truyền qua ?product_id= để form tự điền sẵn, khỏi phải chọn lại; đồng thời danh
     * sách "mục cha" cũng chỉ còn học liệu CỦA ĐÚNG sản phẩm đó (đỡ rối vì trước đây liệt kê
     * lẫn lộn học liệu của mọi sản phẩm). Không truyền (null) thì form vẫn hoạt động y hệt cũ
     * (chọn sản phẩm từ dropdown đầy đủ) — phòng khi có người vào thẳng URL không qua sản phẩm.
     */
    /**
     * SỬA 4/9 (khách yêu cầu: "chỗ thêm file học liệu thì cho chọn chương/phần/đề") — bỏ
     * $parents cũ (mọi Material bất kỳ loại nào làm mục cha, không phân biệt sản phẩm nào khi
     * admin đổi dropdown "Thuộc sản phẩm"), thay bằng 2 mảng để JS tự lọc theo ĐÚNG sản phẩm
     * đang chọn (xem resources/views/admin/content/materials/create.blade.php):
     *  - 'chaptersByProduct': product_id => danh sách chương/phần/đề (chỉ Material type=
     *    chapter, xem Material::scopeChapters()) CỦA sản phẩm đó.
     *  - 'chapterLabelByProduct': product_id => nhãn "Chương"/"Phần"/"Đề" (null nếu sản phẩm
     *    loại Khóa học — không dùng khái niệm này, xem ProductType::chapterLabel()).
     */
    public function materialCreateFormData(?int $selectedProductId = null): array
    {
        $products = $this->products->query()->with('chapters')->orderBy('title')->get();

        return [
            'products' => $products->map(fn ($p) => ['id' => $p->id, 'title' => $p->title])->all(),
            'chaptersByProduct' => $products->mapWithKeys(fn ($p) => [
                $p->id => $p->chapters->map(fn ($c) => ['id' => $c->id, 'title' => $c->title])->values()->all(),
            ])->all(),
            'chapterLabelByProduct' => $products->mapWithKeys(fn ($p) => [$p->id => $p->chapterLabel()])->all(),
            'assessments' => $this->assessments->query()->orderBy('title')->get(['id', 'title'])->all(),
            'types' => self::MATERIAL_TYPE_LABELS,
            'statuses' => $this->statusOptions(),
            'selectedProductId' => $selectedProductId,
        ];
    }

    /**
     * SỬA 25/8 (tải bài — 16 mục "tải bài hàng loạt"): $data['code']/$data['pdf'] (UploadedFile,
     * có thể null) là 2 trường MỚI, tùy chọn — xem resolveMaterialCode()/storeMaterialPdf().
     * Vẫn tạo được Material KHÔNG có mã/PDF như trước (ví dụ Material chỉ là mục lục cha), nên
     * không phá luồng cũ.
     */
    public function materialStore(array $data): Material
    {
        $pdf = $data['pdf'] ?? null;
        $audio = $data['audio'] ?? null;
        $image = $data['image'] ?? null;
        // SỬA 4/9 — $code giờ tự sinh từ TỆP ĐẦU TIÊN có mặt trong 3 loại (không chỉ riêng
        // pdf như trước), để 1 học liệu chỉ có audio/ảnh (không có PDF) vẫn tự đặt được mã.
        $code = $this->resolveMaterialCode((int) $data['product_id'], $data['code'] ?? null, $pdf ?? $audio ?? $image);

        $attributes = [
            'product_id' => $data['product_id'],
            'parent_id' => $data['parent_id'] ?: null,
            'type' => $data['type'],
            'title' => $data['title'],
            'order' => $data['order'] ?? 0,
            'assessment_id' => $data['type'] === 'assessment_ref' ? ($data['assessment_id'] ?: null) : null,
            'status' => $data['status'],
            'code' => $code,
        ];

        if ($pdf !== null) {
            // $code chắc chắn khác null ở đây — pdf khác null thì resolveMaterialCode() luôn
            // trả về 1 mã (tự gõ hoặc tự sinh từ tên tệp), không bao giờ về nhánh "để NULL".
            $attributes = array_merge($attributes, $this->storeMaterialPdf((int) $data['product_id'], $code, $pdf));
        }

        if ($audio !== null) {
            $attributes = array_merge($attributes, $this->storeMaterialAudio((int) $data['product_id'], $code, $audio));
        }

        if ($image !== null) {
            $attributes = array_merge($attributes, $this->storeMaterialImage((int) $data['product_id'], $code, $image));
        }

        return $this->materials->create($attributes);
    }

    public function materialEditFormData(int $id): array
    {
        return array_merge($this->materialCreateFormData(), [
            'material' => $this->materials->query()->findOrFail($id),
        ]);
    }

    /**
     * SỬA 25/8: khách yêu cầu rõ "các bài cần có cơ chế sửa sau khi nhập" — mã bài và PDF ĐỀU
     * sửa lại được ở đây, không phải tải lên xong là khóa cứng:
     *  - Đổi mã: gõ mã mới vào $data['code'], assertMaterialCodeAvailable() bỏ qua CHÍNH bản ghi
     *    đang sửa (2 mục "$material->id" dưới) nên không tự báo trùng với mã cũ của chính nó.
     *  - Thay PDF: có tải $data['pdf'] mới thì XÓA file PDF cũ trên disk rồi lưu file mới — nếu
     *    không tải gì thì giữ nguyên pdf_path hiện tại (không đụng vào).
     */
    public function materialUpdate(Material $material, array $data): Material
    {
        $pdf = $data['pdf'] ?? null;
        $audio = $data['audio'] ?? null;
        $image = $data['image'] ?? null;
        $code = $this->resolveMaterialCode((int) $data['product_id'], $data['code'] ?? null, $pdf ?? $audio ?? $image, $material->id);

        $attributes = [
            'product_id' => $data['product_id'],
            'parent_id' => $data['parent_id'] ?: null,
            'type' => $data['type'],
            'title' => $data['title'],
            'order' => $data['order'] ?? 0,
            'assessment_id' => $data['type'] === 'assessment_ref' ? ($data['assessment_id'] ?: null) : null,
            'status' => $data['status'],
            'code' => $code,
        ];

        if ($pdf !== null) {
            if ($material->pdf_path) {
                Storage::disk('local')->delete($material->pdf_path);
            }

            $attributes = array_merge($attributes, $this->storeMaterialPdf((int) $data['product_id'], $code, $pdf));
        }

        if ($audio !== null) {
            if ($material->audio_path) {
                Storage::disk('local')->delete($material->audio_path);
            }

            $attributes = array_merge($attributes, $this->storeMaterialAudio((int) $data['product_id'], $code, $audio));
        }

        if ($image !== null) {
            if ($material->image_path) {
                Storage::disk('local')->delete($material->image_path);
            }

            $attributes = array_merge($attributes, $this->storeMaterialImage((int) $data['product_id'], $code, $image));
        }

        return $this->materials->update($material, $attributes);
    }

    /** Không có guard đặc thù cho Material (chỉ Question mới có điều kiện phát hành, 6.2). */
    public function materialPublish(Material $material): Material
    {
        return $this->materials->update($material, ['status' => ContentStatus::Published->value]);
    }

    /** Trả về nháp — PHẢI có lý do + audit log (10.4). */
    public function materialReject(Material $material, string $reason): Material
    {
        Material::$auditReason = $reason;
        $this->materials->update($material, ['status' => ContentStatus::Draft->value]);
        Material::$auditReason = null;

        return $material;
    }

    /** Lưu trữ — cách "gỡ khỏi lưu hành" cho nội dung (không có trạng thái xóa, Table 27). */
    public function materialArchive(Material $material, string $reason): Material
    {
        Material::$auditReason = $reason;
        $this->materials->update($material, ['status' => ContentStatus::Archived->value]);
        Material::$auditReason = null;

        return $material;
    }

    /**
     * SỬA 25/8 (7) — "thêm tính năng xóa cho admin, xóa luôn file liên quan tránh rác": XÓA
     * THẬT (khác materialArchive() ở trên — Table 27 vốn không có trạng thái "đã xóa", chỉ có
     * "lưu trữ"; khách đã được hỏi lại và xác nhận muốn xóa thật, không thể khôi phục).
     *
     * Thứ tự bắt buộc: PHẢI thu thập + xóa file PDF trên disk của material này VÀ TOÀN BỘ
     * material con cháu TRƯỚC khi xóa bản ghi — 1 khi bản ghi mất thì đường dẫn pdf_path cũng
     * mất theo, không còn cách nào dọn file nữa (đúng lo ngại "về lâu về dài nặng máy chủ" của
     * khách). materials.parent_id VÀ class_materials.material_id đều đã có cascadeOnDelete() ở
     * DB (xem migration create_materials_table/create_class_materials_table) nên chỉ cần
     * $this->materials->delete($material) là DB tự dọn sạch các bản ghi con + liên kết lớp —
     * không cần tự viết vòng lặp xóa từng bản ghi con.
     */
    public function materialDelete(Material $material): void
    {
        $ids = $this->collectMaterialAndDescendantIds($material);

        $pdfPaths = $this->materials->query()
            ->whereIn('id', $ids)
            ->whereNotNull('pdf_path')
            ->pluck('pdf_path');

        foreach ($pdfPaths as $path) {
            Storage::disk('local')->delete($path);
        }

        // SỬA 4/9 ("file học liệu có thể là audio, pdf, ảnh động... đính nhiều loại cùng
        // lúc") — dọn luôn 2 loại file mới, cùng cách với pdf_path ở trên.
        foreach (['audio_path', 'image_path'] as $column) {
            $paths = $this->materials->query()->whereIn('id', $ids)->whereNotNull($column)->pluck($column);

            foreach ($paths as $path) {
                Storage::disk('local')->delete($path);
            }
        }

        // Dọn luôn đánh giá/tổng hợp điểm mồ côi trỏ vào material sắp không còn tồn tại (9.x)
        // — không phải file, nhưng tránh để lại dữ liệu rác tham chiếu vào bản ghi đã xóa.
        Review::where('target_type', ReviewTargetType::Material->value)->whereIn('target_id', $ids)->delete();
        RatingSummary::where('target_type', ReviewTargetType::Material->value)->whereIn('target_id', $ids)->delete();

        $this->materials->delete($material);
    }

    /**
     * $material + TOÀN BỘ con cháu (đệ quy theo parent_id, không giới hạn độ sâu) — dùng để
     * biết cần xóa những file PDF nào TRƯỚC KHI cascadeOnDelete() ở DB xóa các bản ghi con.
     *
     * @return array<int, int>
     */
    private function collectMaterialAndDescendantIds(Material $material): array
    {
        $ids = [$material->id];
        $queue = [$material->id];

        while ($queue !== []) {
            $childIds = $this->materials->query()->whereIn('parent_id', $queue)->pluck('id')->all();
            if ($childIds === []) {
                break;
            }
            $ids = array_merge($ids, $childIds);
            $queue = $childIds;
        }

        return $ids;
    }

    /**
     * Xác định giá trị 'code' cuối cùng khi tạo/sửa 1 Material — DÙNG CHUNG cho materialStore()
     * và materialUpdate() (nên đổi quy tắc chỉ cần sửa 1 chỗ):
     *  - Admin tự gõ mã (khác rỗng) -> kiểm tra trùng TRONG CÙNG sản phẩm rồi dùng nguyên văn
     *    (assertMaterialCodeAvailable()).
     *  - Bỏ trống NHƯNG có tải PDF kèm -> tự sinh mã từ TÊN GỐC tệp PDF (giống cơ chế
     *    questionStoreFromZipPackage(), qua deriveUniqueMaterialCode()).
     *  - Bỏ trống VÀ không có PDF -> để NULL (Material chỉ làm mục lục/chương cha, chưa cần mã).
     *
     * $ignoreMaterialId: khi SỬA, truyền $material->id để bỏ qua CHÍNH bản ghi đang sửa lúc dò
     * trùng mã — không truyền (null) thì hiểu là đang TẠO MỚI, không có gì để bỏ qua.
     */
    private function resolveMaterialCode(int $productId, ?string $rawCode, ?UploadedFile $pdf, ?int $ignoreMaterialId = null): ?string
    {
        $code = trim((string) $rawCode);

        if ($code !== '') {
            $this->assertMaterialCodeAvailable($productId, $code, $ignoreMaterialId);

            return $code;
        }

        if ($pdf !== null) {
            return $this->deriveUniqueMaterialCode($productId, $pdf->getClientOriginalName(), $ignoreMaterialId);
        }

        return null;
    }

    /**
     * Mã bài tự sinh từ TÊN GỐC 1 tệp (PDF tải tay hoặc 1 mục trong ZIP hàng loạt) — duy nhất
     * TRONG PHẠM VI 1 sản phẩm ($productId), KHÁC deriveUniqueQuestionCode() (duy nhất TOÀN hệ
     * thống) vì 2 quyển sách/chuyên đề khác nhau được phép dùng trùng mã bài. Thuật toán dùng
     * CHUNG qua App\Support\UniqueCodeFromFilename — xem docblock lớp đó.
     */
    private function deriveUniqueMaterialCode(int $productId, string $originalFilename, ?int $ignoreMaterialId = null): string
    {
        return UniqueCodeFromFilename::generate(
            $originalFilename,
            fn (string $code) => $this->materialCodeExists($productId, $code, $ignoreMaterialId),
        );
    }

    /**
     * Ném lỗi validate nếu mã bài đã dùng TRONG CÙNG sản phẩm — chỉ gọi khi ADMIN TỰ GÕ mã
     * (nhánh tự sinh ở deriveUniqueMaterialCode() đã tự thêm hậu tố "-2", "-3"... nên không bao
     * giờ trùng, không cần assert).
     */
    private function assertMaterialCodeAvailable(int $productId, string $code, ?int $ignoreMaterialId = null): void
    {
        if ($this->materialCodeExists($productId, $code, $ignoreMaterialId)) {
            throw ValidationException::withMessages([
                'code' => "Mã bài \"{$code}\" đã được dùng trong sản phẩm này, đổi mã khác.",
            ]);
        }
    }

    private function materialCodeExists(int $productId, string $code, ?int $ignoreMaterialId = null): bool
    {
        return $this->materials->query()
            ->where('product_id', $productId)
            ->where('code', $code)
            ->when($ignoreMaterialId, fn ($q) => $q->where('id', '!=', $ignoreMaterialId))
            ->exists();
    }

    /**
     * Lưu 1 tệp PDF bài học vào disk 'local' (riêng tư — giống quy ước
     * PdfAssessmentEditingService::PDF_DISK, xem migration add_code_and_pdf_to_materials_table).
     * Đặt tên tệp theo $code (đã được resolveMaterialCode() đảm bảo duy nhất trong sản phẩm) chứ
     * không theo material->id, vì lúc TẠO MỚI chưa có id — $code thì luôn có sẵn trước khi lưu.
     *
     * @return array{pdf_path: string, pdf_original_name: string}
     */
    private function storeMaterialPdf(int $productId, string $code, UploadedFile $pdf): array
    {
        $path = "materials/{$productId}/{$code}.pdf";
        Storage::disk('local')->putFileAs("materials/{$productId}", $pdf, "{$code}.pdf");

        return ['pdf_path' => $path, 'pdf_original_name' => $pdf->getClientOriginalName()];
    }

    /**
     * SỬA 4/9 (khách yêu cầu: "file học liệu có thể là audio, pdf, ảnh động... đính nhiều
     * loại cùng lúc") — cùng cách đặt tên với storeMaterialPdf() ở trên (theo $code, không
     * theo material->id), thêm hậu tố "_audio"/"_image" để không đè lên file PDF cùng mã (1
     * Material giờ có thể có cả 3 file cùng lúc, xem materialStore()/materialUpdate()).
     *
     * @return array{audio_path: string, audio_original_name: string}
     */
    private function storeMaterialAudio(int $productId, string $code, UploadedFile $audio): array
    {
        $ext = strtolower($audio->getClientOriginalExtension()) ?: 'mp3';
        $filename = "{$code}_audio.{$ext}";
        $path = "materials/{$productId}/{$filename}";
        Storage::disk('local')->putFileAs("materials/{$productId}", $audio, $filename);

        return ['audio_path' => $path, 'audio_original_name' => $audio->getClientOriginalName()];
    }

    /** SỬA 4/9 — xem storeMaterialAudio() ở trên, cùng nguyên tắc, cho ảnh (tĩnh hoặc GIF động). */
    private function storeMaterialImage(int $productId, string $code, UploadedFile $image): array
    {
        $ext = strtolower($image->getClientOriginalExtension()) ?: 'jpg';
        $filename = "{$code}_image.{$ext}";
        $path = "materials/{$productId}/{$filename}";
        Storage::disk('local')->putFileAs("materials/{$productId}", $image, $filename);

        return ['image_path' => $path, 'image_original_name' => $image->getClientOriginalName()];
    }

    // ================= Học liệu — "tải bài hàng loạt" qua ZIP (25/8) =================
    // Khác materialsStore/Update ở trên (nhập TỪNG bài 1) — bulk tạo NHIỀU Material cùng lúc,
    // mỗi tệp .pdf ở gốc ZIP = 1 bài, mã bài lấy thẳng từ tên tệp đó (khách chốt 25/8: "đặt tên
    // các gói zip chính là mã bài"). $type/$parentId/$status áp dụng CHUNG cho cả gói — bài nào
    // cần khác thì sửa lại riêng sau qua materialsEdit (đã hỗ trợ sửa mã + thay PDF, xem
    // materialUpdate() ở trên).

    /** SỬA 26/8 ("gộp Học liệu vào Sản phẩm & quyền") — $selectedProductId: xem ghi chú ở materialCreateFormData(), áp dụng y hệt cho form tải hàng loạt này. */
    public function materialsBulkImportFormData(?int $selectedProductId = null): array
    {
        $parentsQuery = $this->materials->query()->with('product')->orderBy('product_id')->orderBy('order');
        if ($selectedProductId !== null) {
            $parentsQuery->where('product_id', $selectedProductId);
        }

        return [
            'products' => $this->products->query()->orderBy('title')->get(['id', 'title'])->all(),
            'parents' => $parentsQuery->get()
                ->map(fn ($m) => ['id' => $m->id, 'label' => ($m->product->title ?? '?').' › '.$m->title])->all(),
            // 'assessment_ref' KHÔNG có trong danh sách này — loại này chỉ để THAM CHIẾU 1
            // Assessment đã có sẵn (không có nội dung PDF riêng, xem materialStore()), không hợp
            // với luồng "mỗi tệp PDF trong ZIP = 1 bài" của bulk import.
            'types' => array_filter(self::MATERIAL_TYPE_LABELS, fn ($key) => $key !== 'assessment_ref', ARRAY_FILTER_USE_KEY),
            'statuses' => $this->statusOptions(),
            'selectedProductId' => $selectedProductId,
        ];
    }

    /**
     * admin.content.materials.bulk.store — mở gói ZIP, mỗi tệp .pdf nằm NGAY GỐC ZIP (không đọc
     * thư mục con lồng nhau, tránh đoán bừa cấu trúc nếu khách nén sai cách) tạo thành 1
     * Material mới. Tiêu đề tạm lấy từ tên tệp (bỏ đuôi .pdf) — admin sửa lại cho gọn sau nếu
     * cần, không bắt buộc đúng chuẩn ngay từ lúc nhập.
     *
     * @throws ValidationException nếu ZIP không mở được hoặc không có tệp .pdf hợp lệ nào ở gốc.
     * @return Collection<int, Material>
     */
    public function materialsBulkImportFromZip(int $productId, string $type, ?int $parentId, string $status, UploadedFile $zip): Collection
    {
        $zipArchive = new ZipArchive();
        if ($zipArchive->open($zip->getRealPath()) !== true) {
            throw ValidationException::withMessages(['zip_package' => 'Không mở được gói ZIP, kiểm tra lại tệp.']);
        }

        $pdfEntries = [];
        for ($i = 0; $i < $zipArchive->numFiles; $i++) {
            $name = $zipArchive->getNameIndex($i);
            if ($name === false || str_contains($name, '/') || strtolower(pathinfo($name, PATHINFO_EXTENSION)) !== 'pdf') {
                continue; // bỏ qua thư mục con và mọi tệp không phải .pdf nằm ngay gốc ZIP
            }

            $pdfEntries[] = $name;
        }

        if ($pdfEntries === []) {
            $zipArchive->close();

            throw ValidationException::withMessages([
                'zip_package' => 'Không tìm thấy tệp PDF nào ở gốc gói ZIP (mỗi bài = 1 tệp .pdf, tên tệp sẽ dùng làm mã bài).',
            ]);
        }

        natsort($pdfEntries);
        $pdfEntries = array_values($pdfEntries);

        $created = collect();
        foreach ($pdfEntries as $order => $name) {
            $raw = $zipArchive->getFromName($name);
            if ($raw === false) {
                continue; // không đọc được entry này (hiếm) — bỏ qua, không chặn cả gói
            }

            $code = $this->deriveUniqueMaterialCode($productId, $name);
            $path = "materials/{$productId}/{$code}.pdf";
            Storage::disk('local')->put($path, $raw);

            $created->push($this->materials->create([
                'product_id' => $productId,
                'parent_id' => $parentId,
                'type' => $type,
                'title' => pathinfo($name, PATHINFO_FILENAME),
                'order' => $order,
                'assessment_id' => null,
                'status' => $status,
                'code' => $code,
                'pdf_path' => $path,
                'pdf_original_name' => basename($name),
            ]));
        }

        $zipArchive->close();

        return $created;
    }

    // ================= Câu hỏi kho chung (Question, 6.5) =================

    public function questionCreateFormData(): array
    {
        return [
            // SỬA 31/8 (2) — loại 'composite' khỏi dropdown TẠO TAY (không có ô nhập
            // grading_config tương ứng ở form này, xem questionUpdate()) — CHỈ tạo được qua
            // nhập ZIP (content.type = "composite"). QUESTION_TYPE_LABELS đầy đủ 4 dạng vẫn
            // dùng nguyên ở indexData() để hiển thị đúng nhãn cho câu đã có.
            'types' => array_filter(self::QUESTION_TYPE_LABELS, fn ($key) => $key !== 'composite', ARRAY_FILTER_USE_KEY),
            'visibilities' => ['public' => 'Công khai', 'private' => 'Riêng tư (nội bộ)'],
            // SỬA 8/9 (3) ("phân loại kho câu hỏi theo môn") — danh mục CỐ ĐỊNH cho 2 ô Môn học/
            // Khối lớp ở form tạo & sửa, xem App\Support\SubjectCatalog.
            'subjects' => SubjectCatalog::SUBJECTS,
            'grades' => SubjectCatalog::GRADES,
            // SỬA 19/8 (Giai đoạn 6): danh sách tag có sẵn để tick chọn ở form — xem
            // resolveTagIds() (cho phép gõ thêm tag MỚI ngay trong form, không bắt buộc phải
            // sang tab "Tag/Chuyên đề" tạo trước).
            'allTags' => $this->tags->allOrderedByName(),
        ];
    }

    /**
     * admin.content.questions.store — luôn tạo vào "Kho chung" (owner_type=shared) vì admin
     * đang thao tác ở mục Nội dung CHUNG (6.5) — câu hỏi riêng của giáo viên được tạo ở
     * teacher.questions.create (owner_type=teacher), không đi qua đây.
     */
    public function questionStore(User $admin, array $data): Question
    {
        if ($this->questions->query()->where('code', $data['code'])->exists()) {
            throw ValidationException::withMessages(['code' => 'Mã câu hỏi này đã tồn tại, chọn mã khác.']);
        }

        $question = $this->questions->create([
            'bank_id' => $this->sharedBank()->id,
            'code' => $data['code'],
            'type' => $data['type'],
            'title' => $data['title'],
            // SỬA 8/9 (3) — chuẩn hoá lại qua SubjectCatalog thay vì tin thẳng input: giá trị lạ
            // (form bị sửa tay/link cũ) thành null = "Chưa phân loại", không lưu rác vào cột lọc.
            'subject' => SubjectCatalog::normalize($data['subject'] ?? null),
            'grade' => SubjectCatalog::normalizeGrades($data['grades'] ?? null, $data['grade'] ?? null),
            'body' => $data['body'] ?? null,
            // SỬA 1/10 (khách: "thêm 1 cái field nữa cho chọn tỉnh thành và năm") — chuẩn hoá
            // qua ProvinceCatalog thay vì tin thẳng input: mã lạ (form bị sửa tay/link cũ) thành
            // null = "Chưa gán", không lưu rác vào cột lọc. Giống hệt cách làm với subject/grade.
            'province' => ProvinceCatalog::normalizeForQuestion($data['province'] ?? null),
            'exam_year' => ProvinceCatalog::normalizeYear($data['exam_year'] ?? null),
            ...\App\Support\QuestionSource::attributes($data), // SỬA 10/10 — ô Nguồn
            // SỬA 1/10 (khách: "chọn cơ bản là 2 điểm… khi chọn thì nó tự active vô field điểm
            // luôn không cho nhập điểm") — ĐIỂM tính lại Ở ĐÂY từ độ khó, KHÔNG tin ô input
            // (ô readonly vẫn sửa được bằng DevTools mà điểm thì ảnh hưởng kết quả chấm).
            // Bảng quy đổi ở QuestionDifficulty::POINTS. Rơi về $data['points'] chỉ khi KHÔNG
            // chọn độ khó — giữ cho các luồng cũ (câu Composite, script) không bị về 0 điểm.
            'points' => QuestionDifficulty::pointsFor($data['difficulty'] ?? null) ?? ($data['points'] ?? 0),
            // SỬA 30/9 — độ ưu tiên hiển thị (số lớn hiện trước), xem migration
            // add_display_order_to_questions_table.
            'display_order' => (int) ($data['display_order'] ?? 0),
            'grading_config' => $this->buildGradingConfig($data['type'], $data),
            'owner_type' => OwnerType::Shared->value,
            'owner_id' => null,
            'visibility' => $data['visibility'] ?? Visibility::Public->value,
            // SỬA 18/9 — Độ khó do người tạo chọn (dễ/trung bình/khó/cực khó). Lưu vào
            // metadata.difficulty (KHÔNG thêm cột mới) vì metadata còn giữ 'assets'/'attachments'
            // của câu nhập ZIP — xem mergeDifficultyIntoMetadata() để biết vì sao phải GỘP.
            // Bỏ trống => không lưu key => trang Luyện tập public tự suy độ khó theo điểm (cũ).
            'metadata' => $this->mergeDifficultyIntoMetadata(null, $data),
            'status' => ContentStatus::Draft->value,
            'version' => 1,
            'created_by' => $admin->id,
        ]);

        $question->tags()->sync($this->resolveTagIds($data));

        // SỬA 1/10 — phải gọi SAU create() vì đường dẫn tệp lấy theo $question->id.
        $this->applyManualUploads($question, $data);

        return $question;
    }

    public function questionEditFormData(int $id): array
    {
        /** @var Question $question */
        $question = $this->questions->query()->with('tags')->findOrFail($id);

        return array_merge($this->questionCreateFormData(), [
            'question' => $question,
            'hasBeenAttempted' => $this->publishGuard->requiresNewVersion($question),
        ]);
    }

    /**
     * admin.content.questions.update — CHẶN sửa âm thầm câu đã có người làm (6.2: "Câu hỏi
     * đã có người làm — sửa nội dung phải tạo phiên bản mới"). Admin phải dùng
     * questionCreateNewVersion() thay vì gọi hàm này khi $hasBeenAttempted = true.
     */
    public function questionUpdate(Question $question, array $data): Question
    {
        // SỬA 21/9 — luật 6.2 đang TẮT (QuestionPublishGuard::VERSION_ON_EDIT) → sửa thẳng.
        if ($this->publishGuard->requiresNewVersion($question)) {
            throw ValidationException::withMessages([
                'code' => 'Câu hỏi này đã có học sinh làm bài — không thể sửa trực tiếp, hãy dùng "Tạo phiên bản mới" (6.2).',
            ]);
        }

        $attributes = [
            'code' => $data['code'],
            'title' => $data['title'],
            // SỬA 8/9 (3) — sửa lại Môn/Khối cho câu cũ (kể cả câu nhập ZIP bị đoán sai) ngay ở
            // form Sửa, không cần lệnh backfill.
            'subject' => SubjectCatalog::normalize($data['subject'] ?? null),
            'grade' => SubjectCatalog::normalizeGrades($data['grades'] ?? null, $data['grade'] ?? null),
            // SỬA 1/10 (khách: "nội dung đề bài bên chỗ cập nhật câu hỏi cũng ẩn đi") — PHẢI
            // phân biệt "form không gửi ô body" (ô đang bị ẩn -> GIỮ NGUYÊN đề bài cũ) với "form
            // gửi ô body rỗng" (người dùng CỐ Ý xoá). Trước đây dòng này là `$data['body'] ?? null`
            // nên chỉ cần ẩn ô đi là mỗi lần bấm Lưu XOÁ SẠCH đề bài của câu hỏi.
            'body' => array_key_exists('body', $data) ? $data['body'] : $question->body,
            // SỬA 1/10 (khách: "thêm 1 cái field nữa cho chọn tỉnh thành và năm") — chuẩn hoá
            // qua ProvinceCatalog thay vì tin thẳng input: mã lạ (form bị sửa tay/link cũ) thành
            // null = "Chưa gán", không lưu rác vào cột lọc. Giống hệt cách làm với subject/grade.
            'province' => ProvinceCatalog::normalizeForQuestion($data['province'] ?? null),
            'exam_year' => ProvinceCatalog::normalizeYear($data['exam_year'] ?? null),
            ...\App\Support\QuestionSource::attributes($data), // SỬA 10/10 — ô Nguồn
            // SỬA 1/10 (khách: "chọn cơ bản là 2 điểm… khi chọn thì nó tự active vô field điểm
            // luôn không cho nhập điểm") — ĐIỂM tính lại Ở ĐÂY từ độ khó, KHÔNG tin ô input
            // (ô readonly vẫn sửa được bằng DevTools mà điểm thì ảnh hưởng kết quả chấm).
            // Bảng quy đổi ở QuestionDifficulty::POINTS. Rơi về $data['points'] chỉ khi KHÔNG
            // chọn độ khó — giữ cho các luồng cũ (câu Composite, script) không bị về 0 điểm.
            'points' => QuestionDifficulty::pointsFor($data['difficulty'] ?? null) ?? ($data['points'] ?? 0),
            // SỬA 30/9 — độ ưu tiên hiển thị (số lớn hiện trước), xem migration
            // add_display_order_to_questions_table.
            'display_order' => (int) ($data['display_order'] ?? 0),
            'visibility' => $data['visibility'] ?? Visibility::Public->value,
            // SỬA 18/9 — sửa Độ khó ngay ở form Sửa. GỘP vào metadata hiện có của câu (giữ
            // nguyên 'assets'/'attachments' đã nhập từ ZIP), xem mergeDifficultyIntoMetadata().
            'metadata' => $this->mergeDifficultyIntoMetadata($question->metadata, $data),
        ];

        // SỬA 31/8 (2, "mở rộng ZIP bài tập") — câu Composite (nhiều phần/nhiều dạng con, chỉ
        // tạo qua nhập ZIP) KHÔNG có form nhập tay tương ứng ở Kho câu hỏi (form chỉ có ô cho
        // Mcq/FillBlank/Coding) — buildGradingConfig() sẽ rơi vào nhánh `default => []` và XOÁ
        // SẠCH cấu hình các phần con nếu gọi cho Composite. Giữ NGUYÊN grading_config đã nhập từ
        // ZIP, chỉ cho sửa Tiêu đề/Nội dung/Điểm/Hiển thị/Tag như các dạng khác.
        if ($question->type !== \App\Enums\QuestionType::Composite) {
            // SỬA 21/9 — ô test bị khoá (không gửi lên) thì giữ nguyên test cũ, xem buildGradingConfig().
            $data['_existing_test_cases'] = $question->grading_config['test_cases'] ?? [];
            $data['_existing_checker'] = $question->grading_config['checker'] ?? null; // SỬA 21/10 — form không có ô Cách chấm thì giữ
            $attributes['grading_config'] = $this->buildGradingConfig($question->type->value, $data);
        }

        $updated = $this->questions->update($question, $attributes);

        $updated->tags()->sync($this->resolveTagIds($data));

        // SỬA 1/10 — tệp đính kèm nhập tay. Chạy SAU update() ở trên (update() vừa ghi
        // metadata.difficulty) và tự đọc lại metadata mới nhất để 2 bước không ghi đè nhau.
        $this->applyManualUploads($updated, $data);

        return $updated;
    }

    /** Tạo bản version mới thay vì sửa âm thầm (6.2) — dùng khi câu đã có người làm. */
    public function questionCreateNewVersion(Question $question, array $data): Question
    {
        $changes = [
            'title' => $data['title'],
            // SỬA 8/9 (3) — bản version mới giữ đúng Môn/Khối đang chọn trên form (replicate()
            // đã copy giá trị cũ sang, dòng này để sửa được luôn khi tạo version mới).
            'subject' => SubjectCatalog::normalize($data['subject'] ?? null),
            'grade' => SubjectCatalog::normalizeGrades($data['grades'] ?? null, $data['grade'] ?? null),
            // SỬA 1/10 — cùng lý do ở questionUpdate(): ô body bị ẩn (không gửi lên) thì bản
            // version mới thừa hưởng đề bài của bản gốc, không bị xoá trắng.
            'body' => array_key_exists('body', $data) ? $data['body'] : $question->body,
            // SỬA 1/10 (khách: "thêm 1 cái field nữa cho chọn tỉnh thành và năm") — chuẩn hoá
            // qua ProvinceCatalog thay vì tin thẳng input: mã lạ (form bị sửa tay/link cũ) thành
            // null = "Chưa gán", không lưu rác vào cột lọc. Giống hệt cách làm với subject/grade.
            'province' => ProvinceCatalog::normalizeForQuestion($data['province'] ?? null),
            'exam_year' => ProvinceCatalog::normalizeYear($data['exam_year'] ?? null),
            ...\App\Support\QuestionSource::attributes($data), // SỬA 10/10 — ô Nguồn
            // SỬA 1/10 (khách: "chọn cơ bản là 2 điểm… khi chọn thì nó tự active vô field điểm
            // luôn không cho nhập điểm") — ĐIỂM tính lại Ở ĐÂY từ độ khó, KHÔNG tin ô input
            // (ô readonly vẫn sửa được bằng DevTools mà điểm thì ảnh hưởng kết quả chấm).
            // Bảng quy đổi ở QuestionDifficulty::POINTS. Rơi về $data['points'] chỉ khi KHÔNG
            // chọn độ khó — giữ cho các luồng cũ (câu Composite, script) không bị về 0 điểm.
            'points' => QuestionDifficulty::pointsFor($data['difficulty'] ?? null) ?? ($data['points'] ?? 0),
            // SỬA 30/9 — độ ưu tiên hiển thị (số lớn hiện trước), xem migration
            // add_display_order_to_questions_table.
            'display_order' => (int) ($data['display_order'] ?? 0),
            'visibility' => $data['visibility'] ?? Visibility::Public->value,
            // SỬA 18/9 — bản version mới giữ đúng Độ khó đang chọn trên form (replicate() đã
            // copy metadata cũ sang, gộp thêm để sửa được luôn khi tạo version mới).
            'metadata' => $this->mergeDifficultyIntoMetadata($question->metadata, $data),
        ];

        // SỬA 31/8 (2) — cùng lý do ở questionUpdate() ngay trên: KHÔNG build lại grading_config
        // cho Composite — replicate() ở createNewVersion() đã tự copy NGUYÊN grading_config gốc
        // sang bản version mới, bỏ qua key này trong $changes là đủ để giữ nguyên, không cần gọi
        // buildGradingConfig() (sẽ xoá sạch 'parts').
        if ($question->type !== \App\Enums\QuestionType::Composite) {
            // SỬA 21/9 — cùng lý do ở questionUpdate(): ô test bị khoá thì giữ nguyên test cũ.
            $data['_existing_test_cases'] = $question->grading_config['test_cases'] ?? [];
            $data['_existing_checker'] = $question->grading_config['checker'] ?? null; // SỬA 21/10 — form không có ô Cách chấm thì giữ
            $changes['grading_config'] = $this->buildGradingConfig($question->type->value, $data);
        }

        $newVersion = $this->publishGuard->createNewVersion($question, $changes);

        // Phiên bản mới giữ NGUYÊN tag của bản gốc trừ khi form gửi kèm lựa chọn tag khác —
        // đổi nội dung câu hỏi (sửa lỗi/cập nhật) hiếm khi đổi luôn chủ đề của nó.
        $newVersion->tags()->sync($this->resolveTagIds($data));

        // SỬA 1/10 — tệp mới tải lên ở form "Tạo phiên bản mới" ghi vào thư mục của BẢN MỚI
        // (questions/{idMới}/…), không dùng chung đường dẫn với bản gốc.
        $this->applyManualUploads($newVersion, $data);

        return $newVersion;
    }

    /**
     * SỬA 18/9 (khách: "tạo câu hỏi không thấy Độ khó") — ghi độ khó do người tạo CHỌN vào
     * metadata.difficulty. Phải GỘP chứ không ghi đè cả cột metadata vì metadata còn chứa
     * 'assets' (ảnh/âm thanh) và 'attachments' (PDF đề/lời giải) của câu nhập từ gói ZIP —
     * ghi đè sẽ làm mất file đính kèm (xem questionAssetDownload()/questionAttachment()).
     * Bỏ trống ô Độ khó => XOÁ key => Public\PracticeService tự suy lại theo điểm như trước,
     * chứ không kẹt ở giá trị cũ.
     *
     * @return array<string, mixed> metadata mới để lưu vào cột questions.metadata (cast array).
     */
    private function mergeDifficultyIntoMetadata(?array $current, array $data): array
    {
        $metadata = $current ?? [];
        // SỬA 30/9 — chuẩn hoá trước khi lưu: form/link đời cũ còn gửi 'medium', lưu nguyên si
        // thì DB lẫn 2 hệ khoá. normalize() quy về khoá mới cùng số sao ('fair'/Khá).
        $value = QuestionDifficulty::normalize($data['difficulty'] ?? null);

        if ($value !== null) {
            $metadata['difficulty'] = $value;
        } else {
            unset($metadata['difficulty']);
        }

        return $metadata;
    }

    /**
     * SỬA 1/10 (khách: "chỗ nhập thủ công đang thiếu vài trường… thiếu chọn file pdf") — trước
     * đây CHỈ gói ZIP mới tạo được metadata.attachments (đề/lời giải/code mẫu) và
     * metadata.assets (ảnh/âm thanh), nên câu gõ tay không bao giờ có tab "Đề bài PDF" cho học
     * sinh (xem Question::attachmentInfo() + Student\AssessmentService). Giờ form Tạo/Sửa có ô
     * chọn tệp, luồng lưu dùng LẠI đúng quy ước đường dẫn của storeZipAttachments()/
     * storeZipAssets() để 2 nguồn (ZIP và gõ tay) đọc ra như nhau, không cần sửa nơi đọc.
     *
     * GỘP chứ không ghi đè: câu nhập ZIP rồi sửa tay vẫn giữ nguyên tệp cũ nếu lần lưu này
     * không chọn tệp mới — cùng lý do ở mergeDifficultyIntoMetadata().
     */
    private function applyManualUploads(Question $question, array $data): void
    {
        $metadata = $question->metadata ?? [];
        $currentAttachments = $metadata['attachments'] ?? [];
        $currentAssets = $metadata['assets'] ?? [];

        // Đọc bytes TRƯỚC khi lưu disk để dùng lại cho việc trích đề bài bên dưới (lưu bằng
        // Storage::put() không di chuyển tệp tạm, nhưng đọc 1 lần vẫn gọn hơn đọc 2 lần).
        $statementFile = $data[self::MANUAL_ATTACHMENT_FIELDS['statement']] ?? null;
        $statementBytes = $statementFile instanceof UploadedFile ? $statementFile->get() : null;

        $attachments = $this->mergeManualAttachments($question, $data, $currentAttachments);
        $assets = $this->mergeManualAssets($question, $data, $currentAssets);

        $attributes = [];

        if ($attachments !== $currentAttachments || $assets !== $currentAssets) {
            // Không ghi khoá rỗng: nơi đọc dùng `?? []` nên mảng rỗng và không có khoá là một,
            // nhưng bỏ hẳn khoá giúp metadata của câu gõ tay không phình ra vô ích.
            if ($attachments === []) {
                unset($metadata['attachments']);
            } else {
                $metadata['attachments'] = $attachments;
            }

            if ($assets === []) {
                unset($metadata['assets']);
            } else {
                $metadata['assets'] = $assets;
            }

            $attributes['metadata'] = $metadata;
        }

        /*
         * SỬA 1/10 — BẮT BUỘC phải có, không phải tiện thêm: form TẠO đang ẩn ô "Nội dung đề
         * bài" (khách yêu cầu), nên body về null, mà QuestionPublishGuard::canPublish() chặn
         * phát hành khi body rỗng ("Thiếu toàn văn đề bài") -> mọi câu gõ tay sẽ KHÔNG BAO GIỜ
         * phát hành được. Xử lý y như luồng nhập ZIP: trích chữ thật từ tệp PDF đề bài vừa tải
         * lên làm body (placeholderBodyForZipImport() đã có sẵn, tái dùng nguyên), PDF scan
         * không có lớp chữ thì rơi về dòng ghi chú — vẫn đủ điều kiện phát hành.
         *
         * Chỉ chạy khi body đang RỖNG: câu đã có đề bài (gõ tay hoặc nhập ZIP) không bị tệp PDF
         * tải lên sau ghi đè mất nội dung.
         */
        if ($statementBytes !== null && blank($question->body)) {
            $attributes['body'] = $this->placeholderBodyForZipImport(
                ['title' => $question->title],
                ['statement' => ['content' => $statementBytes]],
            );
        }

        if ($attributes === []) {
            return;
        }

        $this->questions->update($question, $attributes);
    }

    /**
     * 3 tệp đính kèm CỐ ĐỊNH (statement/solution/reference) — cùng khoá, cùng đường dẫn
     * "questions/{id}/{kind}.{ext}" như storeZipAttachments().
     *
     * Bỏ chọn (remove_attachments[]) chỉ XOÁ KHOÁ trong metadata, KHÔNG xoá tệp trên disk: bản
     * version cũ của câu hỏi có thể đang trỏ vào đúng tệp đó (xem questionCreateNewVersion()),
     * xoá thật sẽ làm bản cũ 404.
     *
     * @param  array<string, array{path:string, filename:string}>  $current
     * @return array<string, array{path:string, filename:string}>
     */
    private function mergeManualAttachments(Question $question, array $data, array $current): array
    {
        $remove = array_map('strval', (array) ($data['remove_attachments'] ?? []));

        foreach (self::MANUAL_ATTACHMENT_FIELDS as $kind => $field) {
            if (in_array($kind, $remove, true)) {
                unset($current[$kind]);
            }

            $file = $data[$field] ?? null;

            if (! $file instanceof UploadedFile) {
                continue;
            }

            $extension = strtolower($file->getClientOriginalExtension() ?: 'bin');
            $path = "questions/{$question->id}/{$kind}.{$extension}";
            Storage::disk('local')->put($path, $file->get());

            $current[$kind] = ['path' => $path, 'filename' => $file->getClientOriginalName()];
        }

        return $current;
    }

    /**
     * Ảnh/âm thanh đính kèm (không giới hạn số lượng) — cùng cấu trúc storeZipAssets() để
     * Question::findAsset() + Student\PracticeByQuestionService đọc được không cần sửa gì.
     *
     * KHÁC gói ZIP ở 2 điểm, đã cố ý: 'kind' suy từ loại tệp (ảnh/âm thanh/video) thay vì gói
     * tự khai, và 'transcript'/'alt_text' để null vì form không có chỗ gõ cho từng tệp — cần
     * lời thoại/chú thích ảnh thì vẫn phải nhập bằng gói ZIP.
     *
     * @param  array<int, array<string, mixed>>  $current
     * @return array<int, array<string, mixed>>
     */
    private function mergeManualAssets(Question $question, array $data, array $current): array
    {
        $remove = array_map('strval', (array) ($data['remove_assets'] ?? []));

        if ($remove !== []) {
            $current = array_values(array_filter(
                $current,
                fn ($asset) => ! in_array((string) ($asset['id'] ?? ''), $remove, true)
            ));
        }

        foreach ((array) ($data['asset_files'] ?? []) as $file) {
            if (! $file instanceof UploadedFile) {
                continue;
            }

            $id = (string) Str::uuid();
            $extension = strtolower($file->getClientOriginalExtension() ?: 'bin');
            $path = "questions/{$question->id}/assets/{$id}.{$extension}";
            Storage::disk('local')->put($path, $file->get());

            $current[] = [
                'id' => $id,
                'kind' => $this->assetKindFor($file),
                'path' => $path,
                'filename' => $file->getClientOriginalName(),
                'transcript' => null,
                'alt_text' => null,
            ];
        }

        return array_values($current);
    }

    /**
     * 'kind' quyết định học sinh thấy ảnh hay nghe audio (xem Student\PracticeByQuestionService
     * + blade làm bài), nên KHÔNG tin một mình getMimeType(): nó đoán theo nội dung tệp và trả
     * về 'application/octet-stream'/'text/plain' với không ít tệp thật (đã gặp khi thử). Đoán
     * theo mime trước, không ra thì xét đuôi tên tệp — bộ luật kiểm tra ở
     * ContentController::questionUploadRules() đã chặn các loại ngoài ảnh/âm thanh từ trước.
     */
    private function assetKindFor(UploadedFile $file): string
    {
        $mime = (string) $file->getMimeType();

        foreach (['image', 'audio', 'video'] as $kind) {
            if (str_starts_with($mime, $kind.'/')) {
                return $kind;
            }
        }

        return match (strtolower($file->getClientOriginalExtension())) {
            'jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'svg' => 'image',
            'mp3', 'm4a', 'aac', 'wav', 'ogg', 'oga', 'opus', 'weba' => 'audio',
            'mp4', 'webm', 'mov', 'm4v' => 'video',
            default => 'file',
        };
    }

    /**
     * grading_config.file_io — quy ước tên tệp vào/ra cho câu Lập trình. ĐƯỢC DÙNG THẬT:
     * CodeJudgingService::withFileIo() chèn đoạn mở/đóng tệp vào mã của học sinh, nên thiếu nó
     * thì bài viết kiểu freopen("TONG.INP") chấm sai sạch.
     *
     * Form nhập tay gửi 2 ô rời 'file_io_input' / 'file_io_output'. Nhánh `$data['file_io']`
     * giữ lại cho nguồn gửi sẵn cả mảng (QuestionZipPackage::gradingConfig() dùng khoá này) —
     * lúc nhập ZIP thì grading_config build ở buildGradingConfigFromZipPackage(), KHÔNG qua đây,
     * nhưng để nhánh đó thì hàm này an toàn với mọi nơi gọi buildGradingConfig().
     * Chỉ điền 1 trong 2 ô vẫn hợp lệ — withFileIo() xử lý được riêng từng chiều.
     *
     * QUAN TRỌNG: form Sửa PHẢI điền sẵn 2 ô này từ grading_config.file_io (xem
     * edit.blade.php). Để trống rồi bấm Lưu = CỐ Ý bỏ quy ước tên tệp của câu đó.
     *
     * @return array{input?:string, output?:string}|null
     */
    private function resolveFileIo(array $data): ?array
    {
        // SỬA 10/10 (khách: "để mặc định Bàn phím / màn hình thì phải lưu cái đó, không phải lưu tệp có tên")
        // — người dùng chọn 'std' thì KHÔNG lưu tên tệp nào, dù 2 ô (đang ẩn) có chứa gì.
        if (($data['io_mode'] ?? null) === 'std') {
            return null;
        }

        if (! array_key_exists('file_io_input', $data) && ! array_key_exists('file_io_output', $data)) {
            return $data['file_io'] ?? null;
        }

        // SỬA 27/10 (khách: "tên tệp = mã bài + .INP / .OUT, gắn luôn khỏi phải nhập") — chọn "Tệp có tên" mà để trống ô nào
        // thì lấy MÃBÀI.INP / MÃBÀI.OUT (mã bài bỏ ký tự không hợp lệ cho tên tệp).
        if (($data['io_mode'] ?? null) === 'file') {
            $base = preg_replace('/[^A-Za-z0-9._-]/', '', trim((string) ($data['code'] ?? '')));
            if ($base !== '') {
                if (trim((string) ($data['file_io_input'] ?? '')) === '') {
                    $data['file_io_input'] = $base.'.INP';
                }
                if (trim((string) ($data['file_io_output'] ?? '')) === '') {
                    $data['file_io_output'] = $base.'.OUT';
                }
            }
        }

        $io = array_filter([
            'input' => trim((string) ($data['file_io_input'] ?? '')),
            'output' => trim((string) ($data['file_io_output'] ?? '')),
        ], fn ($v) => $v !== '');

        return $io === [] ? null : $io;
    }

    /**
     * SỬA 19/8 (Giai đoạn 6) — gộp 2 nguồn tag từ form: (1) 'tag_ids' — các tag CÓ SẴN được
     * tick chọn; (2) 'new_tags' — chuỗi tên tag MỚI cách nhau bằng dấu phẩy, gõ trực tiếp
     * ngay trong form (không bắt buộc phải sang tab "Tag/Chuyên đề" tạo trước rồi quay lại).
     * findOrCreateByName() tự khớp nếu trùng tên tag đã có (không phân biệt hoa/thường) —
     * tránh tự sinh tag gần trùng chỉ vì gõ khác cách viết hoa/thường.
     *
     * @return array<int> danh sách tag_id cuối cùng để sync() vào câu hỏi.
     */
    private function resolveTagIds(array $data): array
    {
        $tagIds = array_map('intval', $data['tag_ids'] ?? []);

        $newNames = array_filter(array_map('trim', explode(',', (string) ($data['new_tags'] ?? ''))), fn ($n) => $n !== '');

        foreach ($newNames as $name) {
            $tagIds[] = $this->tags->findOrCreateByName($name)->id;
        }

        return array_values(array_unique($tagIds));
    }

    /**
     * Dựng grading_config đúng cấu trúc tối thiểu theo từng loại câu (6.1/6.2) từ input có
     * cấu trúc trên form — KHÔNG bắt admin tự viết JSON tay (dễ sai, khó kiểm tra lỗi rõ).
     * Test case coding dùng định dạng đơn giản "input|||output" mỗi dòng — cố ý CHƯA làm
     * trình tải file test/kéo-thả (phạm vi lớn hơn nhiều, để dành cho màn hình OJ chuyên biệt
     * sau này) — vẫn đủ để QuestionPublishGuard::hasMinimumGradingConfig() nhận đúng cấu trúc.
     */
    private function buildGradingConfig(string $type, array $data): array
    {
        return match ($type) {
            'mcq' => [
                'options' => array_values(array_filter($data['options'] ?? [], fn ($o) => filled($o))),
                'correct_options' => isset($data['correct_option']) && $data['correct_option'] !== ''
                    ? [(int) $data['correct_option']]
                    : [],
            ],
            'fill_blank' => [
                'accepted_answers' => array_values(array_filter(
                    array_map('trim', preg_split('/\r?\n|,/', (string) ($data['accepted_answers'] ?? ''))),
                    fn ($a) => $a !== ''
                )),
                'case_sensitive' => (bool) ($data['case_sensitive'] ?? false),
            ],
            'coding' => array_filter([
                // SỬA 24/8 (Nhập câu hỏi lập trình từ gói ZIP "OT360-QPACK"): ưu tiên
                // 'test_cases_parsed' (mảng {input,output} đã tách sẵn, ví dụ đọc thẳng từ
                // tệp trong gói ZIP) nếu có — TRÁNH vòng lặp lossy qua ô "Test cases" 1-dòng-
                // 1-test "input|||output" khi test case gốc có nhiều dòng (xem
                // questionStoreFromZipPackage() bên dưới). Form nhập tay bình thường không
                // gửi 'test_cases_parsed' nên hành vi cũ (đọc 'test_cases_raw') không đổi.
                /*
                 * SỬA 21/9 (khách: "code tính tổng đúng mà ghi nhận cứ sai") — thứ tự ưu tiên:
                 *   1. 'test_cases_parsed' — đã tách sẵn (gói ZIP), dùng nguyên văn;
                 *   2. có gửi ô 'test_cases_raw' -> tách theo định dạng "input|||output";
                 *   3. KHÔNG gửi ô đó -> GIỮ NGUYÊN test cũ ('_existing_test_cases').
                 * Nhánh 3 là mới: form Sửa khoá ô test khi câu có test nhiều dòng (xem
                 * edit.blade.php) và không gửi ô đó lên. Trước đây vắng ô này thì rơi vào
                 * parseTestCases('') -> mảng rỗng -> XOÁ SẠCH toàn bộ test của câu hỏi.
                 */
                'test_cases' => $data['test_cases_parsed']
                    ?? (array_key_exists('test_cases_raw', $data)
                        ? $this->parseTestCases((string) ($data['test_cases_raw'] ?? ''))
                        : ($data['_existing_test_cases'] ?? [])),
                'time_limit_ms' => filled($data['time_limit_ms'] ?? null) ? (int) $data['time_limit_ms'] : null,
                'memory_limit_mb' => filled($data['memory_limit_mb'] ?? null) ? (int) $data['memory_limit_mb'] : null,
                // SỬA 21/10 — Cách chấm (App\Support\OutputChecker). Mặc định -> null (không lưu khoá).
                'checker' => \App\Support\OutputChecker::fromInput($data),
                // SỬA 24/8 — 3 khoá dưới đây CHỈ được gói ZIP điền (form nhập tay không có
                // trường tương ứng) — giữ lại trong grading_config để dành cho khi có judge
                // chấm code thật sau này (ngôn ngữ cho phép / quy ước tên file input-output /
                // chấm theo nhóm điểm subtasks). Không dùng ở đâu khác hiện tại — vô hại.
                'languages' => $data['languages'] ?? null,
                // SỬA 1/10 (khách: "nhập thủ công đang thiếu vài trường") — file_io KHÔNG
                // còn là "chỉ gói ZIP điền được": form nhập tay giờ có 2 ô Tên tệp vào / Tên
                // tệp ra. Xem resolveFileIo() ngay dưới buildGradingConfig().
                'file_io' => $this->resolveFileIo($data),
                'subtasks' => $data['subtasks'] ?? null,
            ], fn ($v) => $v !== null),
            default => [],
        };
    }

    /**
     * Mỗi dòng "input|||output" -> 1 test case.
     *
     * SỬA 21/9 — dòng KHÔNG có dấu "|||" giờ là LỖI, báo rõ số dòng cho người nhập; trước đây
     * nó bị BỎ QUA ÂM THẦM, và đó chính là cơ chế đã xoá sạch dữ liệu vào của cả bộ test:
     *
     *   Test nhập từ gói ZIP có dữ liệu vào kết thúc bằng xuống dòng ("2 3\n"). Form Sửa ghép
     *   lại thành chuỗi "2 3\n|||5" -> ô textarea hiện HAI dòng "2 3" và "|||5". Bấm Lưu, dòng
     *   "2 3" không có "|||" nên bị bỏ, dòng "|||5" thành test có dữ liệu vào RỖNG. Chỉ một lần
     *   bấm Lưu (không sửa gì) là mất hết. Chương trình đúng đọc vào rỗng -> in 0 -> chỉ đậu
     *   đúng những test có đáp án 0 (khách gặp: 4/20).
     *
     * Dòng trống vẫn bỏ qua như cũ (để người nhập cách dòng cho dễ đọc).
     *
     * @throws ValidationException khi có dòng không đúng định dạng.
     */
    private function parseTestCases(string $raw): array
    {
        $cases = [];
        $badLines = [];

        foreach (preg_split('/\r?\n/', trim($raw)) as $index => $line) {
            if (blank($line)) {
                continue;
            }

            if (! str_contains($line, '|||')) {
                $badLines[] = $index + 1;

                continue;
            }

            [$input, $output] = explode('|||', $line, 2);
            $cases[] = ['input' => $input, 'output' => $output];
        }

        if ($badLines !== []) {
            throw ValidationException::withMessages([
                'test_cases_raw' => 'Dòng '.implode(', ', array_slice($badLines, 0, 10)).(count($badLines) > 10 ? '…' : '')
                    .' trong ô Test cases thiếu dấu "|||" giữa dữ liệu vào và kết quả. Mỗi dòng phải có dạng: dữ liệu vào|||kết quả (vd: 3 5|||8). '
                    .'Chưa lưu gì để tránh mất test.',
            ]);
        }

        return $cases;
    }

    /** Phát hành — PHẢI qua QuestionPublishGuard (6.2/6.4), không có ngoại lệ cho admin. */
    public function questionPublish(Question $question): array
    {
        $decision = $this->publishGuard->canPublish($question);
        if (! $decision->allowed) {
            return ['ok' => false, 'message' => $decision->message ?? 'Chưa đủ điều kiện phát hành.'];
        }

        $this->questions->update($question, ['status' => ContentStatus::Published->value]);

        return ['ok' => true, 'message' => null];
    }

    /** Trả về nháp — PHẢI có lý do + audit log (10.4). Auditable đã gắn sẵn ở Question model. */
    public function questionReject(Question $question, string $reason): Question
    {
        Question::$auditReason = $reason;
        $this->questions->update($question, ['status' => ContentStatus::Draft->value]);
        Question::$auditReason = null;

        return $question;
    }

    private const DISPLAY_ORDER_LIMIT = 65535;

    /** Số thứ tự hiển thị lớn nhất đang có (0 nếu chưa câu nào đặt). */
    public function displayOrderMax(): int
    {
        return (int) Question::query()->max('display_order');
    }

    /**
     * SỬA 7/10 — đặt thẳng số "Thứ tự hiển thị" của 1 câu (ô số, nút −/＋ ở danh sách).
     * Số lớn hơn = hiện trước (0 = bình thường). Kẹp 0..65535. Đi qua $question->update() nên
     * nhật ký kiểm toán (Auditable) vẫn ghi như khi sửa bằng form.
     *
     * @return array{ok:bool, message?:string}
     */
    public function questionSetDisplayOrder(Question $question, int $value): array
    {
        $new = max(0, min(self::DISPLAY_ORDER_LIMIT, $value));
        $this->saveDisplayOrder($question, $new);

        return ['ok' => true];
    }

    /**
     * SỬA 7/10 (khách: "Đưa lên đầu = đưa lên TRƯỚC câu đó, không phải lên max") — đưa $question
     * lên đứng NGAY TRƯỚC $before (câu đang nằm liền phía trên nó trong danh sách), không động
     * tới thứ tự của các câu còn lại.
     *
     * Thứ tự này là thứ tự CHUNG của admin và trang Luyện tập (QuestionOrder::apply): gom theo dạng
     * bài → display_order giảm dần → id TĂNG dần. Vì hoà số thì id nhỏ đứng trước, nên muốn chắc chắn
     * câu này đứng trước câu kia ở cả hai nơi thì cho nó số LỚN HƠN HẲN, không để hoà. Vì vậy:
     *   - $question nhận số = $before + 1;
     *   - nếu phía trên $before (cùng dạng bài) đã có câu nào số ≤ $before + 1 thì đẩy các câu đó
     *     lên 2 bậc để chúng vẫn ở trên $question.
     * Trường hợp hay gặp (cả kho đang 0 hết) chỉ cần: các câu phía trên thành 2, câu này thành 1.
     * Thứ tự chỉ có nghĩa TRONG một dạng bài (dạng khác nhau thì xếp theo nhóm dạng) nên 2 câu khác
     * dạng thì từ chối.
     *
     * @return array{ok:bool, message?:string}
     */
    public function questionMoveBefore(Question $question, Question $before): array
    {
        return \App\Support\QuestionReorder::moveBefore($question, $before);
    }

    private function saveDisplayOrder(Question $question, int $new): void
    {
        if ((int) $question->display_order === $new) {
            return;
        }
        Question::$auditReason = 'Đổi thứ tự hiển thị nhanh ở danh sách';
        try {
            $question->update(['display_order' => $new]);
        } finally {
            Question::$auditReason = null;
        }
    }

    /**
     * Giá trị thứ tự hiện tại của các câu đang hiện trên trang + số lớn nhất toàn kho — trả về
     * sau mỗi lần đổi để ô số trên trang khớp với dữ liệu thật (nhất là sau khi đẩy nhóm phía trên).
     *
     * @param  list<int>  $ids
     * @return array{values:array<int,int>, max:int}
     */
    public function displayOrderSnapshot(array $ids): array
    {
        $values = $ids === [] ? [] : Question::query()->whereIn('id', $ids)->pluck('display_order', 'id')
            ->map(fn ($v) => (int) $v)->all();

        return ['values' => $values, 'max' => $this->displayOrderMax()];
    }

    public function questionArchive(Question $question, string $reason): Question
    {
        Question::$auditReason = $reason;
        $this->questions->update($question, ['status' => ContentStatus::Archived->value]);
        Question::$auditReason = null;

        return $question;
    }

    // ================= Câu hỏi lập trình — "Nhập từ gói ZIP" (24/8) =================
    // Khách muốn tải lên 1 gói ZIP đóng gói sẵn (question.json + statement.pdf + solution.pdf
    // + reference/official.cpp + tests/<số>/INPUT+OUTPUT theo định dạng "OT360-QPACK") rồi CHỈ
    // CẦN bấm Lưu ở màn Sửa — không phải gõ tay từng test case. Cố ý tái sử dụng questionStore()
    // NGUYÊN VẸN bên trên (không đổi chữ ký/nội dung hàm đó) để không đụng vào luồng tạo câu hỏi
    // thủ công đang chạy đúng — ở đây chỉ build đúng $data mà questionStore() đã hiểu, rồi gắn
    // thêm 'metadata' (môn/khối/chuyên đề/độ khó/tác giả — xem cột metadata ở migration
    // questions) và lưu 3 tệp đính kèm sau khi đã có $question->id.

    private const MAX_ZIP_PACKAGE_KB = 20480; // 20MB — gói ZIP gồm cả PDF đề+lời giải+nhiều test case

    /**
     * SỬA 1/10 — ánh xạ 3 tệp đính kèm cố định sang tên ô <input type="file"> trên form
     * Tạo/Sửa câu hỏi. Dùng ở CẢ ContentService (lưu) lẫn ContentController (luật kiểm tra)
     * để 2 chỗ không lệch tên ô.
     *
     * @var array<string, string>
     */
    public const MANUAL_ATTACHMENT_FIELDS = [
        'statement' => 'statement_file',
        'solution' => 'solution_file',
        'reference' => 'reference_file',
    ];

    public static function maxQuestionZipKb(): int
    {
        // SỬA 22/10 — gói câu hỏi có bộ test lớn dễ vượt 20MB: dùng trần gói ZIP chung (config/uploads.php, mặc định 200MB).
        return \App\Support\UploadLimit::zipKilobytes();
    }

    /**
     * admin.content.questions.zipImport — điểm vào duy nhất của tính năng. LƯU Ý ĐÃ BÁO CHO
     * KHÁCH: test case nhập từ ZIP được lưu đúng nguyên vẹn (kể cả nhiều dòng) nhờ
     * 'test_cases_parsed' ở buildGradingConfig() trên — nhưng nếu SAU ĐÓ ai sửa câu hỏi này
     * qua ô "Test cases" thủ công (dạng text "input|||output" mỗi dòng), nội dung nhiều dòng
     * có thể bị hiểu sai thành nhiều test case khác nhau.
     *
     * SỬA 21/9 — hạn chế trên ĐÃ ĐƯỢC SỬA: form Sửa bỏ xuống dòng thừa cuối mỗi test trước khi
     * ghép, khoá ô test khi câu có test nhiều dòng thật, và parseTestCases() báo lỗi thay vì âm
     * thầm bỏ dòng. Xem 3 chỗ đó để biết chi tiết.
     *
     * @throws ValidationException nếu gói ZIP không mở được, thiếu/sai question.json, hoặc
     *                              không có test case hợp lệ nào trong thư mục tests/.
     */
    public function questionStoreFromZipPackage(User $admin, UploadedFile $zip): Question
    {
        $package = $this->parseZipQuestionPackage($zip);
        $json = $package['json'];
        $content = $json['content'] ?? [];
        $contentType = (string) ($content['type'] ?? '');

        $points = isset($content['points']) ? (int) round((float) $content['points']) : 0;

        $tagNames = array_values(array_filter(array_map('trim', array_merge(
            $json['taxonomy']['tags'] ?? [],
            $json['taxonomy']['keywords'] ?? [],
        )), fn ($t) => $t !== ''));

        // SỬA 31/8 (2, "mở rộng ZIP bài tập" — không chỉ lập trình): trước đây $data['type'] LUÔN
        // gán cứng 'coding' rồi gọi lại questionStore() (đi qua buildGradingConfig() theo cấu
        // trúc form nhập tay) — giờ gói ZIP có thể là 1 trong 4 content.type khác nhau (xem
        // QuestionZipPackage::SUPPORTED_CONTENT_TYPES), mỗi loại map sang 1 Question::type khác nhau
        // (questionTypeFromZipContentType()) và có cấu trúc grading JSON khác hẳn form nhập tay
        // — build thẳng grading_config qua buildGradingConfigFromZipPackage() (hiểu đúng cấu
        // trúc từng loại) rồi tạo Question trực tiếp, không qua questionStore() nữa (giữ nguyên
        // questionStore() cho luồng nhập tay ở form, không đụng vào).
        $type = $this->questionTypeFromZipContentType($contentType);

        // SỬA 8/9 (3) ("phân loại kho câu hỏi theo môn") — gói ZIP đã khai báo sẵn môn/khối ở
        // taxonomy.subject + taxonomy.grade_levels; đổ thẳng vào 2 cột lọc, không để câu nhập từ
        // ZIP rơi vào nhóm "Chưa phân loại". Mã môn lạ (không có trong SubjectCatalog) -> null,
        // admin gán lại ở form Sửa. Bản taxonomy đầy đủ vẫn giữ nguyên trong metadata bên dưới.
        $classification = SubjectCatalog::fromTaxonomy($json['taxonomy'] ?? []);

        // SỬA 6/11 — giáo viên nhập gói ZIP đề ở màn của quản trị (TeacherContentScope): câu vào kho riêng của giáo viên.
        $teacherScoped = \App\Support\TeacherContentScope::ownerAttributes($admin)['owner_type'] === OwnerType::Teacher->value;
        $question = $this->questions->create([
            'bank_id' => $teacherScoped ? app(\App\Services\Teacher\QuestionService::class)->findOrCreatePersonalBank($admin)->id : $this->sharedBank()->id,
            'code' => $this->deriveUniqueQuestionCode($zip->getClientOriginalName()),
            'type' => $type,
            'title' => $content['title'] ?? 'Câu hỏi (nhập từ ZIP)',
            'subject' => $classification['subject'],
            'grade' => $classification['grade'],
            // SỬA 16/10 (khách: "nhập file ZIP thì Tỉnh thành mặc định Toàn quốc, Năm mặc định năm nay — thích thì chọn khác")
            // — gói có ghi taxonomy.province / taxonomy.exam_year hợp lệ thì theo gói, không thì mặc định.
            'province' => ProvinceCatalog::normalizeForQuestion(isset($json['taxonomy']['province']) ? (string) $json['taxonomy']['province'] : null)
                ?? ProvinceCatalog::DEFAULT_QUESTION_SCOPE,
            'exam_year' => ProvinceCatalog::normalizeYear($json['taxonomy']['exam_year'] ?? null) ?? (int) date('Y'),
            'body' => $this->placeholderBodyForZipImport($content, $package['attachments']),
            'points' => max(0, $points),
            'grading_config' => $this->buildGradingConfigFromZipPackage($contentType, $json, $package['testCases']),
            ...\App\Support\TeacherContentScope::ownerAttributes($admin),
            'visibility' => $teacherScoped ? Visibility::Private->value : Visibility::Public->value,
            'status' => ContentStatus::Draft->value,
            'version' => 1,
            'created_by' => $admin->id,
        ]);

        $question->update([
            'metadata' => [
                'source_package' => [
                    'schema' => $json['schema'] ?? null,
                    'content_type' => $contentType,
                    'original_filename' => $zip->getClientOriginalName(),
                    'imported_at' => now()->toIso8601String(),
                ],
                'taxonomy' => $json['taxonomy'] ?? null,
                'pedagogy' => $json['pedagogy'] ?? null,
                'attribution' => $json['attribution'] ?? null,
                'attachments' => $this->storeZipAttachments($question, $package['attachments']),
                // SỬA 31/8 (2) — audio/ảnh... đính kèm (khác 3 tệp cố định statement/solution/
                // reference ở trên) — xem storeZipAssets() + Question::findAsset().
                'assets' => $this->storeZipAssets($question, $package['assets']),
                // SỬA 18/9 — độ khó gói ZIP khai sẵn ở pedagogy.difficulty; đổ thẳng vào
                // metadata.difficulty để trang Luyện tập public hiện/lọc đúng ngay sau khi nhập.
                // Gói KHÔNG khai thì BỎ HẲN khoá (array_filter dưới) chứ không ghi null: bộ lọc
                // "Chưa đặt độ khó" đọc bằng json_extract, mà JSON null không phải SQL NULL nên
                // ghi null sẽ làm câu đó rơi ra ngoài mọi mức lọc. Xem QuestionDifficulty.
            ] + array_filter(['difficulty' => QuestionZipPackage::difficultyFrom($json)]),
        ]);

        if ($tagNames !== []) {
            $question->tags()->sync($this->tags->idsFromPackageNames($tagNames)); // SỬA 16/10 — tag có dấu (TagName)
        }

        return $question;
    }

    /**
     * admin.content.questions.attachment — tệp đính kèm (đề/lời giải/code mẫu) lưu trong
     * metadata.attachments khi câu hỏi được nhập từ gói ZIP (xem questionStoreFromZipPackage()).
     * Câu hỏi tạo tay (không qua ZIP) không có metadata.attachments -> luôn 404 ở đây, đúng vì
     * không có tệp gì để tải.
     */
    public function questionAttachmentInfo(Question $question, string $kind): array
    {
        $attachments = $question->metadata['attachments'] ?? [];
        if (! isset($attachments[$kind]['path'])) {
            abort(404);
        }

        return [
            'path' => $attachments[$kind]['path'],
            'filename' => $attachments[$kind]['filename'] ?? basename($attachments[$kind]['path']),
        ];
    }

    /**
     * SỬA 31/8 (2, "mở rộng ZIP bài tập" — không chỉ lập trình): 4 dạng nội dung
     * (content.type) hiện được hỗ trợ — trước đây CHỈ 'programming'. Khách chốt: essay (phần
     * tự luận trong 'composite') ghi nhận, chưa tự chấm được (cùng cách xử lý câu Lập trình).
     */
    private const SUPPORTED_ZIP_CONTENT_TYPES = QuestionZipPackage::SUPPORTED_CONTENT_TYPES;

    /**
     * Mở gói ZIP, đọc + kiểm tra question.json (phải đúng schema "OT360-QPACK" và content.type
     * thuộc SUPPORTED_ZIP_CONTENT_TYPES ở trên), gom test case từ các thư mục tests/<số>/ (mỗi
     * thư mục có 1 tệp chứa "input" trong tên và 1 tệp chứa "output" trong tên — KHÔNG cố định
     * đúng tên "INPUT.INP"/"OUTPUT.OUT" vì gói khác có thể đặt tên file khác), đọc nội dung 3
     * tệp đính kèm cố định (statement.pdf/solution.pdf/reference/official.cpp) nếu có, VÀ đọc
     * luôn 'assets' (audio/ảnh... khai báo trong question.json, path bất kỳ trong gói — SỬA
     * 31/8 (2), xem gói mẫu "ANH7AUDIO_DEMO_001") — đọc hết NGAY TRONG hàm này rồi đóng ZIP
     * luôn, tránh phải giữ ZipArchive mở vắt qua nhiều hàm.
     *
     * Test case (tests/<số>/) chỉ BẮT BUỘC với content.type = 'programming' (chấm bằng so khớp
     * input/output qua judge) — 4 dạng còn lại chấm qua 'grading' trong question.json, không
     * cần thư mục tests/ nào.
     *
     * @return array{json: array, testCases: array<int, array{input:string, output:string}>, attachments: array<string, array{content:string, filename:string}>, assets: array<int, array{id:string, kind:string, filename:string, content:string, transcript:?string, alt_text:?string}>}
     */
    private function parseZipQuestionPackage(UploadedFile $zip): array
    {
        return QuestionZipPackage::parse($zip);
    }

    /**
     * SỬA 31/8 (2) — map content.type (gói ZIP) sang Question::type (cột 'type' thật của hệ
     * thống): 'single_choice'/'true_false' quy về 'mcq' — TÁI DÙNG NGUYÊN VẸN máy Mcq đã có
     * (QuestionGrader::isMcqCorrect(), màn Luyện tập/Làm bài Mcq) thay vì viết thêm luồng
     * chấm/hiển thị riêng, xem App\Support\QuestionZipPackage
     * (đã chuyển sang đó, SỬA 18/9); 'short_answer' quy về 'fill_blank' cùng lý do. 'composite' là loại DUY NHẤT thật
     * sự mới (nhiều phần khác dạng, không quy về đâu được).
     */
    private function questionTypeFromZipContentType(string $contentType): string
    {
        return QuestionZipPackage::questionType($contentType);
    }

    /**
     * Dựng grading_config từ gói ZIP theo ĐÚNG content.type — khác buildGradingConfig() ở trên
     * (dựng từ input FORM nhập tay của admin, cấu trúc khác hẳn cấu trúc JSON của gói ZIP) nên
     * tách hàm riêng, không gộp chung tránh 1 hàm phải hiểu 2 nguồn dữ liệu khác hình dạng.
     */
    private function buildGradingConfigFromZipPackage(string $contentType, array $json, array $testCases): array
    {
        return QuestionZipPackage::gradingConfig($contentType, $json, $testCases);
    }

    /**
     * Mã câu hỏi tự sinh từ TÊN GỐC của tệp ZIP (ví dụ "TIN9TONG_2_SO_001.zip" ->
     * "TIN9TONG_2_SO_001") — admin không phải tự gõ mã khi nhập từ ZIP. Thêm hậu tố "-2", "-3"...
     * nếu trùng mã đã có (questionStore() vẫn tự kiểm tra lại lần cuối, đây chỉ để tránh va
     * trùng ngay từ đầu trong trường hợp thường gặp).
     */
    private function deriveUniqueQuestionCode(string $originalFilename): string
    {
        // SỬA 25/8: thuật toán chuyển sang dùng CHUNG App\Support\UniqueCodeFromFilename với
        // deriveUniqueMaterialCode() (mã bài học liệu) — khác nhau đúng 1 chỗ là PHẠM VI kiểm
        // tra trùng ($exists dưới đây: toàn hệ thống cho câu hỏi, trong 1 sản phẩm cho học
        // liệu), còn lại (cắt đuôi, giới hạn độ dài, thêm hậu tố) là 1 thuật toán duy nhất.
        return UniqueCodeFromFilename::generate(
            $originalFilename,
            fn (string $code) => $this->questions->query()->where('code', $code)->exists(),
        );
    }

    /**
     * SỬA 3/9 (khách chốt: "hiển thị thẳng đề bài dạng text, khỏi hiển thị file") — thử trích
     * chữ thật từ statement.pdf đính kèm (nếu gói ZIP có) qua PdfTextExtractor, dùng THẲNG làm
     * body để học sinh đọc ngay trên trang luyện tập/làm bài, KHÔNG cần mở file riêng nữa.
     * Chỉ rơi về dòng ghi chú cũ khi: không có statement.pdf, hoặc trích lỗi/rỗng (PDF là ảnh
     * scan, không có lớp text thật) — để trống body sẽ bị QuestionPublishGuard chặn phát hành
     * (đòi body không rỗng), nên vẫn cần 1 nội dung hợp lệ trong mọi trường hợp.
     *
     * @param  array<string, array{content:string, filename:string}>  $rawAttachments  $package['attachments'] TRƯỚC khi lưu disk (storeZipAttachments()) — cần nguyên bytes PDF để trích, không phải đường dẫn đã lưu.
     */
    private function placeholderBodyForZipImport(array $content, array $rawAttachments = []): string
    {
        $statementPdf = $rawAttachments['statement']['content'] ?? null;
        if ($statementPdf !== null) {
            $extracted = $this->pdfTextExtractor->extractText($statementPdf);
            if ($extracted !== null) {
                return $this->pdfTextExtractor->toBodyHtml($extracted);
            }
        }

        $note = 'Đề bài đầy đủ nằm trong tệp PDF đính kèm (nhập từ gói ZIP) — xem mục "Tệp đính kèm" ở trang Sửa câu hỏi.';
        $title = $content['title'] ?? null;

        return $title ? "{$title}\n\n{$note}" : $note;
    }

    /**
     * Lưu tệp đính kèm (đề/lời giải/code mẫu) vào đúng disk 'local' (riêng tư, giống quy ước
     * PdfAssessmentEditingService::PDF_DISK) theo đường dẫn khoá bởi $question->id — chỉ gọi
     * SAU KHI câu hỏi đã tạo (cần id để đặt đường dẫn).
     *
     * @param  array<string, array{content:string, filename:string}>  $attachments
     * @return array<string, array{path:string, filename:string}>
     */
    private function storeZipAttachments(Question $question, array $attachments): array
    {
        $stored = [];
        foreach ($attachments as $kind => $attachment) {
            $extension = pathinfo($attachment['filename'], PATHINFO_EXTENSION) ?: 'bin';
            $path = "questions/{$question->id}/{$kind}.{$extension}";
            Storage::disk('local')->put($path, $attachment['content']);
            $stored[$kind] = ['path' => $path, 'filename' => $attachment['filename']];
        }

        return $stored;
    }

    /**
     * SỬA 31/8 (2, "mở rộng ZIP bài tập") — lưu asset (audio/ảnh...) đính kèm câu hỏi, SONG
     * SONG với storeZipAttachments() ở trên nhưng khác ở chỗ SỐ LƯỢNG/loại không cố định trước
     * (3 tên statement/solution/reference) — lưu theo asset id (duy nhất trong 1 câu hỏi, do
     * gói ZIP tự đặt hoặc tự sinh UUID nếu thiếu, xem parseZipQuestionPackage()) thay vì theo
     * 'kind' cố định. Trả về mảng lưu vào metadata.assets — Question::findAsset() +
     * Student\PracticeByQuestionService/blade dùng lại để phát audio/hiện ảnh lúc "Làm bài".
     *
     * @param  array<int, array{id:string, kind:string, filename:string, content:string, transcript:?string, alt_text:?string}>  $assets
     * @return array<int, array{id:string, kind:string, path:string, filename:string, transcript:?string, alt_text:?string}>
     */
    private function storeZipAssets(Question $question, array $assets): array
    {
        $stored = [];
        foreach ($assets as $asset) {
            $extension = pathinfo($asset['filename'], PATHINFO_EXTENSION) ?: 'bin';
            $path = "questions/{$question->id}/assets/{$asset['id']}.{$extension}";
            Storage::disk('local')->put($path, $asset['content']);

            $stored[] = [
                'id' => $asset['id'],
                'kind' => $asset['kind'],
                'path' => $path,
                'filename' => $asset['filename'],
                'transcript' => $asset['transcript'],
                'alt_text' => $asset['alt_text'],
            ];
        }

        return $stored;
    }

    // ================= Bài tập đính kèm sản phẩm ("ZIP bài tập", 31/8) =================
    // Khách chốt qua nhiều vòng: (1) nhập bằng ZIP OT360-QPACK — tái dùng
    // parseZipQuestionPackage()/storeZipAttachments()/deriveUniqueQuestionCode()/
    // placeholderBodyForZipImport()/questionAttachmentInfo() y hệt Kho câu hỏi ở trên, chỉ khác
    // gắn product_id thay vì đưa vào Kho chung; (2) không giới hạn số lượng bài tập/sản phẩm;
    // (3) chấm kiểu thi online khi học sinh làm — thực chất tái dùng
    // Student\PracticeByQuestionService (xem startForQuestion() ở đó) — LƯU Ý: hệ thống hiện
    // CHƯA có sandbox chấm code thật (AttemptService.php đã ghi chú từ trước, không riêng gì
    // tính năng này), nên bài nộp vẫn ở trạng thái "Đang chấm" — khách đã được báo và đồng ý
    // làm trước, chấm thật sẽ tự chạy đúng khi có sandbox thật sau này, không cần sửa lại;
    // (4) chọn ZIP xong mà thoát ra không bấm "Lưu bài tập" thì tự xoá — xem
    // discardAbandonedDraftsFor(); (5) CHỈ Admin quản lý — route đặt cùng nhóm middleware
    // role:admin,super_admin với admin.products.* (routes/web.php), giáo viên không có route
    // nào trỏ tới các hàm dưới đây.

    /**
     * admin.products.show — danh sách bài tập để hiển thị + tự dọn bản nháp bỏ dở TRƯỚC khi
     * trả về danh sách (xem discardAbandonedDraftsFor()) — nhờ vậy nút "Thêm ZIP" ở màn hình
     * này luôn có thể bấm ngay, không bao giờ bị "kẹt" vì 1 bản nháp cũ quên chưa lưu.
     */
    public function productExercisesFor(Product $product): array
    {
        $this->discardAbandonedDraftsFor($product);

        // SỬA 27/10 (khách: "hiển thị theo thứ tự câu") — theo chương rồi mã bài (T1B001, T1B002…), cùng thứ tự với cột
        // Bài tập ở màn đọc (QuestionOrder::sortMaterialExercises), thay cho "mới nhập trước".
        // SỬA 27/10 lần 2 (khách: "dùng chung, không lưu thêm") — gộp thêm bài DÙNG KÉ từ tài liệu khác (kể cả bài gốc đang
        // nháp, để admin còn thấy mà gỡ). Bài dùng ké: Sửa = sửa bài gốc, nút "Gỡ" thay cho "Xoá". Xem App\Support\ProductExerciseLinks.
        $exLinks = \App\Support\ProductExerciseLinks::class;
        // SỬA 29/10 (tràn bộ nhớ với tài liệu có test lớn) — chỉ cột nhẹ + số test đếm bằng SQL, không kéo grading_config;
        // bỏ ORDER BY của quan hệ (thứ tự do sortMaterialExercises() xếp ở dưới).
        $exList = $exLinks::withLinked((int) $product->id, $product->exercises()->reorder()->listColumns()->withSummaryCounts()->with(['tags', 'chapter'])->get(), ['tags', 'product:id,title'], ['*'], false, fn ($q) => $q->listColumns()->withSummaryCounts());
        $exUsedBy = $exLinks::supported() && $exList->isNotEmpty()
            ? \App\Models\ProductExerciseLink::query()->whereIn('question_id', $exList->pluck('id')->all())->where('product_id', '!=', $product->id)
                ->selectRaw('question_id, COUNT(*) as n')->groupBy('question_id')->pluck('n', 'question_id')->all()
            : [];

        return \App\Support\QuestionOrder::sortMaterialExercises($exList)->map(fn (Question $q) => [
            'id' => $q->id,
            'linked' => $exLinks::isLinked($q),
            'ownerProductId' => (int) $q->product_id,
            'linkedFrom' => $exLinks::isLinked($q) ? 'Dùng chung từ '.($q->product?->title ?? 'tài liệu #'.$q->product_id) : null,
            'usedByCount' => (int) ($exUsedBy[$q->id] ?? 0), // số tài liệu KHÁC đang dùng ké bài này
            'code' => (string) $q->code,
            'chapterId' => $q->material_id !== null ? (int) $q->material_id : null, // SỬA 27/10 — lọc theo chương ở trang tài liệu
            'title' => $q->title,
            'points' => $q->points,
            // SỬA 31/8 (2, "mở rộng ZIP bài tập") — trước đây 'testCasesCount' (chỉ đúng cho
            // Lập trình) — bài tập giờ có thể là bất kỳ dạng nào trong 4 dạng ZIP hỗ trợ, dùng
            // Question::exerciseSummaryLabel() để mô tả đúng theo TỪNG dạng.
            'summary' => $q->exerciseSummaryLabel(),
            // SỬA 14/10 — tên dạng theo 4 dạng khách dùng (Đúng / Sai là trắc nghiệm 2 phương án nhập tay).
            // SỬA 16/10 — bài nhập từ ZIP: Đúng/Sai lưu là trắc nghiệm 2 phương án, nhận theo content_type của gói.
            'typeLabel' => match (true) {
                ($q->metadata['manual_variant'] ?? null) === 'true_false',
                ($q->metadata['source_package']['content_type'] ?? null) === 'true_false' => 'Đúng / Sai',
                $q->type->value === 'mcq' => 'Trắc nghiệm',
                $q->type->value === 'fill_blank' => 'Điền từ',
                $q->type->value === 'coding' => 'Lập trình',
                default => self::QUESTION_TYPE_LABELS[$q->type->value] ?? $q->type->value,
            },
            'typeKey' => (($q->metadata['manual_variant'] ?? null) === 'true_false'
                || ($q->metadata['source_package']['content_type'] ?? null) === 'true_false') ? 'true_false' : $q->type->value,
            'tags' => $q->tags->pluck('name')->all(),
            // SỬA 4/9 (khách yêu cầu "Chương/Phần/Đề") — tên chương/phần/đề bài tập này thuộc
            // về (null nếu chưa gắn) — xem Question::chapter().
            'chapterTitle' => $q->chapter?->title,
            'createdAt' => $q->created_at?->format('d/m/Y H:i'),
            // SỬA 27/10 — bài thêm bằng "Lấy từ bài có sẵn" (bản sao): nhãn "Lấy từ T1B001 · Sách …", xem ProductExercisePickService.
            'copiedFrom' => isset($q->metadata['copied_from']['code'])
                ? 'Lấy từ '.$q->metadata['copied_from']['code'].(filled($q->metadata['copied_from']['product_title'] ?? null) ? ' · '.$q->metadata['copied_from']['product_title'] : '')
                : null,
        ])->all();
    }

    // ================= Chương/Phần/Đề (materials.type=chapter) — SỬA 4/9 =================
    // Khách yêu cầu: "nếu loại sách thì thêm chương, loại chuyên đề là thêm phần, loại bộ đề
    // thì thêm đề, field chỉ cần title". Tái dùng NGUYÊN hệ Học liệu (Material) có sẵn — xem
    // Material::scopeChapters(), Product::chapters(), ProductType::chapterLabel() — KHÔNG tạo
    // bảng mới. Sản phẩm loại "Khóa học" không có khái niệm này (chapterLabel() trả null),
    // route/view tự ẩn khối này khi đó (xem admin/products/show.blade.php).

    /**
     * Danh sách chương/phần/đề của 1 sản phẩm, kèm số bài tập đang gắn vào (để cảnh báo trước
     * khi xoá).
     *
     * SỬA 29/9 (khách chốt: "bỏ file pdf sách đi, chỗ chương mỗi chương là thêm từng file
     * pdf") — thêm 'hasPdf'/'pdfName': từ nay NỘI DUNG ĐỌC nằm ở PDF của TỪNG chương, không
     * còn ở 1 tệp "File PDF" tổng gắn thẳng vào sản phẩm. Trang đọc nối các tệp này lại thành
     * một dải cuộn, xem App\Services\ProductReadService.
     */
    public function productChaptersFor(Product $product): array
    {
        return $product->chapters()->withCount(['questions', 'children'])->get()->map(fn (Material $m) => [
            'id' => $m->id,
            'title' => $m->title,
            'order' => $m->order,
            'questionsCount' => $m->questions_count,
            'materialsCount' => $m->children_count,
            'hasPdf' => filled($m->pdf_path),
            'pdfName' => $m->pdf_original_name,
        ])->all();
    }

    /**
     * SỬA 4/9 (khách yêu cầu: "chỗ thêm file học liệu thì cho chọn chương/phần/đề") — danh
     * sách học liệu (file PDF/audio/ảnh THẬT, KHÁC bản thân chương/phần/đề — loại trừ
     * type=chapter) của 1 sản phẩm, kèm tên chương/phần/đề đang gắn (qua parent_id, null nếu
     * chưa gắn) — hiện ở khối mới trên trang chi tiết sản phẩm.
     */
    public function productMaterialsFor(Product $product): array
    {
        return $this->materials->query()
            ->where('product_id', $product->id)
            ->where('type', '!=', 'chapter')
            ->with('parent')
            ->orderBy('order')
            ->get()
            ->map(function (Material $m) {
                [$label, $tone] = $this->statusLabel($m->status);

                return [
                    'id' => $m->id,
                    'title' => $m->title,
                    'chapterTitle' => $m->parent?->title,
                    'hasPdf' => (bool) $m->pdf_path,
                    'hasAudio' => (bool) $m->audio_path,
                    'hasImage' => (bool) $m->image_path,
                    'statusLabel' => $label,
                    'statusTone' => $tone,
                ];
            })->all();
    }

    /**
     * SỬA 29/9 — $data['pdf'] (UploadedFile, tùy chọn): tệp PDF NỘI DUNG của chính chương/phần/
     * đề này. Tái dùng nguyên resolveMaterialCode() + storeMaterialPdf() của học liệu thường
     * (cùng disk 'local', cùng quy ước đặt tên materials/{product}/{code}.pdf) — không thêm
     * bảng/đường dẫn mới. Chưa có tệp thì vẫn tạo được chương rỗng như trước.
     */
    public function productChapterStore(Product $product, array $data): Material
    {
        $pdf = $data['pdf'] ?? null;
        $code = $this->resolveMaterialCode($product->id, $data['code'] ?? null, $pdf);

        $attributes = [
            'product_id' => $product->id,
            'parent_id' => null,
            'type' => 'chapter',
            'title' => $data['title'],
            'order' => $data['order'] ?? 0,
            'assessment_id' => null,
            'code' => $code,
            // Published ngay — khái niệm "chương/phần/đề" ở đây chỉ là mục lục nội bộ để gắn
            // bài tập/học liệu, không qua vòng duyệt nội dung như Material dạng nội dung thật.
            'status' => ContentStatus::Published->value,
        ];

        if ($pdf !== null) {
            $attributes = array_merge($attributes, $this->storeMaterialPdf($product->id, (string) $code, $pdf));
        }

        return $this->materials->create($attributes);
    }

    /**
     * SỬA 29/9 — sửa tên/thứ tự như trước, THÊM 2 việc với tệp PDF của chương:
     *  - tải tệp mới ($data['pdf']) -> xoá tệp cũ trên disk rồi lưu tệp mới (y như
     *    materialUpdate(), không để file rác lại trên đĩa);
     *  - tích "xoá PDF" ($data['remove_pdf']) -> xoá tệp và trả 2 cột về null, chương thành
     *    mục lục rỗng trở lại. Tải tệp mới thì việc xoá bị bỏ qua (ý người dùng rõ ràng là THAY).
     */
    public function productChapterUpdate(Material $chapter, array $data): Material
    {
        $pdf = $data['pdf'] ?? null;
        $attributes = [
            'title' => $data['title'],
            'order' => $data['order'] ?? $chapter->order,
        ];

        if ($pdf !== null) {
            if ($chapter->pdf_path) {
                Storage::disk('local')->delete($chapter->pdf_path);
            }

            $code = $this->resolveMaterialCode($chapter->product_id, $chapter->code, $pdf, $chapter->id);
            $attributes['code'] = $code;
            $attributes = array_merge($attributes, $this->storeMaterialPdf($chapter->product_id, (string) $code, $pdf));
        } elseif (! empty($data['remove_pdf'])) {
            if ($chapter->pdf_path) {
                Storage::disk('local')->delete($chapter->pdf_path);
            }

            $attributes['pdf_path'] = null;
            $attributes['pdf_original_name'] = null;
        }

        return $this->materials->update($chapter, $attributes);
    }

    /**
     * Chặn xoá khi vẫn còn bài tập/học liệu đang gắn vào — Material::parent_id có
     * cascadeOnDelete() ở DB (xem migration create_materials_table), xoá "lụi" 1 chương có thể
     * âm thầm xoá theo cả cây học liệu con bên dưới nó, rất dễ mất dữ liệu ngoài ý muốn.
     *
     * @throws ValidationException nếu vẫn còn học liệu con (parent_id) hoặc bài tập (material_id) gắn vào.
     */
    /**
     * SỬA 15/10 (khách: "thêm nút mũi tên lên xuống để đảo thứ tự chương tuỳ ý") — đổi chỗ chương với chương
     * liền trên/dưới. Đánh lại số thứ tự 10, 20, 30… cho cả danh sách (dữ liệu cũ có thể trùng số/để 0), nên
     * bấm bao nhiêu lần cũng ra đúng thứ tự đang thấy. Ở đầu/cuối danh sách thì bỏ qua.
     */
    public function productChapterMove(Material $chapter, string $direction): void
    {
        $chapters = $this->materials->query()
            ->where('product_id', $chapter->product_id)
            ->where('type', 'chapter')
            ->whereNull('parent_id')
            ->orderBy('order')
            ->orderBy('id')
            ->get(['id', 'order'])
            ->values();

        $index = $chapters->search(fn (Material $m) => $m->id === $chapter->id);
        if ($index === false) {
            return;
        }

        $target = $direction === 'up' ? $index - 1 : $index + 1;
        if ($target < 0 || $target >= $chapters->count()) {
            return;
        }

        $list = $chapters->all();
        [$list[$index], $list[$target]] = [$list[$target], $list[$index]];

        \Illuminate\Support\Facades\DB::transaction(function () use ($list) {
            foreach ($list as $i => $m) {
                $newOrder = ($i + 1) * 10;
                if ((int) $m->order !== $newOrder) {
                    $this->materials->query()->whereKey($m->id)->update(['order' => $newOrder]);
                }
            }
        });
    }

    public function productChapterDestroy(Material $chapter): void
    {
        if ($chapter->children()->exists() || $chapter->questions()->exists()) {
            throw ValidationException::withMessages([
                'chapter' => 'Không thể xoá — vẫn còn học liệu hoặc bài tập đang gắn vào mục này. Gỡ/chuyển hết rồi thử lại.',
            ]);
        }

        // SỬA 29/9 — chương giờ có thể mang tệp PDF riêng: xoá bản ghi thì xoá luôn tệp, không
        // để file mồ côi trên disk (cùng cách materialDestroy() đang dọn file của học liệu).
        if ($chapter->pdf_path) {
            Storage::disk('local')->delete($chapter->pdf_path);
        }

        $chapter->delete();
    }

    /** material_id gửi lên có thực sự là 1 chương/phần/đề CỦA ĐÚNG sản phẩm này không — chặn admin tự sửa URL gắn nhầm sang chương của sản phẩm khác. */
    private function resolveChapterId(Product $product, mixed $rawMaterialId): ?int
    {
        if (! filled($rawMaterialId)) {
            return null;
        }

        return $product->chapters()->whereKey($rawMaterialId)->value('id');
    }

    /**
     * Bản NHÁP (status=Draft) chỉ tồn tại trong khoảng thời gian giữa lúc admin chọn xong ZIP
     * (productExerciseStoreFromZipPackage() tạo ngay + chuyển thẳng sang màn Sửa) và lúc admin
     * bấm "Lưu bài tập" (productExerciseSave() chuyển status -> Published). Hàm này chỉ được
     * gọi khi trang chi tiết sản phẩm được tải lại — nghĩa là admin CHẮC CHẮN không còn ở màn
     * Sửa bản nháp đó nữa (rời đi mà chưa lưu = bỏ dở) — xoá thẳng, không cần hỏi lại, đúng
     * yêu cầu "thoát ra không bấm Lưu thì xoá luôn, không cần thao tác gì thêm". Bài tập ĐÃ LƯU
     * (status khác Draft) không bao giờ bị đụng tới ở đây.
     */
    public function discardAbandonedDraftsFor(Product $product): void
    {
        $product->exercises()->where('status', ContentStatus::Draft->value)->get()
            ->each(fn (Question $draft) => $this->productExerciseDestroy($draft));
    }

    /**
     * admin.products.exercises.store — chọn ZIP xong tạo NGAY bản nháp rồi chuyển sang màn Sửa
     * (controller redirect) để admin xem lại/sửa Tiêu đề-Điểm-Tag trước khi bấm "Lưu bài tập".
     * Quét dọn nháp bỏ dở TRƯỚC KHI tạo mới (phòng khi admin bấm "Thêm ZIP" từ 1 tab/trang cũ
     * đã lỗi thời) — đúng tinh thần "phải thêm xong thì mới được thêm file ZIP mới".
     *
     * @throws ValidationException nếu gói ZIP không mở được/sai định dạng/thiếu test case hợp
     *                              lệ — xem parseZipQuestionPackage().
     */
    public function productExerciseStoreFromZipPackage(Product $product, User $admin, UploadedFile $zip, ?int $chapterId = null): Question
    {
        $this->discardAbandonedDraftsFor($product);

        // SỬA 27/10 (khách: "bài đã có rồi thì báo không ghi đè được, tránh bị trùng") — mã bài = tên file ZIP. Đã có bài mang
        // mã đó (ở bất kỳ tài liệu nào / kho chung) thì DỪNG, không tạo bản "-2" như trước.
        $baseCode = \App\Support\UniqueCodeFromFilename::base($zip->getClientOriginalName());
        $existing = \App\Models\Question::withTrashed()->where('code', $baseCode)->with('product:id,title')->first(['id', 'code', 'title', 'product_id', 'deleted_at']);
        if ($existing !== null) {
            throw ValidationException::withMessages([
                'zip_package' => 'Bài "'.$baseCode.'" ('.$zip->getClientOriginalName().') — '.\App\Services\Admin\ProductExerciseBulkImportService::whereLabel($existing)
                    .'. Hệ thống không ghi đè: muốn nhập lại thì xoá bài cũ trước, hoặc bỏ file ZIP này ra.',
            ]);
        }

        $package = $this->parseZipQuestionPackage($zip);
        $json = $package['json'];
        $content = $json['content'] ?? [];
        $contentType = (string) ($content['type'] ?? '');

        $points = isset($content['points']) ? (int) round((float) $content['points']) : 0;

        $tagNames = array_values(array_filter(array_map('trim', array_merge(
            $json['taxonomy']['tags'] ?? [],
            $json['taxonomy']['keywords'] ?? [],
        )), fn ($t) => $t !== ''));

        // SỬA 31/8 (2, "mở rộng ZIP bài tập") — cùng thay đổi như questionStoreFromZipPackage():
        // 'type' KHÔNG còn gán cứng 'coding', build grading_config qua
        // buildGradingConfigFromZipPackage() (hiểu đúng cấu trúc từng content.type) thay vì
        // buildGradingConfig('coding', ...).
        $type = $this->questionTypeFromZipContentType($contentType);

        $question = $this->questions->create([
            'bank_id' => $this->sharedBank()->id,
            // SỬA 31/8 — điểm khác biệt DUY NHẤT với questionStoreFromZipPackage(): gắn
            // product_id để câu hỏi này là "riêng của sản phẩm", loại khỏi mọi nơi lấy câu hỏi
            // dùng chung (xem whereNull('product_id') ở QuestionRepository).
            'product_id' => $product->id,
            // SỬA 14/10 — gắn chương chọn sẵn ở ô "Thuộc chương" (màn Sửa vẫn đổi lại được).
            'material_id' => $this->resolveChapterId($product, $chapterId),
            'code' => $this->deriveUniqueQuestionCode($zip->getClientOriginalName()),
            'type' => $type,
            'title' => $content['title'] ?? 'Bài tập (nhập từ ZIP)',
            'body' => $this->placeholderBodyForZipImport($content, $package['attachments']),
            'points' => max(0, $points),
            'grading_config' => $this->buildGradingConfigFromZipPackage($contentType, $json, $package['testCases']),
            'owner_type' => OwnerType::Shared->value,
            'owner_id' => null,
            'visibility' => Visibility::Public->value,
            // Draft = "đang thêm dở, chưa bấm Lưu" — KHÁC nghĩa "chờ duyệt" bên Kho câu hỏi
            // chung. Bài tập sản phẩm không qua vòng duyệt riêng; bấm "Lưu bài tập"
            // (productExerciseSave()) chuyển thẳng sang Published.
            'status' => ContentStatus::Draft->value,
            'version' => 1,
            'created_by' => $admin->id,
        ]);

        $question->update([
            'metadata' => [
                'source_package' => [
                    'schema' => $json['schema'] ?? null,
                    'content_type' => $contentType,
                    'original_filename' => $zip->getClientOriginalName(),
                    'imported_at' => now()->toIso8601String(),
                ],
                'taxonomy' => $json['taxonomy'] ?? null,
                'pedagogy' => $json['pedagogy'] ?? null,
                'attribution' => $json['attribution'] ?? null,
                'attachments' => $this->storeZipAttachments($question, $package['attachments']),
                'assets' => $this->storeZipAssets($question, $package['assets']),
            ],
        ]);

        if ($tagNames !== []) {
            $question->tags()->sync($this->tags->idsFromPackageNames($tagNames)); // SỬA 16/10 — tag có dấu (TagName)
        }

        return $question;
    }

    /**
     * admin.products.exercises.createManual (SỬA 4/9, khách yêu cầu "vừa thêm được từ ZIP và
     * thêm thủ công nữa") — chỉ hỗ trợ 3 dạng đã có form nhập tay sẵn ở Kho câu hỏi (mcq/
     * fill_blank/coding, xem questionCreateFormData()) — dạng "Nhiều phần" (composite) vẫn CHỈ
     * tạo được qua ZIP như quy ước cũ, không có form nhập tay tương ứng ở đây.
     */
    public function productExerciseManualCreateFormData(Product $product): array
    {
        return [
            'product' => $product,
            'types' => array_filter(self::QUESTION_TYPE_LABELS, fn ($key) => in_array($key, ['mcq', 'fill_blank', 'coding'], true), ARRAY_FILTER_USE_KEY),
            'chapters' => $this->productChaptersFor($product),
            'allTags' => $this->tags->allOrderedByName(),
        ];
    }

    /**
     * admin.products.exercises.storeManual — KHÁC productExerciseStoreFromZipPackage() ở chỗ
     * tạo THẲNG ra Published (không qua bước Nháp -> màn Sửa -> Lưu), vì toàn bộ nội dung đã
     * nhập đủ ngay trong 1 form duy nhất (giống questionStore() ở Kho câu hỏi) — không cần màn
     * riêng để "kiểm tra lại rồi Lưu" như luồng ZIP (vốn cần xem lại dữ liệu tự đọc từ gói).
     *
     * @throws ValidationException nếu trùng 'code' (Question.code duy nhất TOÀN hệ thống, xem questionStore()).
     */
    public function productExerciseStoreManual(Product $product, User $admin, array $data): Question
    {
        $variant = $data['type'];
        $data = $this->normalizeManualExerciseInput($data);

        if ($this->questions->query()->where('code', $data['code'])->exists()) {
            throw ValidationException::withMessages(['code' => 'Mã bài tập này đã tồn tại, chọn mã khác.']);
        }

        $question = $this->questions->create([
            'bank_id' => $this->sharedBank()->id,
            'product_id' => $product->id,
            'material_id' => $this->resolveChapterId($product, $data['material_id'] ?? null),
            'code' => $data['code'],
            'type' => $data['type'],
            'title' => $data['title'],
            'body' => $data['body'] ?? null,
            'points' => $data['points'] ?? 0,
            'grading_config' => $this->buildGradingConfig($data['type'], $data),
            // SỬA 14/10 — nhớ dạng hiển thị ("Đúng / Sai" là trắc nghiệm 2 phương án) để danh sách ghi đúng tên dạng.
            'metadata' => ['manual_variant' => $variant],
            'owner_type' => OwnerType::Shared->value,
            'owner_id' => null,
            'visibility' => Visibility::Public->value,
            'status' => ContentStatus::Published->value,
            'version' => 1,
            'created_by' => $admin->id,
        ]);

        $question->tags()->sync($this->resolveTagIds($data));

        return $question;
    }

    /**
     * SỬA 14/10 — chuẩn hoá form nhập tay ngay trên trang tài liệu (3 dạng) về đúng dữ liệu buildGradingConfig() hiểu:
     *  · Trắc nghiệm: bắt buộc đủ 4 đáp án + chọn 1 đáp án đúng.
     *  · Đúng / Sai: lưu là trắc nghiệm 2 phương án "Đúng", "Sai" -> mọi màn làm bài/chấm hiện có dùng được ngay.
     *  · Điền từ: ít nhất 1 đáp án được chấp nhận (mỗi dòng một đáp án).
     *  · Mã bài để trống -> tự sinh; đề bài gõ chữ thường (không có thẻ HTML) -> giữ xuống dòng.
     *
     * @throws ValidationException
     */
    private function normalizeManualExerciseInput(array $data): array
    {
        $errors = [];

        if ($data['type'] === 'mcq') {
            $options = array_map(fn ($o) => trim((string) $o), array_slice(array_pad((array) ($data['options'] ?? []), 4, ''), 0, 4));
            if (in_array('', $options, true)) {
                $errors['options'] = 'Nhập đủ 4 đáp án A, B, C, D.';
            }
            if (! isset($data['correct_option']) || $data['correct_option'] === '' || (int) $data['correct_option'] > 3) {
                $errors['correct_option'] = 'Chọn 1 đáp án đúng.';
            }
            $data['options'] = $options;
        } elseif ($data['type'] === 'true_false') {
            if (! in_array($data['tf_answer'] ?? null, ['true', 'false'], true)) {
                $errors['tf_answer'] = 'Chọn nhận định này Đúng hay Sai.';
            }
            $data['type'] = 'mcq';
            $data['options'] = ['Đúng', 'Sai'];
            $data['correct_option'] = ($data['tf_answer'] ?? 'true') === 'true' ? 0 : 1;
        } elseif ($data['type'] === 'fill_blank') {
            if (trim((string) ($data['accepted_answers'] ?? '')) === '') {
                $errors['accepted_answers'] = 'Nhập ít nhất 1 đáp án được chấp nhận.';
            }
        }

        if ($errors !== []) {
            throw ValidationException::withMessages($errors);
        }

        $body = trim((string) ($data['body'] ?? ''));
        if ($body !== '' && $body === strip_tags($body)) {
            $body = nl2br(e($body), false);
        }
        $data['body'] = $body === '' ? null : $body;

        $code = trim((string) ($data['code'] ?? ''));
        if ($code === '') {
            do {
                $code = 'BT-'.strtoupper(\Illuminate\Support\Str::random(6));
            } while ($this->questions->query()->where('code', $code)->exists());
        }
        $data['code'] = $code;

        return $data;
    }

    /** admin.products.exercises.edit — form riêng, đơn giản hơn nhiều so với Kho câu hỏi: chỉ
     *  cho sửa Tiêu đề/Điểm/Tag, test case + tệp đính kèm hiện READ-ONLY (xem lý do ở
     *  productExerciseSave()). */
    public function productExerciseEditFormData(Product $product, Question $exercise): array
    {
        return [
            'product' => $product,
            'exercise' => $exercise->load('tags'),
            'allTags' => $this->tags->allOrderedByName(),
            'isDraft' => $exercise->status === ContentStatus::Draft,
            // SỬA 4/9 — dropdown "Thuộc chương/phần/đề" ở màn Sửa, xem productChaptersFor().
            'chapters' => $this->productChaptersFor($product),
        ];
    }

    /**
     * admin.products.exercises.update — admin bấm "Lưu bài tập". CHỈ cho sửa Tiêu đề/Điểm/Tag
     * — test case nhập từ ZIP giữ NGUYÊN, không cho sửa tay ở đây (ô nhập tay 1-dòng-1-test
     * "input|||output" của Kho câu hỏi dễ làm hỏng test case nhiều dòng đọc thẳng từ ZIP, đã
     * ghi chú ở questionStoreFromZipPackage() phía trên — cố ý không lặp lại rủi ro đó ở đây).
     * status -> Published: bản nháp chính thức trở thành bài tập của sản phẩm, từ nay
     * discardAbandonedDraftsFor() không còn đụng tới bài này nữa.
     */
    public function productExerciseSave(Question $exercise, array $data): Question
    {
        $attributes = [
            'title' => $data['title'],
            'points' => $data['points'] ?? 0,
            // SỬA 4/9 — gắn/gỡ chương-phần-đề ngay ở màn Sửa, xem resolveChapterId().
            'material_id' => $this->resolveChapterId($exercise->product, $data['material_id'] ?? null),
            'status' => ContentStatus::Published->value,
        ];

        // SỬA 14/10 (khách: "thiếu mã bài, cập nhật được mã bài") — mã bài là DUY NHẤT toàn hệ thống (cột unique),
        // để trống thì giữ mã cũ.
        $code = trim((string) ($data['code'] ?? ''));
        if ($code !== '' && $code !== (string) $exercise->code) {
            if ($this->questions->query()->where('code', $code)->whereKeyNot($exercise->id)->exists()) {
                throw ValidationException::withMessages(['code' => "Mã bài \"{$code}\" đã được dùng cho bài khác, chọn mã khác."]);
            }
            $attributes['code'] = $code;
        }

        /*
         * SỬA 14/10 (khách: "dạng lập trình thì sửa được code mẫu, lời giải, đề bài và bộ test — giống sửa câu hỏi ở Kho
         * bài tập") — CHỈ câu Lập trình. Cùng luật với ContentService::questionUpdate():
         *  · Bộ test: chỉ thay khi form gửi bộ test mới ('test_cases_parsed' từ khối "Bộ test"); không đổi thì giữ nguyên.
         *  · Giới hạn thời gian / bộ nhớ / đọc-ghi tệp: lấy từ form.
         *  · GỘP vào cấu hình cũ, không dựng lại từ đầu: các khoá chỉ gói ZIP có (ngôn ngữ cho phép, subtasks…) được giữ.
         *  · Tệp đề bài / lời giải / code mẫu: applyManualUploads() (thay, bỏ tệp — như Kho câu hỏi).
         */
        $isCoding = $exercise->type === \App\Enums\QuestionType::Coding;
        if ($isCoding) {
            $old = $exercise->grading_config ?? [];
            $fresh = $this->buildGradingConfig('coding', $data + ['_existing_test_cases' => $old['test_cases'] ?? []]);
            $merged = array_merge($old, $fresh);
            // Người dùng chọn "Bàn phím / màn hình" -> bỏ hẳn quy ước tên tệp cũ (buildGradingConfig lọc bỏ khoá null).
            if (! array_key_exists('file_io', $fresh) && array_key_exists('io_mode', $data)) {
                unset($merged['file_io']);
            }
            // SỬA 21/10 — chọn lại Cách chấm "Mặc định" -> bỏ khoá checker cũ (gộp không tự xoá).
            if (! array_key_exists('checker', $fresh) && array_key_exists('checker_mode', $data)) {
                unset($merged['checker']);
            }
            $attributes['grading_config'] = $merged;
        }

        /*
         * SỬA 14/10 (khách: "trắc nghiệm, điền từ vẫn cho sửa thoải mái, lỡ nhập lộn") — câu Trắc nghiệm / Đúng-Sai / Điền
         * từ: sửa câu hỏi, đáp án, đáp án đúng, và ĐỔI ĐƯỢC DẠNG giữa 3 dạng này. Chỉ khi form gửi ô 'kind'.
         * Bài tập tài liệu không lưu lượt làm trong CSDL (xem productExerciseDestroy()), nên đổi dạng không làm lệch bài đã nộp.
         */
        if (! $isCoding && isset($data['kind']) && in_array($exercise->type->value, ['mcq', 'fill_blank'], true)) {
            $attributes = array_merge($attributes, $this->manualExerciseEditAttributes($exercise, $data));
        }

        $updated = $this->questions->update($exercise, $attributes);

        $updated->tags()->sync($this->resolveTagIds($data));

        if ($isCoding) {
            $this->applyManualUploads($updated, $data);
        }

        return $updated;
    }

    /**
     * SỬA 14/10 — thuộc tính mới của câu nhập tay khi sửa (xem productExerciseSave()). Khác lúc tạo: trắc nghiệm nhận 2–8
     * đáp án (câu nhập từ ZIP có thể không đủ 4), và GỘP vào cấu hình cũ để giữ các khoá khác (vd bỏ dấu khi chấm).
     *
     * @return array<string, mixed>
     *
     * @throws ValidationException
     */
    private function manualExerciseEditAttributes(Question $exercise, array $data): array
    {
        $kind = $data['kind'];
        $old = $exercise->grading_config ?? [];
        $errors = [];

        if ($kind === 'mcq') {
            $options = array_values(array_map(fn ($o) => trim((string) $o), (array) ($data['options'] ?? [])));
            $correct = isset($data['correct_option']) && $data['correct_option'] !== '' ? (int) $data['correct_option'] : null;
            if (count($options) < 2) {
                $errors['options'] = 'Cần ít nhất 2 đáp án.';
            } elseif (in_array('', $options, true)) {
                $errors['options'] = 'Còn đáp án để trống — nhập nội dung hoặc bấm × để bỏ đáp án đó.';
            }
            if ($correct === null || $correct < 0 || $correct >= count($options)) {
                $errors['correct_option'] = 'Chọn 1 đáp án đúng.';
            }
            $config = array_merge(array_diff_key($old, array_flip(['accepted_answers', 'case_sensitive'])), [
                'options' => $options,
                'correct_options' => $correct === null ? [] : [$correct],
            ]);
            $type = 'mcq';
        } elseif ($kind === 'true_false') {
            if (! in_array($data['tf_answer'] ?? null, ['true', 'false'], true)) {
                $errors['tf_answer'] = 'Chọn nhận định này Đúng hay Sai.';
            }
            $config = array_merge(array_diff_key($old, array_flip(['accepted_answers', 'case_sensitive'])), [
                'options' => ['Đúng', 'Sai'],
                'correct_options' => [($data['tf_answer'] ?? 'true') === 'true' ? 0 : 1],
            ]);
            $type = 'mcq';
        } else {
            $accepted = $this->buildGradingConfig('fill_blank', $data);
            if ($accepted['accepted_answers'] === []) {
                $errors['accepted_answers'] = 'Nhập ít nhất 1 đáp án được chấp nhận.';
            }
            $config = array_merge(array_diff_key($old, array_flip(['options', 'correct_options'])), $accepted);
            $type = 'fill_blank';
        }

        if (array_key_exists('body', $data) && trim(strip_tags((string) ($data['body'] ?? ''), '<img>')) === '') {
            $errors['body'] = 'Nhập nội dung câu hỏi.';
        }

        if ($errors !== []) {
            throw ValidationException::withMessages($errors);
        }

        $attributes = [
            'type' => $type,
            'grading_config' => $config,
            'metadata' => array_merge($exercise->metadata ?? [], ['manual_variant' => $kind]),
        ];

        if (array_key_exists('body', $data)) {
            $body = trim((string) ($data['body'] ?? ''));
            if ($body !== '' && $body === strip_tags($body)) {
                $body = nl2br(e($body), false);
            }
            $attributes['body'] = $body === '' ? null : $body;
        }

        return $attributes;
    }

    /**
     * SỬA 14/10 — ô ẩn `test_cases_json` của khối "Bộ test" (partial admin.content.questions._test-set) -> 'test_cases_parsed'.
     * Cùng luật với ContentController::testCasesFromJson() (Kho câu hỏi); để ở đây cho màn Sửa bài tập của tài liệu dùng.
     * Không gửi ô đó (không đổi bộ test) -> trả nguyên $data, bộ test cũ được giữ.
     *
     * @throws ValidationException
     */
    public static function testCasesFromJsonInput(array $data): array
    {
        $json = $data['test_cases_json'] ?? null;
        unset($data['test_cases_json']);

        if ($json === null || $json === '') {
            return $data;
        }

        $fail = fn (string $message) => ValidationException::withMessages(['test_cases_json' => $message]);

        $decoded = json_decode((string) $json, true);
        if (! is_array($decoded) || ! array_is_list($decoded)) {
            throw $fail('Bộ test gửi lên không đọc được — chưa lưu gì. Hãy nhập lại cặp tệp .in/.out rồi lưu lại.');
        }
        if (count($decoded) > 500) {
            throw $fail('Bộ test có quá 500 test — chưa lưu gì. Hãy chia nhỏ bài hoặc giảm số test.');
        }

        $cases = [];
        foreach ($decoded as $index => $case) {
            if (! is_array($case) || ! is_string($case['input'] ?? null) || ! is_string($case['output'] ?? null)) {
                throw $fail('Test thứ '.($index + 1).' không đúng định dạng (cần có dữ liệu vào và kết quả) — chưa lưu gì.');
            }
            $cases[] = ['input' => $case['input'], 'output' => $case['output']];
        }

        $data['test_cases_parsed'] = $cases;

        return $data;
    }

    /**
     * Xoá bài tập — dùng cho cả (a) nháp bỏ dở (discardAbandonedDraftsFor() tự gọi) lẫn (b)
     * admin chủ động xoá bài đã lưu (nút "Xoá" ở trang chi tiết sản phẩm). Xoá HẲN
     * (forceDelete), KHÔNG soft-delete như Question::delete() mặc định, vì 2 lý do: (1) bài tập
     * sản phẩm không có lịch sử làm bài lưu ở DB để cần giữ lại — luồng "Làm bài"
     * (PracticeByQuestionService) cố ý CHỈ lưu trong session, không ghi Attempt/AttemptAnswer;
     * (2) xoá hẳn mới giải phóng lại cột 'code' (unique) — soft-delete sẽ để hàng cũ chiếm chỗ
     * mã đó, khiến nhập lại ĐÚNG tệp ZIP y hệt (rất dễ xảy ra khi admin thêm-rồi-bỏ-dở-rồi-thêm-
     * lại) báo lỗi trùng khoá ở lần tạo sau. Xoá tệp đính kèm trên đĩa trước, giống
     * materialDelete() ở trên.
     */
    public function productExerciseDestroy(Question $exercise): void
    {
        // SỬA 4/10 — trước đây chỉ xoá metadata.attachments, BỎ SÓT metadata.assets (audio/ảnh
        // của câu hỏi, xem storeZipAssets()). Mỗi lần admin xoá một bài tập sản phẩm là bỏ lại
        // một đống tệp mồ côi trên đĩa. Giờ xoá nguyên thư mục của câu hỏi, xem
        // forgetQuestionFiles().
        $this->forgetQuestionFiles($exercise);

        $exercise->tags()->detach();
        $exercise->forceDelete();
    }

    /**
     * SỬA 4/10 (khách: "khi xoá item nào là tất cả các file liên quan lưu trong thư mục phải xoá
     * hết tránh việc dữ liệu rác sau này nặng nha").
     *
     * XOÁ NGUYÊN THƯ MỤC questions/{id} thay vì dò từng đường dẫn trong metadata. Mọi tệp của
     * một câu hỏi đều nằm dưới đó — đính kèm (storeZipAttachments: questions/{id}/<kind>.<ext>)
     * lẫn asset (storeZipAssets: questions/{id}/assets/<uuid>.<ext>), cả khi nhập từ ZIP lẫn khi
     * tải tay ở màn Sửa. Dò theo metadata thì sót đúng kiểu bản cũ vừa sót: thêm một loại tệp
     * mới là lại quên cập nhật chỗ xoá. Xoá cả thư mục thì không bao giờ sót.
     *
     * Vẫn xoá thêm theo metadata cho chắc: câu hỏi cũ (trước khi có quy ước thư mục) có thể
     * đang trỏ tới đường dẫn nằm ngoài questions/{id}.
     */
    private function forgetQuestionFiles(Question $question): void
    {
        $disk = Storage::disk('local');

        foreach (($question->metadata['attachments'] ?? []) as $attachment) {
            if (filled($attachment['path'] ?? null)) {
                $disk->delete($attachment['path']);
            }
        }

        foreach (($question->metadata['assets'] ?? []) as $asset) {
            if (filled($asset['path'] ?? null)) {
                $disk->delete($asset['path']);
            }
        }

        $disk->deleteDirectory("questions/{$question->id}");
    }

    /**
     * SỬA 4/10 (khách: "phần danh sách bài không thấy nút xoá") — XOÁ MỘT CÂU HỎI ở Kho bài tập.
     *
     * SỬA 7/10 (khách: "khi xoá câu hỏi là cho xoá hết luôn dữ liệu liên quan") — BỎ HAI CHỐT
     * TỪ CHỐI cũ (đã có học sinh làm / đang nằm trong đề). Khách chủ động chọn xoá sạch, nên giờ
     * xoá câu hỏi là xoá luôn MỌI thứ gắn với nó, trong MỘT giao dịch (lỗi giữa chừng thì không
     * xoá gì cả):
     *
     *   - bài làm của học sinh (attempt_answers) và các lượt chấm code của chúng (judge_submissions);
     *   - dòng của câu trong mọi đề (assessment_items) — tổng điểm đề (total_points) bị TRỪ
     *     đúng phần điểm của câu đó, để đề không còn ghi "30 điểm" khi chỉ còn 20 điểm câu hỏi;
     *   - điểm của các lượt làm đã có bài làm bị xoá (attempts.total_score) bị TRỪ tương ứng,
     *     chặn dưới ở 0 — lượt làm vẫn còn, chỉ mất phần điểm của câu này;
     *   - bài mẫu admin chỉ định (practice_sample_submissions), gắn thẻ (question_tag),
     *     bản ghi mở khoá tiến độ theo câu (progress_unlocks — bảng này không có khoá ngoại nên
     *     CSDL KHÔNG tự dọn, phải xoá tay kẻo để lại dòng mồ côi);
     *   - tệp đính kèm trên đĩa (xoá SAU khi giao dịch chốt, vì tệp xoá rồi không hoàn lại được).
     *
     * Các bảng còn lại (session_resources, draft_questions…) khai nullOnDelete nên tự gỡ liên kết.
     * Thao tác không thể khôi phục — giao diện đã hỏi xác nhận bằng lời cảnh báo rõ ràng.
     *
     * Trả về [ok, thông điệp]; vẫn giữ chữ ký cũ để nơi gọi không phải đổi.
     *
     * @return array{0:bool, 1:string}
     */
    public function questionDestroy(Question $question): array
    {
        $stats = DB::transaction(function () use ($question): array {
            $questionId = $question->id;

            // 1. Bài làm của học sinh: gom trước để biết trừ điểm lượt nào bao nhiêu.
            $answers = DB::table('attempt_answers')
                ->where('question_id', $questionId)
                ->get(['id', 'attempt_id', 'score']);

            $answerIds = $answers->pluck('id')->all();
            $lostByAttempt = [];
            foreach ($answers as $answer) {
                $lostByAttempt[$answer->attempt_id] = ($lostByAttempt[$answer->attempt_id] ?? 0) + (float) ($answer->score ?? 0);
            }

            foreach (array_chunk($answerIds, 500) as $chunk) {
                DB::table('judge_submissions')->whereIn('attempt_answer_id', $chunk)->delete();
                DB::table('attempt_answers')->whereIn('id', $chunk)->delete();
            }

            foreach ($lostByAttempt as $attemptId => $lost) {
                if ($lost > 0) {
                    DB::table('attempts')
                        ->where('id', $attemptId)
                        ->whereNotNull('total_score')
                        ->update(['total_score' => DB::raw('CASE WHEN total_score > '.((float) $lost).' THEN total_score - '.((float) $lost).' ELSE 0 END')]);
                }
            }

            // 2. Câu nằm trong đề: gỡ khỏi đề và trừ đúng điểm của nó khỏi tổng điểm đề.
            $items = DB::table('assessment_items')
                ->where('question_id', $questionId)
                ->get(['assessment_id', 'points_override']);

            foreach ($items as $item) {
                $points = (float) ($item->points_override ?? $question->points ?? 0);
                if ($points > 0) {
                    DB::table('assessments')
                        ->where('id', $item->assessment_id)
                        ->update(['total_points' => DB::raw('CASE WHEN total_points > '.$points.' THEN total_points - '.$points.' ELSE 0 END')]);
                }
            }
            DB::table('assessment_items')->where('question_id', $questionId)->delete();

            // 3. Phần còn lại gắn với câu hỏi.
            $samples = DB::table('practice_sample_submissions')->where('question_id', $questionId)->delete();
            DB::table('progress_unlocks')
                ->where('unit_type', ProgressUnitType::Question->value)
                ->where('unit_id', $questionId)
                ->delete();
            $question->tags()->detach();

            return [
                'answers' => count($answerIds),
                'exams' => $items->count(),
                'samples' => $samples,
            ];
        });

        // Tệp trên đĩa: chỉ xoá khi giao dịch đã chốt thành công.
        $this->forgetQuestionFiles($question);
        $question->forceDelete();

        $extras = [];
        if ($stats['answers'] > 0) {
            $extras[] = $stats['answers'].' bài làm của học sinh';
        }
        if ($stats['exams'] > 0) {
            $extras[] = 'câu trong '.$stats['exams'].' đề';
        }
        if ($stats['samples'] > 0) {
            $extras[] = $stats['samples'].' bài mẫu';
        }

        return [true, 'Đã xoá câu hỏi, toàn bộ tệp đính kèm'.($extras === [] ? '.' : ' và dữ liệu liên quan ('.implode(', ', $extras).').')];
    }

    /**
     * SỬA 4/10 — XOÁ MỘT ĐỀ THI, kèm cả 4 tệp của nó.
     *
     * Đề giữ tệp ở 4 cột RỜI NHAU, trên 2 đĩa khác nhau (ảnh bìa ở 'public' để trình duyệt đọc
     * được, 3 PDF ở 'local' vì là nội dung trả phí) và nằm ở thư mục phẳng chứ không gom theo id,
     * nên phải xoá từng đường dẫn một — không có thư mục nào để xoá gọn như câu hỏi.
     *
     * TỪ CHỐI khi đã có lượt làm / đã giao cho lớp / đã gắn vào cuộc thi: attempts, assignments
     * và competition_exams đều cascadeOnDelete, xoá đề là xoá sạch kết quả thi của học sinh.
     *
     * @return array{0:bool, 1:string}
     */
    /**
     * SỬA 3/11 (khách: "khi xoá đề là xoá luôn, câu hỏi nào trong đề đó hay file gì cũng xoá hết") — XOÁ ĐỀ KÈM NỘI DUNG:
     *   1. vẫn chặn như cũ khi đề đang giao cho lớp / đang gắn vào cuộc thi (xoá là hỏng lớp / cuộc thi đó);
     *   2. xoá các lượt làm của đề (bài làm, chấm bài rơi theo cascade) — trước đây có lượt làm là từ chối;
     *   3. xoá đề + mọi tệp của đề bằng ĐÚNG assessmentDestroy() bên dưới;
     *   4. xoá từng câu hỏi của đề bằng ĐÚNG questionDestroy() (đề bài, lời giải, ảnh/âm thanh, bộ test, bài mẫu…) — trừ câu còn
     *      nằm trong đề khác (giữ lại để không làm hỏng đề kia).
     *
     * @return array{0:bool, 1:string}
     */
    public function assessmentDestroyWithContent(Assessment $assessment): array
    {
        if ($assessment->assignments()->count() > 0) {
            return [false, 'Không xoá được: đề đang được giao cho lớp. Gỡ bài giao trước rồi hãy xoá.'];
        }
        if (DB::table('competition_exams')->where('assessment_id', $assessment->id)->exists()) {
            return [false, 'Không xoá được: đề đang gắn vào một cuộc thi. Gỡ khỏi cuộc thi trước rồi hãy xoá.'];
        }

        $questionIds = $assessment->items()->pluck('question_id')->unique()->values()->all();
        $attemptCount = $assessment->attempts()->count();
        if ($attemptCount > 0) {
            DB::table('attempts')->where('assessment_id', $assessment->id)->delete();
        }

        [$ok, $message] = $this->assessmentDestroy($assessment);
        if (! $ok) {
            return [false, $message];
        }

        $deleted = 0;
        $kept = 0;
        foreach (Question::query()->whereIn('id', $questionIds)->get() as $q) {
            if ($q->assessmentItems()->exists()) {
                $kept++;
                continue;
            }
            $this->questionDestroy($q);
            $deleted++;
        }

        return [true, 'Đã xoá đề, toàn bộ tệp đính kèm và '.$deleted.' câu hỏi trong đề'
            .($kept > 0 ? ' (giữ lại '.$kept.' câu vì còn nằm trong đề khác)' : '')
            .($attemptCount > 0 ? ', kèm '.$attemptCount.' lượt làm.' : '.')];
    }

    public function assessmentDestroy(Assessment $assessment): array
    {
        $attemptCount = $assessment->attempts()->count();

        if ($attemptCount > 0) {
            return [false, 'Không xoá được: đã có '.$attemptCount.' lượt làm đề này. '
                .'Xoá sẽ xoá sạch kết quả thi của học sinh. Dùng "Ngừng phát hành" nếu chỉ muốn ẩn đề đi.'];
        }

        if ($assessment->assignments()->count() > 0) {
            return [false, 'Không xoá được: đề đang được giao cho lớp. Gỡ bài giao trước rồi hãy xoá.'];
        }

        if (DB::table('competition_exams')->where('assessment_id', $assessment->id)->exists()) {
            return [false, 'Không xoá được: đề đang gắn vào một cuộc thi. Gỡ khỏi cuộc thi trước rồi hãy xoá.'];
        }

        $this->forgetAssessmentCover($assessment->cover_image_path);
        $this->forgetAssessmentPreviewPdf($assessment->preview_pdf_path);
        $this->forgetAssessmentPreviewPdf($assessment->guide_pdf_path);
        $this->forgetAssessmentPreviewPdf($assessment->sample_pdf_path);

        foreach ([$assessment->pdf_path, $assessment->solution_pdf_path] as $pdfPath) {
            if (filled($pdfPath)) {
                Storage::disk('local')->delete($pdfPath);
            }
        }

        // items / answerKeys / codingItems rơi theo nhờ cascadeOnDelete ở cấp CSDL.
        $assessment->forceDelete();

        return [true, 'Đã xoá đề và toàn bộ tệp đính kèm.'];
    }

    // ================= Đề/bộ bài (Assessment) =================
    // SỬA 18/8: trước đây phạm vi cố ý chỉ giới hạn ở metadata, với giả định "gắn/gỡ câu hỏi
    // vào đề là luồng riêng của giáo viên khi soạn đề (TEA-xx)" — nhưng giả định đó SAI với
    // đề do chính ADMIN tạo (owner_type=shared, vd "Đề thi quốc gia", "Đề thi cuộc thi"):
    // không giáo viên nào sở hữu đề này để vào teacher.assessments.create sửa cả (màn đó chỉ
    // cho giáo viên soạn đề CỦA CHÍNH HỌ, không có màn sửa lại đề đã tạo), nên loại đề admin tự
    // tạo trước giờ không cách nào gắn câu hỏi được (để lại đúng 1 dòng TODO chết ở
    // admin.content.show). Thêm assessmentItemsFormData()/assessmentItemsUpdate() bên dưới để
    // bù đúng khoảng trống đó — CHỈ áp dụng cho đề admin tự quản (không đụng vào luồng soạn đề
    // riêng của giáo viên, vẫn giữ nguyên như cũ).

    public function assessmentCreateFormData(): array
    {
        // SỬA 8/9 (5) (khách: "bên admin khi thêm hay sửa đề/bộ bài cũng ẩn loại Tự luyện đi —
        // ẩn thôi, sau tôi kêu mở thì mở, không được xoá") — loại 'practice' chỉ bị LOẠI KHỎI
        // DANH SÁCH CHỌN khi cờ tắt; enum AssessmentType::Practice, contentModeForType() và mọi
        // đề cũ đang mang loại này đều giữ nguyên. Bật lại: config/features.php ->
        // 'assessment_type_practice' => true (rồi config:cache).
        $types = [
            // SỬA 16/10 (khách: "bỏ 2 dạng Bài giao và Đề thi đấu, cả admin lẫn giáo viên") — chỉ ẨN khỏi các ô chọn khi tạo đề; enum AssessmentType và mọi đề cũ mang 2 loại này giữ nguyên (mở form sửa đề cũ vẫn thấy đúng loại của nó).
            'practice' => 'Luyện tập', 'exam' => 'Đề thi',
        ];

        if (! config('features.assessment_type_practice', false)) {
            unset($types['practice']);
        }

        return [
            'types' => $types,
            'publishAnswerRules' => [
                'never' => 'Không bao giờ hiện đáp án', 'after_deadline' => 'Hiện sau hạn nộp', 'immediately' => 'Hiện ngay sau khi nộp',
            ],
        ];
    }

    /**
     * SỬA 18/8 (đề PDF, theo file khách chốt "chốt chức năng đề luyện tập tài liệu" mục
     * 1.1/1.2): content_mode do HỆ THỐNG tự suy ra từ type, KHÔNG cho admin tự chọn — chỉ
     * "Luyện tập" (practice) mới dùng câu hỏi rời (structured); Bài giao/Đề thi/Đề thi đấu
     * đều bắt buộc dùng PDF + phiếu đáp án. Xem App\Enums\AssessmentContentMode.
     */
    private function contentModeForType(string $type): string
    {
        // SỬA 20/10 (khách: "Đề thi cách thêm y đúc Luyện tập") — Đề thi giờ cũng là câu hỏi rời từ Kho câu hỏi như Luyện tập.
        // Tạo / thêm câu / Chấm câu giống hệt Luyện tập, chỉ khác Loại (Đề thi gắn được vào Cuộc thi — đề đang dùng cho Cuộc
        // thi thì không có Chấm câu, xem Student\AssessmentService::canGradeQuestions()). Đề thi PDF cũ vẫn là PDF (assessmentUpdate giữ nguyên); Bài giao / Đề thi đấu vẫn PDF như trước.
        return in_array($type, [AssessmentType::Practice->value, AssessmentType::Exam->value], true)
            ? AssessmentContentMode::Structured->value
            : AssessmentContentMode::PdfAnswerSheet->value;
    }

    public function assessmentStore(User $admin, array $data, ?UploadedFile $cover = null): Assessment
    {
        $removeCover = false;

        return $this->assessments->create([
            'title' => $data['title'],
            'type' => $data['type'],
            'content_mode' => $this->contentModeForType($data['type']),
            // SỬA 23/9 (khách: "nhập điểm cho từng câu") — đề mới chưa có câu nào thì 0 điểm;
            // con số thật do màn "Chọn câu hỏi" cộng lại, form này không còn ô Tổng điểm.
            'total_points' => 0,
            'duration_minutes' => $data['duration_minutes'] ?: null,
            'publish_answer_rule' => $data['publish_answer_rule'] ?? 'never',
            // SỬA 2/10 — 6 trường mô tả đề cho bản mẫu UI mới. Tỉnh/thành và Loại đề chuẩn
            // hoá qua catalog chứ không tin thẳng input: mã lạ thành null = "chưa gán", không
            // lưu rác vào cột lọc (cùng cách đã làm với questions.subject/province).
            ...$this->assessmentDetailAttributes($data, $cover, $removeCover, null),
            'status' => ContentStatus::Draft->value,
            'version' => 1,
            // SỬA 6/11 — giáo viên tạo đề từ màn của quản trị (App\Support\TeacherContentScope): đề thuộc kho riêng của giáo viên.
            ...\App\Support\TeacherContentScope::ownerAttributes($admin),
            'created_by' => $admin->id,
        ]);
    }

    public function assessmentEditFormData(int $id): array
    {
        $assessment = $this->assessments->query()->findOrFail($id);
        $form = $this->assessmentCreateFormData();

        // SỬA 16/10 — loại ĐANG CÓ của đề phải luôn nằm trong ô "Loại" (Luyện tập đang bị cờ ẩn, hoặc Bài giao / Đề thi đấu
        // vừa bị ẩn khỏi form tạo mới) — thiếu thì bấm Lưu là đề bị đổi sang loại khác một cách lặng lẽ.
        $typeValue = $assessment->type instanceof \BackedEnum ? $assessment->type->value : (string) $assessment->type;
        $allLabels = ['practice' => 'Luyện tập', 'assignment' => 'Bài giao', 'exam' => 'Đề thi', 'competition_paper' => 'Đề thi đấu'];
        if (isset($allLabels[$typeValue]) && ! isset($form['types'][$typeValue])) {
            $form['types'] = [$typeValue => $allLabels[$typeValue]] + $form['types'];
        }

        return array_merge($form, ['assessment' => $assessment]);
    }

    /**
     * admin.content.assessments.items.edit — dữ liệu cho màn chọn câu hỏi. Admin xem/chọn
     * được TOÀN BỘ câu hỏi (Kho chung + kho riêng từng giáo viên — allLatestWithOwner() đã
     * có sẵn, dùng lại đúng chỗ tab "Câu hỏi" ở admin.content.index đang dùng, xem
     * indexData()), không giới hạn theo 1 giáo viên như teacher.assessments.create.
     */
    public function assessmentItemsFormData(Assessment $assessment): array
    {
        $assessment->load('items.question');
        $existingItems = $assessment->items->keyBy('question_id');

        return [
            'assessment' => $assessment,
            // SỬA 6/11 — giáo viên (TeacherContentScope) chỉ chọn được câu trong kho của chính mình.
            'questions' => (($tid = \App\Support\TeacherContentScope::teacherId()) !== null
                ? Question::query()->with('owner')->whereNull('product_id')->where('owner_type', OwnerType::Teacher->value)->where('owner_id', $tid)->latest()->limit(500)->get()
                : $this->questions->allLatestWithOwner(200))->map(fn (Question $q) => [
                'id' => $q->id,
                'code' => (string) $q->code, // SỬA 10/10 — để tìm theo mã ở màn chọn câu
                'title' => $q->title,
                'type' => $q->type->value,
                // SỬA 11/10 — đây CHỈ là số GỢI Ý điền sẵn vào ô nhập điểm của câu chưa có trong
                // đề (suy từ độ khó). Người ra đề nhập số của mình, số đó mới là điểm được chấm
                // — xem assessmentItemsUpdate().
                'points' => QuestionDifficulty::pointsForQuestion($q->metadata, (int) $q->points),
                'difficultyLabel' => QuestionDifficulty::label(QuestionDifficulty::resolve($q->metadata, (int) $q->points)),
                'status' => $q->status->value,
                'ownerLabel' => $q->owner_type === OwnerType::Shared ? 'Kho chung' : ('GV '.($q->owner->name ?? '')),
            ])->all(),
            'selectedIds' => $existingItems->keys()->all(),
            // SỬA 11/10 (khách: "điểm từng câu để người dùng nhập") — điểm ĐÃ CHỐT trong đề, điền
            // lại vào ô nhập khi mở màn sửa. Câu chưa có trong đề thì ô hiện số gợi ý ban đầu
            // ('points' ở trên, suy từ độ khó) để người ra đề sửa theo ý mình.
            'pointsOverrides' => $existingItems
                ->filter(fn ($item) => $item->points_override !== null)
                ->map(fn ($item) => (float) $item->points_override)
                ->all(),
        ];
    }

    /**
     * SỬA 11/10 — đặt điểm cho MỘT câu trong đề (người dùng nhập), rồi cộng lại total_points.
     */
    public function assessmentItemSetPoints(Assessment $assessment, \App\Models\AssessmentItem $item, float $points): void
    {
        DB::transaction(function () use ($assessment, $item, $points) {
            $item->forceFill(['points_override' => AssessmentPoints::resolve($points, $points)])->save();

            $assessment->unsetRelation('items');
            $total = $this->derivedTotalPoints($assessment);

            if ($total !== null) {
                $this->assessments->update($assessment, ['total_points' => $total]);
            }
        });
    }

    /**
     * SỬA 9/10 — dời 1 câu trong đề: 'up' lên một bậc, 'down' xuống một bậc, 'top' lên đầu.
     * Chuẩn hoá cột order về 0..n-1 trước (đề cũ có thể trùng/lệch số), rồi đổi chỗ — nên bấm
     * lần nào cũng có tác dụng. Chỉ đổi order, KHÔNG đụng điểm hay câu hỏi.
     */
    public function assessmentItemMove(Assessment $assessment, \App\Models\AssessmentItem $item, string $direction): void
    {
        DB::transaction(function () use ($assessment, $item, $direction) {
            $ids = \App\Models\AssessmentItem::query()
                ->where('assessment_id', $assessment->id)
                ->orderBy('order')
                ->orderBy('id')
                ->pluck('id')
                ->all();

            $from = array_search($item->id, $ids, true);
            if ($from === false) {
                return;
            }

            $to = match ($direction) {
                'up' => max(0, $from - 1),
                'down' => min(count($ids) - 1, $from + 1),
                default => 0,
            };

            if ($to !== $from) {
                $moved = array_splice($ids, $from, 1);
                array_splice($ids, $to, 0, $moved);
            }

            foreach ($ids as $position => $id) {
                \App\Models\AssessmentItem::query()->whereKey($id)->update(['order' => $position]);
            }
        });
    }

    /**
     * admin.content.assessments.items.update — thay TOÀN BỘ danh sách câu hỏi trong đề bằng
     * danh sách mới chọn (xoá hết item cũ rồi tạo lại theo đúng thứ tự tick trên form — đơn
     * giản, đủ dùng cho phạm vi này, giống cách teacher.assessments.store xử lý lúc tạo mới).
     * Tự tính lại total_points = tổng điểm từng câu NGƯỜI DÙNG NHẬP (points_override).
     */
    public function assessmentItemsUpdate(Assessment $assessment, array $data): Assessment
    {
        $questionIds = $data['question_ids'];

        $validQuestions = $this->questions->query()->whereIn('id', $questionIds)->get()->keyBy('id');

        $assessment->items()->delete();

        $pointsList = [];
        foreach (array_values($questionIds) as $order => $questionId) {
            $question = $validQuestions->get($questionId);
            if ($question === null) {
                continue;
            }

            /*
             * SỬA 23/9 (khách: "nhập điểm cho từng câu") — LUÔN GHI points_override, kể cả khi
             * trùng đúng điểm của câu trong kho (để null thì AttemptService::maxPointsFor() quay
             * về questions.points, sửa điểm gốc trong kho là điểm đề đã chốt âm thầm đổi theo).
             *
             * SỬA 11/10 (khách: "điểm từng câu để người dùng nhập, đừng lấy điểm của độ khó.
             * Khi chấm điểm tính theo số điểm nhập") — con số lấy từ ô nhập $data['points'][id]
             * (số nguyên hoặc thập phân). Chỉ khi ô để trống mới rơi về số gợi ý theo độ khó.
             * Số này ghi vào assessment_items.points_override, và việc chấm bài, tổng điểm đề,
             * kết quả làm bài đều đọc đúng cột đó.
             */
            $points = AssessmentPoints::resolve(
                $data['points'][$question->id] ?? null,
                (float) QuestionDifficulty::pointsForQuestion($question->metadata, (int) $question->points)
            );

            $assessment->items()->create([
                'question_id' => $question->id,
                'order' => $order,
                'points_override' => $points,
            ]);

            $pointsList[] = $points;
        }

        return $this->assessments->update($assessment, ['total_points' => AssessmentPoints::sum($pointsList)]);
    }

    /**
     * SỬA 23/9 (khách báo "30.00 / 10 · 300% số điểm") — TỔNG ĐIỂM CỦA ĐỀ LÀ SỐ TỰ TÍNH,
     * KHÔNG phải số admin gõ tay.
     *
     * Trước đây ô "Tổng điểm" trên form Sửa đề ghi đè thẳng vào assessments.total_points. Đề
     * tạo mới mặc định 10 điểm, gắn 5 câu Lập trình (mỗi câu 10 điểm trong kho) thì
     * assessmentItemsUpdate() đã tính lại đúng thành 50 — nhưng chỉ cần mở lại form Sửa đề và
     * bấm Lưu (ô Tổng điểm vẫn đang hiện 10) là con số 50 bị đạp về 10. Kết quả: học sinh làm
     * đúng hết ra 50/10 = 500%.
     *
     * Quy tắc chốt: đề ĐÃ CÓ CÂU thì tổng điểm = tổng điểm từng câu (ưu tiên points_override),
     * số gõ tay bị bỏ qua. Đề CHƯA CÓ CÂU nào mới dùng số gõ tay (đề PDF tự chấm điểm riêng
     * qua PdfAssessmentEditingService, cũng không có item nên không bị đụng).
     */
    /** SỬA 16/10 — bỏ 1 câu khỏi đề: xoá dòng gắn (câu vẫn ở Kho), đánh lại thứ tự 0..n-1, cộng lại tổng điểm. */
    public function assessmentItemRemove(Assessment $assessment, \App\Models\AssessmentItem $item): void
    {
        DB::transaction(function () use ($assessment, $item) {
            $item->delete();

            $ids = \App\Models\AssessmentItem::query()
                ->where('assessment_id', $assessment->id)
                ->orderBy('order')
                ->orderBy('id')
                ->pluck('id')
                ->all();
            foreach ($ids as $i => $id) {
                \App\Models\AssessmentItem::query()->whereKey($id)->update(['order' => $i]);
            }

            $assessment->unsetRelation('items');
            $this->assessments->update($assessment, ['total_points' => $this->derivedTotalPoints($assessment) ?? 0]);
        });
    }

    /**
     * SỬA 16/10 — phát hành mọi câu còn Nháp trong đề (vd vừa nhập cả đề từ gói ZIP). Câu chưa đủ điều kiện (thiếu đáp án,
     * thiếu test…) bị bỏ qua và báo lại tên + lý do, không chặn các câu khác.
     *
     * @return array{published: int, failed: array<int, string>}
     */
    public function assessmentPublishAllQuestions(Assessment $assessment): array
    {
        $assessment->loadMissing('items.question');
        $published = 0;
        $failed = [];

        foreach ($assessment->items as $item) {
            $question = $item->question;
            if ($question === null || $question->status === ContentStatus::Published) {
                continue;
            }
            $result = $this->questionPublish($question);
            if ($result['ok']) {
                $published++;
            } else {
                $failed[] = 'Câu "'.$question->title.'": '.$result['message'];
            }
        }

        return ['published' => $published, 'failed' => $failed];
    }

    private function derivedTotalPoints(Assessment $assessment): ?float
    {
        $assessment->loadMissing('items.question');

        if ($assessment->items->isEmpty()) {
            return null;
        }

        // SỬA 11/10 — điểm có thể là số thập phân, KHÔNG ép int (ép là 4.5 + 4.5 thành 8).
        return AssessmentPoints::sum(
            $assessment->items->map(fn ($item) => $item->points_override ?? $item->question?->points ?? 0)
        );
    }

    public function assessmentUpdate(Assessment $assessment, array $data, ?UploadedFile $cover = null, bool $removeCover = false): Assessment
    {
        $derived = $this->derivedTotalPoints($assessment);

        return $this->assessments->update($assessment, [
            'title' => $data['title'],
            'type' => $data['type'],
            // SỬA 16/10 — đề Luyện tập tạo từ gói ZIP là đề PDF + phiếu đáp án: sửa thông tin chung KHÔNG được ép nó về
            // chế độ câu hỏi rời (mất hết PDF/đáp án trên màn). Luyện tập đang là đề PDF thì giữ đề PDF.
            // SỬA 20/10 — Đề thi PDF đã có (tạo trước khi Đề thi chuyển sang câu hỏi rời, hoặc nhập gói đề PDF) cũng giữ PDF.
            'content_mode' => in_array($data['type'], [AssessmentType::Practice->value, AssessmentType::Exam->value], true) && $assessment->isPdfMode()
                ? AssessmentContentMode::PdfAnswerSheet->value
                : $this->contentModeForType($data['type']),
            // Đề có câu -> cộng lại từ các câu. Đề chưa có câu (hoặc đề PDF, điểm do
            // PdfAssessmentEditingService tính riêng) -> GIỮ NGUYÊN số đang có, không đạp về 0.
            'total_points' => $derived ?? $assessment->total_points,
            'duration_minutes' => $data['duration_minutes'] ?: null,
            'publish_answer_rule' => $data['publish_answer_rule'] ?? 'never',
            // SỬA 2/10 — 6 trường mô tả đề cho bản mẫu UI mới. Tỉnh/thành và Loại đề chuẩn
            // hoá qua catalog chứ không tin thẳng input: mã lạ thành null = "chưa gán", không
            // lưu rác vào cột lọc (cùng cách đã làm với questions.subject/province).
            ...$this->assessmentDetailAttributes($data, $cover, $removeCover, $assessment),
        ]);
    }

    /**
     * SỬA 2/10 — 6 trường mô tả đề (mô tả ngắn / tác giả / tỉnh thành / năm học / loại đề / ảnh
     * bìa) dùng CHUNG cho assessmentStore() và assessmentUpdate(), để hai đường không lệch nhau.
     *
     * Ảnh bìa đi theo đúng khuôn CourseService::coverAttribute(): KHÔNG trả khoá
     * 'cover_image_path' khi người dùng không đụng gì tới ảnh (không chọn tệp mới, không tick
     * gỡ ảnh) — nhờ vậy cột đó không nằm trong câu UPDATE và ảnh cũ được giữ nguyên. Ghi thẳng
     * `$cover ?? null` là mỗi lần lưu form lại xoá mất ảnh đang có.
     *
     * @return array<string, mixed>
     */
    private function assessmentDetailAttributes(array $data, ?UploadedFile $cover, bool $removeCover, ?Assessment $existing): array
    {
        $attributes = [
            'subtitle' => filled($data['subtitle'] ?? null) ? trim((string) $data['subtitle']) : null,
            'author' => filled($data['author'] ?? null) ? trim((string) $data['author']) : null,
            'province' => ProvinceCatalog::normalize($data['province'] ?? null),
            'academic_year' => filled($data['academic_year'] ?? null) ? trim((string) $data['academic_year']) : null,
            'exam_category' => ExamCategory::normalize($data['exam_category'] ?? null),
            'exam_level' => \App\Support\ExamLevel::normalize($data['exam_level'] ?? null), // SỬA 12/10
            // SỬA 7/10 — độ khó 1-5; ngoài khoảng/để trống -> null ("chưa xếp").
            'difficulty_level' => filled($data['difficulty_level'] ?? null) && (int) $data['difficulty_level'] >= 1 && (int) $data['difficulty_level'] <= 5 ? (int) $data['difficulty_level'] : null,
            // SỬA 7/10 — số sao đánh giá nhập tay; chỉ lưu khi có ĐỦ cả điểm lẫn số lượt.
            'rating_score' => filled($data['rating_score'] ?? null) && filled($data['rating_count'] ?? null) ? round(max(0, min(5, (float) $data['rating_score'])), 1) : null,
            'rating_count' => filled($data['rating_score'] ?? null) && filled($data['rating_count'] ?? null) ? max(0, (int) $data['rating_count']) : 0,
        ];

        /*
         * SỬA 2/10 lần 3 — TỆP PDF XEM TRƯỚC. Lấy thẳng từ $data (Validator trả về đối tượng
         * UploadedFile cho ô kiểu file) nên không phải nối thêm tham số qua 3 lớp gọi.
         *
         * Tệp cũ bị xoá khỏi disk khi thay tệp mới hoặc khi tích "Gỡ tệp", cùng nếp với ảnh bìa
         * — không xoá thì mỗi lần sửa lại bỏ lại một tệp PDF chết trong storage.
         */
        $previewPdf = ($data['preview_pdf'] ?? null) instanceof UploadedFile ? $data['preview_pdf'] : null;

        if ($previewPdf !== null) {
            $this->forgetAssessmentPreviewPdf($existing?->preview_pdf_path);
            $attributes['preview_pdf_path'] = $previewPdf->store(self::ASSESSMENT_PREVIEW_DIR, self::ASSESSMENT_PREVIEW_DISK);
            $attributes['preview_pdf_original_name'] = $previewPdf->getClientOriginalName();
        } elseif (! empty($data['remove_preview_pdf'])) {
            $this->forgetAssessmentPreviewPdf($existing?->preview_pdf_path);
            $attributes['preview_pdf_path'] = null;
            $attributes['preview_pdf_original_name'] = null;
        }

        // SỬA 11/10 — PDF Hướng dẫn / Bài mẫu: cùng nếp với tệp xem trước (thay tệp mới / tích "Gỡ" thì xoá tệp cũ khỏi disk).
        foreach (['guide', 'sample'] as $docKind) {
            $docFile = ($data[$docKind.'_pdf'] ?? null) instanceof UploadedFile ? $data[$docKind.'_pdf'] : null;

            if ($docFile !== null) {
                $this->forgetAssessmentPreviewPdf($existing?->{$docKind.'_pdf_path'});
                $attributes[$docKind.'_pdf_path'] = $docFile->store('assessments/'.$docKind, self::ASSESSMENT_PREVIEW_DISK);
                $attributes[$docKind.'_pdf_original_name'] = $docFile->getClientOriginalName();
            } elseif (! empty($data['remove_'.$docKind.'_pdf'])) {
                $this->forgetAssessmentPreviewPdf($existing?->{$docKind.'_pdf_path'});
                $attributes[$docKind.'_pdf_path'] = null;
                $attributes[$docKind.'_pdf_original_name'] = null;
            }
        }

        // SỬA 10/10 — ảnh bìa chọn từ catalog (AssessmentCover). Ưu tiên: tải ảnh riêng > chọn catalog > gỡ ảnh.
        // Ảnh tải lên cũ bị xoá khỏi disk khi chuyển sang ảnh khác; ảnh catalog là ảnh dùng chung, không xoá.
        $catalogId = \App\Support\AssessmentCover::normalize($data['cover_catalog'] ?? null);

        if ($cover !== null) {
            $this->forgetAssessmentCover($existing?->cover_image_path);
            $attributes['cover_image_path'] = ImageOptimizer::store($cover, self::ASSESSMENT_COVER_DIR, self::ASSESSMENT_COVER_DISK);
        } elseif ($catalogId !== null) {
            $this->forgetAssessmentCover($existing?->cover_image_path);
            $attributes['cover_image_path'] = \App\Support\AssessmentCover::marker($catalogId);
        } elseif ($removeCover) {
            $this->forgetAssessmentCover($existing?->cover_image_path);
            $attributes['cover_image_path'] = null;
        }

        return $attributes;
    }

    /** Xoá tệp ảnh bìa cũ khỏi disk khi thay ảnh mới hoặc gỡ ảnh — tránh để lại rác. */
    private function forgetAssessmentCover(?string $path): void
    {
        if ($path !== null && Storage::disk(self::ASSESSMENT_COVER_DISK)->exists($path)) {
            Storage::disk(self::ASSESSMENT_COVER_DISK)->delete($path);
        }
    }

    /** Như trên, cho tệp PDF xem trước. */
    private function forgetAssessmentPreviewPdf(?string $path): void
    {
        if ($path !== null && Storage::disk(self::ASSESSMENT_PREVIEW_DISK)->exists($path)) {
            Storage::disk(self::ASSESSMENT_PREVIEW_DISK)->delete($path);
        }
    }

    /**
     * SỬA 18/8 (đề PDF): đề content_mode=pdf_answer_sheet PHẢI qua PdfAssessmentPublishGuard
     * trước khi phát hành (16/8 mục 5: "đề chưa hoàn thiện không bị lộ ra ngoài") — đề
     * content_mode=structured giữ nguyên hành vi cũ, không có guard (chưa có quy tắc nào
     * được đặc tả cho loại đó).
     *
     * @return array{ok: bool, message: ?string}
     */
    public function assessmentPublish(Assessment $assessment): array
    {
        if ($assessment->isPdfMode()) {
            $decision = $this->pdfAssessmentGuard->canPublish($assessment);
            if (! $decision->allowed) {
                return ['ok' => false, 'message' => $decision->message ?? 'Chưa đủ điều kiện phát hành.'];
            }
        }

        $this->assessments->update($assessment, ['status' => ContentStatus::Published->value]);

        return ['ok' => true, 'message' => null];
    }

    public function assessmentReject(Assessment $assessment, string $reason): Assessment
    {
        Assessment::$auditReason = $reason;
        $this->assessments->update($assessment, ['status' => ContentStatus::Draft->value]);
        Assessment::$auditReason = null;

        return $assessment;
    }

    public function assessmentArchive(Assessment $assessment, string $reason): Assessment
    {
        Assessment::$auditReason = $reason;
        $this->assessments->update($assessment, ['status' => ContentStatus::Archived->value]);
        Assessment::$auditReason = null;

        return $assessment;
    }

    /**
     * SỬA 19/8 (Giai đoạn 4 — "Admin duyệt đưa đề giáo viên tạo ra kho chung"): trước đây
     * KHÔNG có cơ chế nào để chuyển 1 đề do giáo viên tạo (owner_type=teacher) sang Kho chung
     * (owner_type=shared, owner_id=null) — mọi đề GV tạo mãi mãi thuộc riêng GV đó, kể cả khi
     * chất lượng tốt và Admin muốn dùng chung cho toàn hệ thống. Đây là hành động ĐƠN GIẢN,
     * chỉ đổi quyền sở hữu — KHÔNG đụng tới questions/materials/product đã gắn kèm (nếu có),
     * KHÔNG đổi status/version, và KHÔNG xoá created_by (giữ lại để vẫn biết đề này gốc do ai
     * tạo, hiển thị được ở nơi khác nếu cần — chỉ owner_type/owner_id đổi để đề hiện đúng
     * "Kho chung" ở tab Đề/bộ bài và các màn chọn đề dùng chung khác).
     *
     * Đề đã ở Kho chung rồi (owner_type=shared) thì không có gì để duyệt thêm — chặn sớm bằng
     * ValidationException thay vì âm thầm no-op, để controller trả lỗi rõ ràng nếu có ai bấm
     * nhầm/gọi thẳng route (vd 2 tab admin cùng mở, 1 tab đã duyệt xong trước).
     */
    public function assessmentPromoteToShared(Assessment $assessment): Assessment
    {
        if ($assessment->owner_type === OwnerType::Shared) {
            throw ValidationException::withMessages(['assessment' => 'Đề này đã ở Kho chung rồi, không cần duyệt thêm.']);
        }

        return $this->assessments->update($assessment, [
            'owner_type' => OwnerType::Shared->value,
            'owner_id' => null,
        ]);
    }

    // ================= "Bộ đề" — nhập hàng loạt nhiều đề PDF (Giai đoạn 3, 19/8) ==========
    // 2 cách, theo đúng lựa chọn của khách: (1) tách từ 1 file PDF lớn theo khoảng trang khai
    // sẵn, (2) tải nhiều file PDF riêng lẻ cùng lúc. Toàn bộ đề tạo ra đều content_mode=
    // pdf_answer_sheet, owner_type=shared (kho chung, giống assessmentStore() ở trên) — KHÔNG
    // có type "Luyện tập" (chỉ Luyện tập theo câu mới dùng structured, xem
    // AssessmentContentMode). Đáp án vẫn phải nhập tay sau đó ở màn "Quản lý đề PDF" — bulk chỉ
    // lo tạo khung đề + gắn đúng file PDF, không đọc/OCR nội dung.

    public function assessmentBulkCreateFormData(): array
    {
        return ['types' => $this->bulkTypeOptions()];
    }

    private function bulkTypeOptions(): array
    {
        return [
            // SỬA 16/10 (khách: "bỏ 2 dạng Bài giao và Đề thi đấu, cả admin lẫn giáo viên") — chỉ ẨN khỏi các ô chọn khi tạo đề; enum AssessmentType và mọi đề cũ mang 2 loại này giữ nguyên (mở form sửa đề cũ vẫn thấy đúng loại của nó).
            // Thêm Luyện tập (đề PDF + phiếu đáp án, PdfBulkImportService luôn tạo đề PDF).
            AssessmentType::Practice->value => 'Luyện tập',
            AssessmentType::Exam->value => 'Đề thi',
        ];
    }

    /** @param  array  $rows  @return Collection<int, Assessment> */
    public function assessmentBulkSplit(User $admin, UploadedFile $sourcePdf, array $rows): Collection
    {
        return $this->pdfBulkImport->splitIntoAssessments($admin, OwnerType::Shared, null, $sourcePdf, $rows);
    }

    /**
     * @param  array<int, UploadedFile>  $files
     * @param  array  $meta
     * @return Collection<int, Assessment>
     */
    public function assessmentBulkMulti(User $admin, array $files, array $meta): Collection
    {
        return $this->pdfBulkImport->createFromMultipleFiles($admin, OwnerType::Shared, null, $files, $meta);
    }

    // ================= Đề PDF + phiếu đáp án (16/8 mục 1.2/5/6) =================
    // SỬA 18/8: đề content_mode=pdf_answer_sheet KHÔNG dùng assessmentItemsFormData/Update ở
    // trên (đó là cho content_mode=structured — gắn Question thật vào assessment_items).
    // Đề PDF không có Question nào cả — chỉ có 1 file PDF + đáp án đúng từng câu
    // (AssessmentAnswerKey) và/hoặc bài lập trình con (AssessmentCodingItem).
    // SỬA 18/8 (2): toàn bộ xử lý thật đã chuyển sang App\Services\PdfAssessmentEditingService
    // (dùng chung với Teacher\AssessmentService) — các hàm dưới đây chỉ là lớp mỏng giữ
    // nguyên tên/route cũ cho AdminContentController, không đổi hành vi.

    /** admin.content.assessments.pdf.edit — dữ liệu màn cấu hình đề PDF. */
    public function assessmentPdfFormData(Assessment $assessment): array
    {
        return $this->pdfEditing->formData($assessment);
    }

    /** admin.content.assessments.pdf.update. @param  array  $answerKeyRows */
    public function assessmentPdfUpdate(
        Assessment $assessment,
        array $data,
        array $answerKeyRows,
        ?UploadedFile $pdf,
        ?UploadedFile $solutionPdf,
    ): Assessment {
        return $this->pdfEditing->update($assessment, $data, $answerKeyRows, $pdf, $solutionPdf);
    }

    /** admin.content.assessments.coding-items.store — thêm 1 bài lập trình con vào đề PDF. */
    public function codingItemStore(Assessment $assessment, array $data): AssessmentCodingItem
    {
        return $this->pdfEditing->codingItemStore($assessment, $data);
    }

    public function codingItemUpdate(AssessmentCodingItem $item, array $data): AssessmentCodingItem
    {
        return $this->pdfEditing->codingItemUpdate($item, $data);
    }

    public function codingItemDestroy(AssessmentCodingItem $item): void
    {
        $this->pdfEditing->codingItemDestroy($item);
    }

    /** admin.content.assessments.coding-items.test-cases.import — tải 1 gói ZIP input/output. */
    public function codingItemImportTestCasesZip(AssessmentCodingItem $item, UploadedFile $zip): int
    {
        return $this->pdfEditing->codingItemImportTestCasesZip($item, $zip);
    }

    /** @return array<string, string> */
    private function statusOptions(): array
    {
        return [
            ContentStatus::Draft->value => 'Nháp',
            ContentStatus::PendingReview->value => 'Chờ duyệt',
            ContentStatus::Published->value => 'Phát hành',
            ContentStatus::Archived->value => 'Lưu trữ',
        ];
    }

}
