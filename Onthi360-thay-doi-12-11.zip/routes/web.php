<?php

use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\Auth\PasswordResetController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\Student\DashboardController as StudentDashboardController;
use App\Http\Controllers\NotificationController;
// SỬA 4/11 — trang đọc đủ thông báo + thông báo Quản trị ghim trang chủ; mục "Thông báo" khu quản trị.
use App\Http\Controllers\NotificationDetailController;
use App\Http\Controllers\Admin\AnnouncementController as AdminAnnouncementController;
use App\Http\Controllers\Public\CompetitionController as PublicCompetitionController;
use App\Http\Controllers\Public\CourseController as PublicCourseController;
use App\Http\Controllers\Public\LearningPathController as PublicLearningPathController;
use App\Http\Controllers\Public\HomeController as PublicHomeController;
use App\Http\Controllers\Public\InfoController as PublicInfoController;
use App\Http\Controllers\Public\ContactController as PublicContactController;
use App\Http\Controllers\Public\LeaderboardController as PublicLeaderboardController;
use App\Http\Controllers\Public\MaterialAssignmentController as PublicMaterialAssignmentController;
use App\Http\Controllers\Public\MaterialController as PublicMaterialController;
use App\Http\Controllers\Public\PracticeController as PublicPracticeController;
use App\Http\Controllers\Public\PracticeAssignmentController as PublicPracticeAssignmentController;
use App\Http\Controllers\Public\PracticeHistoryController as PublicPracticeHistoryController;
use App\Http\Controllers\Public\SitemapController as PublicSitemapController;
use App\Http\Controllers\Public\TeacherController as PublicTeacherController;
use App\Http\Controllers\Student\AssessmentController as StudentAssessmentController;
use App\Http\Controllers\Student\ClassRoomController as StudentClassRoomController;
use App\Http\Controllers\Student\CompetitionController as StudentCompetitionController;
use App\Http\Controllers\Student\CourseController as StudentCourseController;
use App\Http\Controllers\Student\LibraryController as StudentLibraryController;
use App\Http\Controllers\Student\MaterialController as StudentMaterialController;
use App\Http\Controllers\Student\ProductReadController as StudentProductReadController;
use App\Http\Controllers\Student\NotificationController as StudentNotificationController;
use App\Http\Controllers\Student\PracticeByQuestionController as StudentPracticeByQuestionController;
use App\Http\Controllers\Student\PracticeController as StudentPracticeController;
use App\Http\Controllers\Student\ProfileController as StudentProfileController;
use App\Http\Controllers\Student\ScheduleController as StudentScheduleController;
use App\Http\Controllers\Student\AssignmentController as StudentAssignmentController;
use App\Http\Controllers\Student\ResultController as StudentResultController;
use App\Http\Controllers\Student\ReviewController as StudentReviewController;
use App\Http\Controllers\Student\ParentController as StudentParentController;
use App\Http\Controllers\Teacher\AssessmentController as TeacherAssessmentController;
use App\Http\Controllers\Teacher\ClassRoomController as TeacherClassRoomController;
use App\Http\Controllers\Teacher\CompetitionController as TeacherCompetitionController;
use App\Http\Controllers\Teacher\DashboardController as TeacherDashboardController;
use App\Http\Controllers\Teacher\LibraryController as TeacherLibraryController;
use App\Http\Controllers\Teacher\MaterialController as TeacherMaterialController;
use App\Http\Controllers\Teacher\ProductReadController as TeacherProductReadController;
use App\Http\Controllers\Teacher\QuestionController as TeacherQuestionController;
use App\Http\Controllers\Teacher\ResultController as TeacherResultController;
use App\Http\Controllers\Teacher\ScheduleController as TeacherScheduleController;
use App\Http\Controllers\Teacher\NotificationController as TeacherNotificationController;
use App\Http\Controllers\Teacher\NoticeController as TeacherNoticeController;
use App\Http\Controllers\Teacher\WorkController as TeacherWorkController;
use App\Http\Controllers\Teacher\ProfileController as TeacherProfileController;
use App\Http\Controllers\Parent\AssignmentController as ParentAssignmentController;
use App\Http\Controllers\Parent\ChildController as ParentChildController;
use App\Http\Controllers\Parent\DeviceController as ParentDeviceController;
use App\Http\Controllers\Parent\ClassReviewController as ParentClassReviewController;
use App\Http\Controllers\Parent\DashboardController as ParentDashboardController;
use App\Http\Controllers\Parent\NotificationController as ParentNotificationController;
use App\Http\Controllers\Parent\ProfileController as ParentProfileController;
use App\Http\Controllers\Parent\ResultController as ParentResultController;
use App\Http\Controllers\Parent\ScheduleController as ParentScheduleController;
use App\Http\Controllers\Access\AccessController;
use App\Http\Controllers\Access\CourseEnrollmentController as AccessCourseEnrollmentController;
use App\Http\Controllers\Access\WalletController;
use App\Http\Controllers\ReviewController;
use App\Http\Controllers\Admin\AccessRightController as AdminAccessRightController;
use App\Http\Controllers\Admin\ProfileController as AdminProfileController;
use App\Http\Controllers\Account\PasswordController as AccountPasswordController;
use App\Http\Controllers\Admin\ActivationCodeController as AdminActivationCodeController;
use App\Http\Controllers\Admin\CompetitionController as AdminCompetitionController;
use App\Http\Controllers\Admin\ContactMessageController as AdminContactMessageController;
use App\Http\Controllers\Admin\ContentController as AdminContentController;
use App\Http\Controllers\Admin\CourseController as AdminCourseController;
use App\Http\Controllers\Admin\LearningPathController as AdminLearningPathController;
use App\Http\Controllers\Admin\DashboardController as AdminDashboardController;
use App\Http\Controllers\Admin\FeaturedTeacherController as AdminFeaturedTeacherController;
use App\Http\Controllers\Admin\TestimonialController as AdminTestimonialController;
use App\Http\Controllers\Admin\OrderController as AdminOrderController;
use App\Http\Controllers\Admin\ProductChapterController as AdminProductChapterController;
use App\Http\Controllers\Admin\ProductController as AdminProductController;
use App\Http\Controllers\Admin\ProductExerciseController as AdminProductExerciseController;
use App\Http\Controllers\Admin\ProductExerciseBulkController as AdminProductExerciseBulkController; // SỬA 27/10 — nhập bài tập hàng loạt
use App\Http\Controllers\Admin\ProductExercisePickController as AdminProductExercisePickController; // SỬA 27/10 — lấy từ bài có sẵn
use App\Http\Controllers\Admin\RankingController as AdminRankingController;
use App\Http\Controllers\Admin\LeaderboardPenaltyController as AdminLeaderboardPenaltyController;
use App\Http\Controllers\Admin\ReportController as AdminReportController;
use App\Http\Controllers\Admin\MaterialReadController as AdminMaterialReadController;
use App\Http\Controllers\Admin\ReviewController as AdminReviewController;
use App\Http\Controllers\Admin\SettingsController as AdminSettingsController;
use App\Http\Controllers\Admin\TeacherApprovalController as AdminTeacherApprovalController;
use App\Http\Controllers\Admin\UserController as AdminUserController;
use Illuminate\Support\Facades\Route;

Route::get('/', [PublicHomeController::class, 'index'])->name('home');
// SỬA 4/11 — trang tải Chocon Desktop (nút "Tải Chocon Desktop" ở trang chủ) + file bộ cài.
Route::get('/tai-chocon', [\App\Http\Controllers\Public\ChoconDownloadController::class, 'show'])->name('chocon.download');
Route::get('/tai-chocon/tai-ve', [\App\Http\Controllers\Public\ChoconDownloadController::class, 'file'])
    ->middleware('throttle:20,1')->name('chocon.download.file');
// SỬA 9/9 (9) — sitemap cho Google (xem Public\SitemapController). Đặt ngay dưới trang chủ
// để không lọt vào nhóm route nào có middleware auth.
Route::get('/sitemap.xml', [PublicSitemapController::class, 'index'])->name('sitemap');
// SỬA 4/11 — thông báo Quản trị đang ghim ở thanh "Thông báo hệ thống" trang chủ (ai cũng xem được).
Route::get('/thong-bao/{announcement}', [NotificationDetailController::class, 'publicShow'])->whereNumber('announcement')->name('announcements.public');
Route::get('/khoa-hoc', [PublicCourseController::class, 'index'])->name('courses.index');
// SỬA 18/9 (khách yêu cầu) — mảnh giao diện cho popup "Chi tiết lớp" ở trang Lớp học công khai.
// Công khai như chính trang danh sách: chỉ trả thông tin lớp vốn đã hiển thị ngoài trang, không
// trả dữ liệu nội bộ của lớp (xem CourseService::classDetailData()).
Route::get('/lop-hoc/{class}/chi-tiet', [PublicCourseController::class, 'classDetail'])
    ->whereNumber('class')->name('courses.classDetail');
Route::get('/khoa-hoc/{course}', [PublicCourseController::class, 'show'])->name('courses.show');
// B3/B4 (15/9) — Lộ trình học công khai. Đặt ngay sau Khóa học vì hai trang này đi cặp:
// lộ trình gồm nhiều khoá, khoá gồm nhiều lớp.
Route::get('/lo-trinh', [PublicLearningPathController::class, 'index'])->name('learningPaths.index');
Route::get('/lo-trinh/{slug}', [PublicLearningPathController::class, 'show'])->name('learningPaths.show');
Route::get('/luyen-tap', [PublicPracticeController::class, 'index'])->name('practice.index');
// SỬA 2/10 (khách: "khi click vào xem chi tiết đề thi nó hiển thị ra màn UI mới giống như source
// mới") — màn chi tiết đề LUYỆN TẬP (chỉ type=practice đã phát hành, service tự chặn loại khác)
// và bản xem trước PDF theo đúng khoảng trang admin đã khai. Công khai như trang /luyen-tap:
// xem được thông tin đề, còn bấm "Bắt đầu làm bài" thì phải đăng nhập.
Route::get('/luyen-tap/de-thi/{assessment}', [PublicPracticeController::class, 'exam'])
    ->whereNumber('assessment')->name('practice.exam.show');
Route::get('/luyen-tap/de-thi/{assessment}/xem-truoc', [PublicPracticeController::class, 'examPreview'])
    ->whereNumber('assessment')->name('practice.exam.preview');
// SỬA 7/10 (khách: "thiếu số sao đánh giá") — học sinh đã nộp đề chấm sao cho đề luyện tập.
Route::post('/luyen-tap/de-thi/{assessment}/danh-gia', [PublicPracticeController::class, 'rate'])
    ->middleware('auth')->whereNumber('assessment')->name('practice.exam.rate');
// SỬA 7/10 (khách: "giáo viên có thể giao bài") — popup "Giao bài"/"Giao đề" ở trang Luyện tập gửi
// về đây. Chỉ cần đăng nhập ở tầng route; quyền giáo viên/admin do controller + service kiểm tiếp.
Route::post('/luyen-tap/giao-bai', [PublicPracticeAssignmentController::class, 'store'])
    ->middleware('auth')->name('practice.assign');
// Gợi ý học sinh cho ô chọn nhiều trong popup (tìm theo tên / email / số điện thoại).
Route::get('/luyen-tap/giao-bai/hoc-sinh', [PublicPracticeAssignmentController::class, 'students'])
    ->middleware('auth')->name('practice.assign.students');
// SỬA 7/10 — Nhật ký nộp bài của một bài tập / một đề. Cần đăng nhập vì chứa bài làm của học sinh;
// ai xem được lượt nộp của ai do PracticeHistoryService quyết (admin: tất cả, giáo viên: học sinh
// mình đã giao, còn lại: chỉ của mình).
Route::middleware('auth')->group(function () {
    // SỬA 23/10 — trang Lịch sử làm bài / Lịch sử làm đề (danh sách bài nộp), xem SubmissionListController.
    Route::get('/luyen-tap/lich-su-lam-bai', [\App\Http\Controllers\Public\SubmissionListController::class, 'problems'])->name('practice.submissions.problems');
    Route::get('/luyen-tap/lich-su-lam-de', [\App\Http\Controllers\Public\SubmissionListController::class, 'exams'])->name('practice.submissions.exams');
    Route::get('/luyen-tap/nhat-ky/bai/{question}', [PublicPracticeHistoryController::class, 'problem'])
        ->whereNumber('question')->name('practice.history.problem');
    Route::get('/luyen-tap/nhat-ky/de/{assessment}', [PublicPracticeHistoryController::class, 'exam'])
        ->whereNumber('assessment')->name('practice.history.exam');
    // SỬA 7/10 — ADMIN chỉ định / bỏ chỉ định bài mẫu cho một bài tập (quyền kiểm ở controller + service).
    Route::post('/luyen-tap/nhat-ky/bai/{question}/bai-mau', [PublicPracticeHistoryController::class, 'designateSample'])
        ->whereNumber('question')->name('practice.history.sample.store');
    Route::delete('/luyen-tap/nhat-ky/bai/{question}/bai-mau', [PublicPracticeHistoryController::class, 'clearSample'])
        ->whereNumber('question')->name('practice.history.sample.destroy');
});
Route::get('/tai-lieu', [PublicMaterialController::class, 'index'])->name('materials.index');
// SỬA 9/10 (khách: "trang tài liệu có cả giao tài liệu") — popup "Giao tài liệu" ở trang /tai-lieu gửi về
// đây. Chỉ cần đăng nhập ở tầng route; quyền giáo viên/admin do controller + service kiểm tiếp.
Route::post('/tai-lieu/giao-tai-lieu', [PublicMaterialAssignmentController::class, 'store'])
    ->middleware('auth')->name('materials.assign');
Route::get('/tai-lieu/giao-tai-lieu/hoc-sinh', [PublicMaterialAssignmentController::class, 'students'])
    ->middleware('auth')->name('materials.assign.students');
Route::get('/tai-lieu/{material}', [PublicMaterialController::class, 'show'])->name('materials.show');
// SỬA 18/10 — MODULE BỘ ĐỀ: trang danh sách đề của 1 bộ đề (xem App\Services\ExamBundle\ExamBundleService).
Route::get('/bo-de/{product}', [\App\Http\Controllers\Public\ExamBundleController::class, 'show'])->whereNumber('product')->name('bundles.show');
Route::middleware('auth')->group(function () {
    // SỬA 18/10 — màn đọc bộ đề: PDF từng đề / từng câu, và bấm ô câu hỏi để vào làm (ExamBundleController).
    Route::get('/bo-de/{product}/tep/{kind}/{id}', [\App\Http\Controllers\Public\ExamBundleController::class, 'file'])
        ->whereNumber(['product', 'id'])->whereIn('kind', ['exam', 'question'])->name('bundles.read.file');
    Route::post('/bo-de/{product}/cau/{question}', [\App\Http\Controllers\Public\ExamBundleController::class, 'startQuestion'])
        ->whereNumber(['product', 'question'])->name('bundles.startQuestion');
});
Route::get('/cuoc-thi', [PublicCompetitionController::class, 'index'])->name('competitions.index');
Route::get('/cuoc-thi/{competition}', [PublicCompetitionController::class, 'show'])->name('competitions.show');
// SỬA 24/10 — thao tác BAN TỔ CHỨC ngay trong phòng thi (tab "Học sinh"). Quyền: ContestOrganizerService::canManage().
Route::middleware('auth')->group(function () {
    Route::get('/cuoc-thi/{competition}/ban-to-chuc/hoc-sinh', [\App\Http\Controllers\ContestManageController::class, 'students'])
        ->whereNumber('competition')->name('competitions.manage.students');
    Route::post('/cuoc-thi/{competition}/ban-to-chuc/hoc-sinh', [\App\Http\Controllers\ContestManageController::class, 'add'])
        ->whereNumber('competition')->name('competitions.manage.add');
    Route::post('/cuoc-thi/{competition}/ban-to-chuc/dang-ky/{registration}/duyet', [\App\Http\Controllers\ContestManageController::class, 'approve'])
        ->whereNumber(['competition', 'registration'])->name('competitions.manage.approve');
    Route::post('/cuoc-thi/{competition}/ban-to-chuc/dang-ky/{registration}/tu-choi', [\App\Http\Controllers\ContestManageController::class, 'reject'])
        ->whereNumber(['competition', 'registration'])->name('competitions.manage.reject');
    // SỬA 24/10 — gỡ học sinh khỏi danh sách.
    Route::post('/cuoc-thi/{competition}/ban-to-chuc/dang-ky/{registration}/go', [\App\Http\Controllers\ContestManageController::class, 'remove'])
        ->whereNumber(['competition', 'registration'])->name('competitions.manage.remove');
    // SỬA 24/10 — thêm / sửa / xoá kỳ thi ngay trong phòng thi.
    Route::post('/cuoc-thi/{competition}/ban-to-chuc/vong', [\App\Http\Controllers\ContestManageController::class, 'storeRound'])
        ->whereNumber('competition')->name('competitions.manage.rounds.store');
    Route::post('/cuoc-thi/{competition}/ban-to-chuc/vong/{exam}', [\App\Http\Controllers\ContestManageController::class, 'updateRound'])
        ->whereNumber(['competition', 'exam'])->name('competitions.manage.rounds.update');
    Route::post('/cuoc-thi/{competition}/ban-to-chuc/vong/{exam}/xoa', [\App\Http\Controllers\ContestManageController::class, 'destroyRound'])
        ->whereNumber(['competition', 'exam'])->name('competitions.manage.rounds.destroy');
    // SỬA 25/10 — tab "Lấy đề có sẵn": chọn đề trong ngân hàng cho kỳ.
    Route::post('/cuoc-thi/{competition}/ban-to-chuc/vong/{exam}/de-co-san', [\App\Http\Controllers\ContestManageController::class, 'setRoundExam'])
        ->whereNumber(['competition', 'exam'])->name('competitions.manage.rounds.exam');
    // SỬA 30/10 — LÀM THỬ đề của kỳ (chỉ ban tổ chức: admin / giáo viên tổ chức), lúc nào cũng được — ContestTestRunController.
    Route::post('/cuoc-thi/{competition}/ban-to-chuc/vong/{exam}/lam-thu', [\App\Http\Controllers\ContestTestRunController::class, 'start'])
        ->whereNumber(['competition', 'exam'])->name('competitions.manage.test');
    Route::get('/cuoc-thi/{competition}/ban-to-chuc/vong/{exam}/lam-thu/{assessment}', [\App\Http\Controllers\ContestTestRunController::class, 'take'])
        ->whereNumber(['competition', 'exam', 'assessment'])->name('competitions.manage.test.take');
    // SỬA 3/11 — LUYỆN LẠI đề của kỳ đã kết thúc (học sinh đã tham gia): không tính điểm / xếp hạng — ContestReviewController.
    Route::post('/cuoc-thi/{competition}/vong/{exam}/luyen-lai', [\App\Http\Controllers\ContestReviewController::class, 'start'])
        ->middleware('throttle:20,1')->whereNumber(['competition', 'exam'])->name('competitions.review');
    Route::get('/cuoc-thi/{competition}/vong/{exam}/luyen-lai/{assessment}', [\App\Http\Controllers\ContestReviewController::class, 'take'])
        ->whereNumber(['competition', 'exam', 'assessment'])->name('competitions.review.take');
    // SỬA 30/10 — dữ liệu hộp "In bảng điểm & xếp giải" (JSON, chỉ ban tổ chức) — ContestScoreSheetService.
    // SỬA 2/11 — giáo viên cùng tổ chức kỳ (chỉ chủ kỳ / admin thêm, gỡ) + cho học sinh làm bù kỳ đã kết thúc.
    Route::post('/cuoc-thi/{competition}/ban-to-chuc/vong/{exam}/cung-to-chuc', [\App\Http\Controllers\ContestRoundTeamController::class, 'addManager'])
        ->whereNumber(['competition', 'exam'])->name('competitions.manage.team.add');
    Route::post('/cuoc-thi/{competition}/ban-to-chuc/vong/{exam}/cung-to-chuc/{user}/go', [\App\Http\Controllers\ContestRoundTeamController::class, 'removeManager'])
        ->whereNumber(['competition', 'exam', 'user'])->name('competitions.manage.team.remove');
    Route::post('/cuoc-thi/{competition}/ban-to-chuc/vong/{exam}/lam-bu', [\App\Http\Controllers\ContestRoundTeamController::class, 'addMakeup'])
        ->whereNumber(['competition', 'exam'])->name('competitions.manage.makeup.add');
    Route::post('/cuoc-thi/{competition}/ban-to-chuc/vong/{exam}/lam-bu/{makeup}/xoa', [\App\Http\Controllers\ContestRoundTeamController::class, 'removeMakeup'])
        ->whereNumber(['competition', 'exam', 'makeup'])->name('competitions.manage.makeup.remove');

    Route::get('/cuoc-thi/{competition}/ban-to-chuc/vong/{exam}/bang-diem', \App\Http\Controllers\ContestScoreSheetController::class)
        ->whereNumber(['competition', 'exam'])->name('competitions.manage.scoreSheet');
    // SỬA 4/11 (khách: "in bảng điểm xoay tùm lum, muốn PDF ngang") — nút "Tải PDF": máy chủ dựng file PDF khổ A4 đúng chiều.
    Route::post('/cuoc-thi/{competition}/ban-to-chuc/vong/{exam}/bang-diem/pdf', \App\Http\Controllers\ContestScoreSheetPdfController::class)
        ->whereNumber(['competition', 'exam'])->name('competitions.manage.scoreSheet.pdf');
    // SỬA 30/10 — tab "Nhật ký" của kỳ (JSON): ban tổ chức xem mọi lượt, người khác chỉ lượt của mình (ContestActivityLogService).
    Route::get('/cuoc-thi/{competition}/vong/{exam}/nhat-ky', \App\Http\Controllers\ContestActivityLogController::class)
        ->whereNumber(['competition', 'exam'])->name('competitions.activity');
    // SỬA 24/10 — tab "Thiết lập đề" (API JSON), xem ContestPaperController.
    Route::prefix('/cuoc-thi/{competition}/ban-to-chuc/vong/{exam}/de')->whereNumber(['competition', 'exam'])->group(function () {
        Route::get('/', [\App\Http\Controllers\ContestPaperController::class, 'state'])->name('competitions.manage.papers');
        Route::post('/', [\App\Http\Controllers\ContestPaperController::class, 'create'])->name('competitions.manage.papers.create');
        Route::post('/{paper}/dem', [\App\Http\Controllers\ContestPaperController::class, 'check'])->whereNumber('paper')->name('competitions.manage.papers.check');
        Route::post('/{paper}/sinh', [\App\Http\Controllers\ContestPaperController::class, 'generate'])->whereNumber('paper')->name('competitions.manage.papers.generate');
        Route::post('/{paper}/thay', [\App\Http\Controllers\ContestPaperController::class, 'replace'])->whereNumber('paper')->name('competitions.manage.papers.replace');
        Route::post('/{paper}/luu', [\App\Http\Controllers\ContestPaperController::class, 'save'])->whereNumber('paper')->name('competitions.manage.papers.save');
        Route::post('/{paper}/xoa', [\App\Http\Controllers\ContestPaperController::class, 'destroy'])->whereNumber('paper')->name('competitions.manage.papers.destroy');
    });
});
Route::get('/bang-xep-hang', [PublicLeaderboardController::class, 'index'])->name('leaderboard.index');
Route::get('/giao-vien-tieu-bieu', [PublicTeacherController::class, 'index'])->name('teachers.index');
Route::get('/giao-vien-tieu-bieu/{teacher}', fn ($teacher) => view('public.teachers.show'))->name('teachers.show');
Route::get('/thong-tin', [PublicInfoController::class, 'index'])->name('info.index');
Route::post('/thong-tin/lien-he', [PublicContactController::class, 'store'])
    ->middleware('throttle:5,1')
    ->name('info.contact.store');
Route::get('/thong-tin/chinh-sach/{slug}', [PublicInfoController::class, 'policy'])
    ->whereIn('slug', ['bao-mat', 'dieu-khoan', 'hoan-tien'])
    ->name('info.policies.show');

Route::middleware(['guest'])->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    // Giới hạn số lần thử đăng nhập theo IP — chống dò mật khẩu bằng máy.
    // SỬA 2/11 — nới 10 → 60 lượt/phút/IP: cả phòng máy dùng chung 1 IP, 10 lượt là cả lớp bị chặn chung. Sai mật khẩu
    // nhiều lần thì khoá riêng từng tài khoản 5 phút (AuthController::login()).
    Route::post('/login', [AuthController::class, 'login'])->middleware('throttle:60,1');
    Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
    Route::post('/register', [AuthController::class, 'register'])->middleware('throttle:10,1');

    /*
     * SỬA 11/9 — luồng đăng ký 3 bước theo source giao diện khách gửi. 3 route dưới đây được
     * giao diện gọi bằng fetch ở bước 2 (xác minh mã 6 số); bản thân việc tạo tài khoản vẫn
     * đi qua đúng POST /register ở trên. Xem App\Services\Auth\RegistrationService.
     */
    Route::post('/register/gui-ma', [AuthController::class, 'sendRegistrationCode'])
        ->middleware('throttle:6,1')
        ->name('register.sendCode');
    Route::post('/register/gui-lai-ma', [AuthController::class, 'resendRegistrationCode'])
        ->middleware('throttle:6,1')
        ->name('register.resendCode');
    Route::post('/register/xac-minh', [AuthController::class, 'verifyRegistrationCode'])
        ->middleware('throttle:12,1')
        ->name('register.verifyCode');

    /*
     * SỬA 11/9 — QUÊN/ĐẶT LẠI MẬT KHẨU: trước đây hệ thống KHÔNG có luồng này, người quên mật
     * khẩu không tự lấy lại được tài khoản. Dùng Password broker sẵn có của Laravel
     * (bảng password_reset_tokens đã có từ migration gốc).
     */
    Route::get('/quen-mat-khau', [PasswordResetController::class, 'showRequest'])->name('password.request');
    Route::post('/quen-mat-khau', [PasswordResetController::class, 'sendLink'])
        ->middleware('throttle:5,1')
        ->name('password.email');
    Route::get('/dat-lai-mat-khau/{token}', [PasswordResetController::class, 'showReset'])->name('password.reset');
    Route::post('/dat-lai-mat-khau', [PasswordResetController::class, 'update'])
        ->middleware('throttle:5,1')
        ->name('password.update');
});

Route::post('/logout', [AuthController::class, 'logout'])->name('logout')->middleware('auth');

Route::middleware(['auth'])->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    // SỬA 3/11 — đề cả bài / lời giải cả bài của "Bài phổ thông" (GeneralSetController::file tự kiểm tra quyền xem).
    Route::get('/bai-pho-thong/{assessment}/{which}', [\App\Http\Controllers\GeneralSetController::class, 'file'])
        ->whereNumber('assessment')->whereIn('which', ['statement', 'solution'])->name('general-sets.file');

    // SỬA 15/10 — admin chuyển qua lại giao diện Giáo viên (xem ActingRoleController). Không đặt trong nhóm role:admin
    // vì lúc đang xem như Giáo viên thì vai trò admin bị che — controller tự kiểm tra admin thật trong CSDL.
    Route::post('/che-do-xem/giao-vien', [\App\Http\Controllers\ActingRoleController::class, 'startTeacher'])
        ->middleware('throttle:20,1')->name('acting.teacher.start');
    Route::post('/che-do-xem/thoat', [\App\Http\Controllers\ActingRoleController::class, 'stop'])
        ->middleware('throttle:20,1')->name('acting.stop');

    Route::get('/notifications/{notification}/read', [NotificationController::class, 'read'])->name('notifications.read');
    Route::post('/notifications/read-all', [NotificationController::class, 'readAll'])->name('notifications.readAll');
    // SỬA 4/11 — đánh dấu đã đọc 1 thông báo (nút ✓ ở chuông), không mở thông báo.
    Route::post('/notifications/{notification}/mark-read', [NotificationController::class, 'markRead'])->name('notifications.markRead');
    // SỬA 4/11 — đọc đủ nội dung một thông báo (thông báo lớp / thông báo Quản trị…).
    Route::get('/notifications/{notification}', [NotificationDetailController::class, 'show'])->name('notifications.show');

    Route::middleware(['role:student'])->prefix('student')->name('student.')->group(function () {
        /*
         * SỬA 24/9 (khách: "thêm cho tôi cái button ... học sinh thì vào không gian học tập")
         * — lối vào khu HỌC SINH có địa chỉ riêng.
         *
         * Trước đây khu học sinh chỉ tới được qua /dashboard, mà route đó là BỘ CHIA THEO VAI
         * TRÒ (DashboardRoutingService): tài khoản vừa là quản trị vừa là học sinh bấm vào sẽ
         * bị đá sang bảng quản trị. Nút mới trên trang chủ nằm trong đúng tab vai trò nên phải
         * tới đúng khu của vai trò đó, không qua bộ chia.
         */
        Route::get('/', [StudentDashboardController::class, 'index'])->name('dashboard');
        Route::get('courses', [StudentCourseController::class, 'index'])->name('courses.index');
        // SỬA 16/9 (khách yêu cầu: "bỏ chỗ nhập mã lớp... bấm đăng ký học thì giáo viên duyệt")
        // — lối vào lớp MỚI. Route mã lớp bên dưới vẫn được đăng ký để route() ở chỗ khác không
        // ném lỗi, nhưng gọi vào thì 404 (Student\ClassRoomService::JOIN_BY_CODE_ENABLED = false).
        Route::post('classes/{class}/dang-ky', [StudentClassRoomController::class, 'requestJoin'])
            ->whereNumber('class')->name('classes.requestJoin');
        Route::post('classes/join', [StudentClassRoomController::class, 'join'])->name('classes.join');
        Route::get('classes/{class}', [StudentClassRoomController::class, 'show'])->name('classes.show');
        Route::get('schedule', [StudentScheduleController::class, 'index'])->name('schedule.index');
        // SỬA 19/9 (khách: "click đăng ký tham gia thì admin sẽ duyệt, duyệt xong học sinh vào
        // được màn không gian thi") — 2 lối duy nhất của học sinh với cuộc thi. Chặn THẬT khi
        // vào thi vẫn nằm ở AttemptService::competitionEntryDecision(), không phải ở route.
        Route::post('competitions/{competition}/dang-ky', [StudentCompetitionController::class, 'requestJoin'])
            ->whereNumber('competition')->name('competitions.requestJoin');
        // SỬA 24/10 — nút trong hộp thoại vào thi (khảo sát: mật khẩu; cuộc thi: mã đề), xem ContestEntryService.
        Route::post('competitions/{competition}/vong/{exam}/vao-thi', [StudentCompetitionController::class, 'enter'])
            ->whereNumber(['competition', 'exam'])->name('competitions.enter');
        Route::get('competitions/{competition}/phong-thi', [StudentCompetitionController::class, 'room'])
            ->whereNumber('competition')->name('competitions.room');
        // SỬA 19/9 (2) (khách: "vào thi thì mở màn làm bài RIÊNG cho cuộc thi") — phòng thi
        // của cuộc thi. Đường dẫn mang cả competition + vòng thi để màn làm bài biết mình
        // đang ở cuộc thi/vòng nào mà hiển thị cho đúng; việc TẠO/TIẾP TỤC lượt làm bài, tự
        // lưu, chạy thử và chấm vẫn dùng NGUYÊN hạ tầng cũ (student.assessment.take.save /
        // .run / .submit) — chỉ khác cái view.
        Route::get('competitions/{competition}/vong/{exam}/lam-bai', [StudentCompetitionController::class, 'exam'])
            ->whereNumber(['competition', 'exam'])->name('competitions.exam');
        // SỬA 25/8 ("đọc bài" — Sách/Chuyên đề/Đề thi): quyền đọc kiểm tra qua
        // App\Services\AccessGateService::canAccessMaterial() (đúng 1 nơi kiểm tra quyền học
        // liệu của toàn hệ thống, xem MaterialReadService). File PDF phục vụ qua route riêng
        // (materials.file), gọi bằng fetch() từ trang đọc — không phải link tải trực tiếp.
        Route::get('materials/{material}', [StudentMaterialController::class, 'read'])->name('materials.read');
        Route::get('materials/{material}/file', [StudentMaterialController::class, 'pdfFile'])->name('materials.file');
        /*
         * SỬA 29/9 (khách chốt: "mỗi chương thêm từng file pdf... khi mua xong hoặc giáo viên
         * gắn vào lớp thì từng file pdf sẽ ghép dài để lướt lên lướt xuống đọc") — ĐỌC LIỀN
         * MẠCH CẢ SẢN PHẨM: 1 trang nối PDF của mọi chương/phần/đề theo thứ tự. Quyền xét bằng
         * AccessGateService::canAccessProduct() (đã mua HOẶC được cấp qua lớp), KHÁC 2 route
         * materials.* ngay trên vốn chỉ xét quyền cá nhân cho 1 bài lẻ — xem ProductReadService.
         */
        Route::get('tai-lieu-cua-toi/{product}/doc', [StudentProductReadController::class, 'read'])
            ->whereNumber('product')->name('products.read');
        Route::get('tai-lieu-cua-toi/{product}/doc/{material}/file', [StudentProductReadController::class, 'file'])
            ->whereNumber(['product', 'material'])->name('products.read.file');
        // SỬA 29/9 (2) — tệp audio/ảnh của học liệu, cho cột "Học liệu" ở trang đọc (tệp riêng
        // tư ở disk 'local', trước đây không có route nào xem được trong khu vực người học).
        Route::get('tai-lieu-cua-toi/{product}/doc/{material}/asset/{kind}', [StudentProductReadController::class, 'asset'])
            ->whereNumber(['product', 'material'])->whereIn('kind', ['audio', 'image'])
            ->name('products.read.asset');
        // SỬA 28/8 ("ẩn mục lục + tài nguyên đính kèm khỏi trang public, chỉ xem trong khu vực
        // học sinh"): "Tài liệu của tôi" — tab Sách/Chuyên đề/Bộ đề, chỉ liệt kê sản phẩm đã
        // mua (App\Services\Student\LibraryService), gộp cả Mục lục (đọc bài — vẫn qua
        // materials.read/file phía trên) VÀ 3 tài nguyên đính kèm (content/exercise/media —
        // guide bị chặn hẳn cho học sinh, xem AccessService::downloadResource()).
        Route::get('tai-lieu-cua-toi', [StudentLibraryController::class, 'index'])->name('library.index');
        // SỬA 12/10 — 3 mục mới của khu Học sinh theo source RoleWorkspace.jsx (xem Student\StudentWorkspaceService).
        Route::get('bai-duoc-giao', [StudentAssignmentController::class, 'index'])->name('assignments.index');
        Route::get('ket-qua', [StudentResultController::class, 'index'])->name('results.index');
        Route::get('danh-gia-cua-toi', [StudentReviewController::class, 'index'])->name('reviews.index');
        // SỬA 12/10 — trang "Phụ huynh" của học sinh (Student\StudentParentLinkService): tìm + liên kết, đồng ý/từ chối yêu cầu, hủy liên kết.
        Route::get('phu-huynh', [StudentParentController::class, 'index'])->name('parents.index');
        Route::post('phu-huynh/tim', [StudentParentController::class, 'search'])->middleware('throttle:20,1')->name('parents.search');
        Route::post('phu-huynh', [StudentParentController::class, 'store'])->middleware('throttle:10,1')->name('parents.store');
        Route::post('phu-huynh/{parentLink}/phan-hoi', [StudentParentController::class, 'respond'])->whereNumber('parentLink')->name('parents.respond');
        Route::delete('phu-huynh/{parentLink}', [StudentParentController::class, 'destroy'])->whereNumber('parentLink')->name('parents.destroy');
        Route::get('notifications', [StudentNotificationController::class, 'index'])->name('notifications');
        Route::get('profile', [StudentProfileController::class, 'show'])->name('profile');
        Route::put('profile', [StudentProfileController::class, 'update'])->name('profile.update');
        // SỬA 9/10 — màn Đổi mật khẩu riêng (App\Http\Controllers\Account\PasswordController); khu suy ra từ tên route.
        Route::get('password', [AccountPasswordController::class, 'edit'])->name('password.edit');
        Route::put('password', [AccountPasswordController::class, 'update'])->middleware('throttle:6,1')->name('password.update');
    });

    /*
     * SỬA 23/9 (khách: "trang luyện tập ngoài public — học sinh, giáo viên, admin, phụ huynh
     * đều làm được hết") — LUYỆN TẬP + LÀM ĐỀ mở cho MỌI tài khoản đã đăng nhập: nhóm này chỉ
     * còn 'auth' của nhóm cha, KHÔNG kèm 'role:...'.
     *
     * Tách ra khỏi nhóm 'role:student' ở trên thay vì nới lỏng cả nhóm đó: những mục riêng
     * của học sinh (lớp của tôi, tài liệu đã mua, hồ sơ, cuộc thi...) VẪN chỉ học sinh vào
     * được. Quyền trên từng đối tượng (đề của sản phẩm phải mua, cuộc thi phải được duyệt...)
     * vẫn do Service/AccessGate kiểm tra như cũ, route chỉ mở cửa vào.
     *
     * Giữ NGUYÊN prefix 'student' và tên route 'student.*' — mọi route() đang dùng ở view,
     * controller, service không phải sửa một dòng nào.
     */
    Route::prefix('student')->name('student.')->group(function () {
        // Màn "Luyện tập" trong khu đăng nhập — mọi nút "Thoát"/"Về danh sách" của màn làm bài
        // đều quay về đây, nên phải mở cùng, không thì người không phải học sinh làm xong bấm
        // thoát là dính 403.
        Route::get('practice', [StudentPracticeController::class, 'index'])->name('practice.index');
        Route::prefix('practice-by-question')->name('practiceByQuestion.')->group(function () {
            Route::get('/', [StudentPracticeByQuestionController::class, 'setup'])->name('setup');
            Route::post('/', [StudentPracticeByQuestionController::class, 'start'])->name('start');
            /*
             * SỬA 24/9 (khách: "nút Làm bài ngay ở trang Luyện tập public — bấm vào là vào 1
             * câu bất ngờ random cho người ta làm") — mở thẳng MỘT câu ngẫu nhiên, bỏ qua màn
             * chọn chuyên đề. POST vì nó GHI phiên luyện vào session, không phải chỉ đọc; để
             * GET thì trình duyệt/trình quét link có thể tự mở và đạp mất bài đang làm dở.
             * Xem Student\PracticeByQuestionController::random().
             */
            Route::post('/random', [StudentPracticeByQuestionController::class, 'random'])->name('random');
            // SỬA 31/8 ("Làm bài" 1 bài tập cụ thể của sản phẩm, từ "Tài liệu của tôi") — mở
            // phiên luyện CHỈ 1 câu (khác start() ở trên vốn xáo trộn cả pool theo tag/dạng
            // câu), có kiểm tra quyền sở hữu sản phẩm — xem
            // Student\PracticeByQuestionController::startExercise().
            Route::post('/exercise/{exercise}', [StudentPracticeByQuestionController::class, 'startExercise'])->name('startExercise');
            Route::get('/play', [StudentPracticeByQuestionController::class, 'play'])->name('play');
            // SỬA 28/10 (khách: "thoát làm bài tập của sách thì đừng tải lại trang, giữ nguyên chương và chỗ đang đọc") — màn
            // làm bài mở trong khung nổi ngay trên trang đọc; bấm thoát thì khung nạp trang 'dong' này để báo trang đọc đóng
            // khung (không tải lại). 'trang-thai' trả trạng thái làm bài để cập nhật dấu "đã làm" tại chỗ.
            Route::get('/dong', [StudentPracticeByQuestionController::class, 'closed'])->name('closed');
            Route::get('/trang-thai', [StudentPracticeByQuestionController::class, 'statuses'])->name('statuses');
            Route::post('/answer', [StudentPracticeByQuestionController::class, 'answer'])->name('answer');
            // SỬA 18/9 (khách: "chỗ chạy test không được") — chạy thử mã với dữ liệu vào tự gõ
            // ở ô Input, trả JSON cho ô Output. Không chấm điểm, xem
            // Student\PracticeByQuestionService::runOnce().
            Route::post('/run', [StudentPracticeByQuestionController::class, 'run'])->name('run');
            // SỬA 30/9 (6) (khách: "thiếu nút bài tiếp theo và bài trước") — chuyển sang bài
            // liền trước/liền sau trong cùng danh sách. POST vì nó GHI lại phiên luyện (mở bài
            // khác, xoá kết quả chấm cũ), y như startExercise ở trên; để GET thì trình duyệt
            // nạp trước link hoặc học sinh bấm nhầm F5 là đạp mất bài đang làm dở.
            Route::post('/sibling/{exercise}', [StudentPracticeByQuestionController::class, 'sibling'])->name('sibling');
            Route::post('/next', [StudentPracticeByQuestionController::class, 'next'])->name('next');
            Route::post('/stop', [StudentPracticeByQuestionController::class, 'stop'])->name('stop');
            // SỬA 31/8 (2, "mở rộng ZIP bài tập" — audio/ảnh...): phát/hiện asset đính kèm câu
            // hỏi NGAY trong màn "Làm bài" (khác PDF đề bài — chỉ xem qua link riêng, đây là
            // nội dung CẦN để trả lời, vd nghe audio nghe-hiểu) — xem
            // StudentPracticeByQuestionController::asset().
            Route::get('/asset/{question}/{asset}', [StudentPracticeByQuestionController::class, 'asset'])->name('asset');
            // SỬA (nối "Xem đề bài" PDF cho học sinh, trước đây có ghi chú "chỉ xem qua link
            // riêng" ở by-question-play.blade.php nhưng CHƯA thực ra route/hàm nào) — xem
            // Student\PracticeByQuestionController::statement().
            Route::get('/statement/{question}', [StudentPracticeByQuestionController::class, 'statement'])->name('statement');
            // SỬA 1/10 (khách: "tab Hướng dẫn thì lấy đổ dữ liệu field lời giải ra, tab bài mẫu
            // thì lấy ở field code mẫu ra") — 2 tệp này TRƯỚC ĐÂY BỊ CHẶN với học sinh (chúng là
            // đáp án); khách chốt mở ở màn luyện tập. Phòng thi/chấm đề vẫn chặn như cũ. Quyền
            // kiểm y hệt route statement ngay trên, xem
            // Student\PracticeByQuestionController::solution()/sampleCode().
            Route::get('/solution/{question}', [StudentPracticeByQuestionController::class, 'solution'])->name('solution');
            Route::get('/sample-code/{question}', [StudentPracticeByQuestionController::class, 'sampleCode'])->name('sampleCode');
        });
        Route::get('assessments/{assessment}/take', [StudentAssessmentController::class, 'take'])->name('assessment.take');
        Route::get('assessments/{assessment}/pdf/{which}', [StudentAssessmentController::class, 'pdfFile'])
            ->whereIn('which', ['exam', 'solution', 'guide', 'sample'])
            ->name('assessment.pdf.file');
        Route::get('assessments/{question}/oj', [StudentAssessmentController::class, 'oj'])->name('assessment.oj');
        Route::get('attempts/{attempt}/result', [StudentAssessmentController::class, 'result'])->name('assessment.result');
        Route::post('attempts/{attempt}/answers', [StudentAssessmentController::class, 'saveAnswers'])->name('assessment.take.save');
        Route::post('attempts/{attempt}/submit', [StudentAssessmentController::class, 'submit'])->name('assessment.take.submit');
        // SỬA 18/9 (2) (khách: "chỗ bắt đầu làm đề, chỗ chạy test không chạy được") — chạy thử
        // mã của 1 câu trong đề với dữ liệu vào tự gõ. Không chấm điểm, xem
        // Student\AssessmentService::runCodeOnce().
        Route::post('attempts/{attempt}/run', [StudentAssessmentController::class, 'runCode'])->name('assessment.take.run');
        // SỬA 14/10 (khách: nút "Chấm câu" trong đề luyện tập) — chấm riêng 1 câu lúc đang làm + hỏi lại kết quả.
        // Giới hạn 20 lần/phút/người: mỗi lần chấm câu lập trình chạy cả bộ test trên máy chấm.
        Route::post('attempts/{attempt}/questions/{question}/grade', [StudentAssessmentController::class, 'gradeQuestion'])
            ->whereNumber('attempt')->whereNumber('question')->middleware('throttle:20,1')->name('assessment.take.grade');
        Route::get('attempts/{attempt}/questions/{question}/grade', [StudentAssessmentController::class, 'gradeStatus'])
            ->whereNumber('attempt')->whereNumber('question')->name('assessment.take.gradeStatus');
        // SỬA 17/10 (khách: "chỗ làm đề, chấm xong cho tải test sai về: Tải input / Tải output như bài tập chuyên đề").
        Route::get('attempts/{attempt}/questions/{question}/tests/{index}/{part}', [StudentAssessmentController::class, 'downloadFailedTest'])
            ->whereNumber('attempt')->whereNumber('question')->whereNumber('index')->whereIn('part', ['in', 'out'])
            ->middleware('throttle:60,1')->name('assessment.take.testDownload');
        /*
         * SỬA 24/9 (khách: "hiển thị modal vậy được rồi, không cần chuyển qua trang result") —
         * điểm hiện tại của lượt làm bài, dạng JSON. Câu lập trình chấm chạy nền nên lúc vừa
         * nộp xong điểm mới là tạm tính; hộp kết quả trên màn làm bài hỏi lại route này vài
         * giây một lần cho con số tự nhích lên. Xem Student\AssessmentController::status().
         */
        Route::get('attempts/{attempt}/status', [StudentAssessmentController::class, 'status'])->name('assessment.status');
    });

    Route::middleware(['role:teacher'])->prefix('teacher')->name('teacher.')->group(function () {
        Route::get('/', [TeacherDashboardController::class, 'index'])->name('dashboard');
        Route::get('classes', [TeacherClassRoomController::class, 'index'])->name('classes.index');
        Route::middleware('teacher.approved')->group(function () {
            Route::get('classes/create', [TeacherClassRoomController::class, 'create'])->name('classes.create');
            Route::post('classes', [TeacherClassRoomController::class, 'store'])->name('classes.store');
        });
        Route::post('classes/{class}/materials', [TeacherClassRoomController::class, 'attachMaterial'])->name('classes.materials.attach');
        Route::delete('classes/{class}/materials/{classMaterial}', [TeacherClassRoomController::class, 'detachMaterial'])->name('classes.materials.detach');
        // SỬA 27/8 ("giáo viên đọc tài liệu bị 403" / "xem học liệu đã gắn lớp như nào") —
        // trước đây chỉ có student.materials.read/file (khoá bởi role:student), giáo viên
        // không có route nào để tự đọc học liệu đã mua/đã gắn lớp. Xem
        // App\Http\Controllers\Teacher\MaterialController — tái dùng MaterialReadService.
        Route::get('materials/{material}', [TeacherMaterialController::class, 'read'])->name('materials.read');
        Route::get('materials/{material}/file', [TeacherMaterialController::class, 'pdfFile'])->name('materials.file');
        // SỬA 29/9 — đọc liền mạch cả sản phẩm, bản cho giáo viên (cùng ProductReadService,
        // chỉ khác layout/route lấy tệp — xem Teacher\ProductReadController).
        Route::get('tai-lieu-cua-toi/{product}/doc', [TeacherProductReadController::class, 'read'])
            ->whereNumber('product')->name('products.read');
        Route::get('tai-lieu-cua-toi/{product}/doc/{material}/file', [TeacherProductReadController::class, 'file'])
            ->whereNumber(['product', 'material'])->name('products.read.file');
        // SỬA 29/9 (2) — tệp audio/ảnh của học liệu, cho cột "Học liệu" ở trang đọc (tệp riêng
        // tư ở disk 'local', trước đây không có route nào xem được trong khu vực người học).
        Route::get('tai-lieu-cua-toi/{product}/doc/{material}/asset/{kind}', [TeacherProductReadController::class, 'asset'])
            ->whereNumber(['product', 'material'])->whereIn('kind', ['audio', 'image'])
            ->name('products.read.asset');
        // SỬA 28/8 (2 — "bên giáo viên cũng xem tài liệu giống như học sinh, chỉ khác được
        // xem thêm file hướng dẫn") — "Tài liệu của tôi" bên giáo viên, tái dùng nguyên
        // App\Services\Student\LibraryService (xem Teacher\LibraryController), chỉ khác gọi
        // với includeGuide=true.
        Route::get('tai-lieu-cua-toi', [TeacherLibraryController::class, 'index'])->name('library.index');
        // SỬA 24/8 — khách yêu cầu: "Giao đề" (chọn đề có sẵn) chuyển hẳn vào đây (tab "Giao
        // đề" trong Chi tiết lớp) — KHÔNG còn giao được từ Bài tập & Đề nữa (xem
        // teacher.assessments.store/index đã bỏ nhánh giao lớp, chỉ còn lưu đề).
        Route::post('classes/{class}/assign', [TeacherClassRoomController::class, 'assignAssessment'])->name('classes.assign');
        // SỬA 16/9 — duyệt/từ chối yêu cầu vào lớp của học sinh (tab Thành viên).
        Route::post('classes/{class}/requests/{enrollment}/approve', [TeacherClassRoomController::class, 'approveJoinRequest'])
            ->whereNumber(['class', 'enrollment'])->name('classes.requests.approve');
        Route::post('classes/{class}/requests/{enrollment}/reject', [TeacherClassRoomController::class, 'rejectJoinRequest'])
            ->whereNumber(['class', 'enrollment'])->name('classes.requests.reject');
        // SỬA 16/9 — gỡ học sinh khỏi lớp (dòng ghi danh chuyển 'left', không xoá).
        Route::post('classes/{class}/members/{student}/remove', [TeacherClassRoomController::class, 'removeStudent'])
            ->whereNumber(['class', 'student'])->name('classes.members.remove');
        // SỬA 6/11 — thêm học sinh vào lớp thủ công (email / số điện thoại).
        Route::post('classes/{class}/members/add', [TeacherClassRoomController::class, 'addStudents'])
            ->whereNumber('class')->middleware('throttle:30,1')->name('classes.members.add');
        Route::get('classes/{class}/students/search', [TeacherClassRoomController::class, 'searchStudents'])
            ->whereNumber('class')->middleware('throttle:120,1')->name('classes.students.search');
        // SỬA 6/11 (khách: "lớp là một giao diện riêng, 8 tab") — thao tác mới của không gian lớp, xem Teacher\ClassSpaceController.
        Route::controller(\App\Http\Controllers\Teacher\ClassSpaceController::class)->whereNumber(['class', 'teacher', 'assignment', 'step'])->group(function () {
            Route::get('classes/{class}/teachers/search', 'searchTeachers')->middleware('throttle:120,1')->name('classes.teachers.search');
            Route::post('classes/{class}/teachers', 'addTeacher')->name('classes.teachers.add');
            Route::post('classes/{class}/teachers/{teacher}/role', 'setTeacherRole')->name('classes.teachers.role');
            Route::delete('classes/{class}/teachers/{teacher}', 'removeTeacher')->name('classes.teachers.remove');
            Route::post('classes/{class}/attendance/cell', 'saveAttendanceCell')->middleware('throttle:600,1')->name('classes.attendance.cell');
            Route::get('classes/{class}/attendance/export', 'exportAttendance')->name('classes.attendance.export');
            Route::post('classes/{class}/assignments/{assignment}/remind', 'remind')->name('classes.assignments.remind');
            Route::get('classes/{class}/practice/sources', 'practiceSources')->middleware('throttle:60,1')->name('classes.practice.sources');
            Route::post('classes/{class}/practice/assign', 'assignPractice')->middleware('throttle:30,1')->name('classes.practice.assign');
            Route::post('classes/{class}/steps', 'storeStep')->name('classes.steps.store');
            Route::put('classes/{class}/steps/{step}', 'updateStep')->name('classes.steps.update');
            Route::delete('classes/{class}/steps/{step}', 'destroyStep')->name('classes.steps.destroy');
            Route::post('classes/{class}/steps/{step}/toggle', 'toggleStep')->name('classes.steps.toggle');
            Route::post('classes/{class}/steps/{step}/move', 'moveStep')->name('classes.steps.move');
            Route::post('classes/{class}/grades', 'saveGrade')->middleware('throttle:600,1')->name('classes.grades.save');
            Route::get('classes/{class}/results/export', 'exportResults')->name('classes.results.export');
            Route::get('classes/{class}/results/print', 'printResults')->name('classes.results.print');
        });
        Route::get('classes/{class}', [TeacherClassRoomController::class, 'show'])->name('classes.show');
        Route::get('questions', [TeacherQuestionController::class, 'index'])->name('questions.index');
        Route::get('questions/create', [TeacherQuestionController::class, 'create'])->middleware(\App\Http\Middleware\EnsurePermissionNotRevoked::for('teacher.question-create'))->name('questions.create');
        Route::post('questions', [TeacherQuestionController::class, 'store'])->middleware(\App\Http\Middleware\EnsurePermissionNotRevoked::for('teacher.question-create'))->name('questions.store');
        Route::get('questions/{question}/edit', [TeacherQuestionController::class, 'edit'])->middleware(\App\Http\Middleware\EnsurePermissionNotRevoked::for('teacher.question-edit'))->name('questions.edit');
        Route::put('questions/{question}', [TeacherQuestionController::class, 'update'])->middleware(\App\Http\Middleware\EnsurePermissionNotRevoked::for('teacher.question-edit'))->name('questions.update');
        Route::post('questions/{question}/publish', [TeacherQuestionController::class, 'publish'])->middleware(\App\Http\Middleware\EnsurePermissionNotRevoked::for('teacher.content-publish'))->name('questions.publish');
        Route::post('questions/{question}/archive', [TeacherQuestionController::class, 'archive'])->middleware(\App\Http\Middleware\EnsurePermissionNotRevoked::for('teacher.question-edit'))->name('questions.archive');
        // SỬA 10/10 — đổi chỗ câu của mình với câu liền trên/dưới trong danh sách (JSON).
        Route::patch('questions/{question}/move', [TeacherQuestionController::class, 'move'])->middleware(\App\Http\Middleware\EnsurePermissionNotRevoked::for('teacher.question-edit'))->name('questions.move');

        // SỬA 24/8 — "Nhập từ gói ZIP" (OT360-QPACK) cho câu hỏi lập trình: xem
        // Teacher\QuestionService::storeFromZipPackage() + attachmentInfo().
        Route::post('questions/zip-import', [TeacherQuestionController::class, 'zipImportStore'])->middleware(\App\Http\Middleware\EnsurePermissionNotRevoked::for('teacher.question-create'))->name('questions.zipImport');
        // SỬA 3/11 — nhập "Bài phổ thông" (1 bài nhiều câu) từ gói ZIP — App\Http\Controllers\GeneralSetController.
        Route::post('questions/general-zip-import', [\App\Http\Controllers\GeneralSetController::class, 'teacherImport'])->middleware(\App\Http\Middleware\EnsurePermissionNotRevoked::for('teacher.question-create'))->name('questions.generalImport');
        // SỬA 3/11 — form nhập tay "Bài phổ thông".
        Route::post('questions/general-form', [\App\Http\Controllers\GeneralSetController::class, 'teacherForm'])->middleware(\App\Http\Middleware\EnsurePermissionNotRevoked::for('teacher.question-create'))->name('questions.generalForm');
        Route::delete('questions/general-sets/{assessment}', [\App\Http\Controllers\GeneralSetController::class, 'teacherDestroy'])->whereNumber('assessment')->name('questions.generalSets.destroy');
        Route::get('questions/{question}/attachment/{kind}', [TeacherQuestionController::class, 'attachmentDownload'])->name('questions.attachment');

        // SỬA 24/8 — khách yêu cầu: giáo viên (cố vấn/đồng hành) chỉ được THÊM/SỬA kỳ thi
        // (vòng) trong 1 cuộc thi có sẵn, KHÔNG được tạo/sửa/lưu trữ chính cuộc thi (vẫn chỉ
        // admin.competitions.* làm được) — xem Teacher\CompetitionController.
        Route::get('competitions', [TeacherCompetitionController::class, 'index'])->name('competitions.index');
        Route::get('competitions/{competition}', [TeacherCompetitionController::class, 'show'])->name('competitions.show');
        Route::post('competitions/{competition}/exams', [TeacherCompetitionController::class, 'examStore'])->middleware(\App\Http\Middleware\EnsurePermissionNotRevoked::for('teacher.organize-competition'))->name('competitions.exams.store');
        Route::put('competitions/exams/{competitionExam}', [TeacherCompetitionController::class, 'examUpdate'])->middleware(\App\Http\Middleware\EnsurePermissionNotRevoked::for('teacher.organize-competition'))->name('competitions.exams.update');
        Route::delete('competitions/exams/{competitionExam}', [TeacherCompetitionController::class, 'examDestroy'])->middleware(\App\Http\Middleware\EnsurePermissionNotRevoked::for('teacher.organize-competition'))->name('competitions.exams.destroy');

        Route::get('assessments', [TeacherAssessmentController::class, 'index'])->name('assessments.index');
        Route::get('assessments/create', [TeacherAssessmentController::class, 'create'])->middleware(\App\Http\Middleware\EnsurePermissionNotRevoked::for('teacher.assessment-create'))->name('assessments.create');
        Route::post('assessments', [TeacherAssessmentController::class, 'store'])->middleware(\App\Http\Middleware\EnsurePermissionNotRevoked::for('teacher.assessment-create'))->name('assessments.store');
        Route::get('assessments/import', [TeacherAssessmentController::class, 'import'])->middleware(\App\Http\Middleware\EnsurePermissionNotRevoked::for('teacher.assessment-create'))->name('assessments.import');
        Route::get('assessments/review-draft', [TeacherAssessmentController::class, 'reviewDraft'])->middleware(\App\Http\Middleware\EnsurePermissionNotRevoked::for('teacher.assessment-create'))->name('assessments.reviewDraft');
        Route::post('assessments/import', [TeacherAssessmentController::class, 'importStore'])->middleware(\App\Http\Middleware\EnsurePermissionNotRevoked::for('teacher.assessment-create'))->name('assessments.import.store');
        Route::get('assessments/documents/{document}/file', [TeacherAssessmentController::class, 'downloadDocument'])->name('assessments.documents.download');
        Route::post('assessments/documents/{document}/drafts', [TeacherAssessmentController::class, 'draftStore'])->middleware(\App\Http\Middleware\EnsurePermissionNotRevoked::for('teacher.assessment-create'))->name('assessments.drafts.store');
        Route::post('assessments/drafts/{draft}', [TeacherAssessmentController::class, 'draftUpdate'])->middleware(\App\Http\Middleware\EnsurePermissionNotRevoked::for('teacher.assessment-create'))->name('assessments.drafts.update');
        Route::post('assessments/drafts/{draft}/merge', [TeacherAssessmentController::class, 'draftMerge'])->middleware(\App\Http\Middleware\EnsurePermissionNotRevoked::for('teacher.assessment-create'))->name('assessments.drafts.merge');
        Route::post('assessments/drafts/{draft}/discard', [TeacherAssessmentController::class, 'draftDiscard'])->middleware(\App\Http\Middleware\EnsurePermissionNotRevoked::for('teacher.assessment-create'))->name('assessments.drafts.discard');
        Route::post('assessments/{assessment}/publish', [TeacherAssessmentController::class, 'publish'])->middleware(\App\Http\Middleware\EnsurePermissionNotRevoked::for('teacher.content-publish'))->name('assessments.publish');

        Route::get('papers', [TeacherAssessmentController::class, 'papersIndex'])->name('papers.index');
        Route::get('papers/create', [TeacherAssessmentController::class, 'papersCreate'])->middleware(\App\Http\Middleware\EnsurePermissionNotRevoked::for('teacher.assessment-create'))->name('papers.create');
        // SỬA 16/10 — nhập cả đề (PDF + đáp án + bài lập trình) từ 1 gói ZIP OT360-EPACK, xem ExamZipImportService.
        Route::post('papers/zip-import', [TeacherAssessmentController::class, 'papersZipImportStore'])->middleware(\App\Http\Middleware\EnsurePermissionNotRevoked::for('teacher.assessment-create'))->name('papers.zipImport');
        Route::post('papers', [TeacherAssessmentController::class, 'papersStore'])->middleware(\App\Http\Middleware\EnsurePermissionNotRevoked::for('teacher.assessment-create'))->name('papers.store');
        Route::get('papers/bulk', [TeacherAssessmentController::class, 'papersBulkCreate'])->middleware(\App\Http\Middleware\EnsurePermissionNotRevoked::for('teacher.assessment-create'))->name('papers.bulk.create');
        Route::post('papers/bulk/split', [TeacherAssessmentController::class, 'papersBulkSplit'])->middleware(\App\Http\Middleware\EnsurePermissionNotRevoked::for('teacher.assessment-create'))->name('papers.bulk.split');
        Route::post('papers/bulk/multi', [TeacherAssessmentController::class, 'papersBulkMulti'])->middleware(\App\Http\Middleware\EnsurePermissionNotRevoked::for('teacher.assessment-create'))->name('papers.bulk.multi');
        Route::get('papers/{assessment}/pdf', [TeacherAssessmentController::class, 'papersPdfEdit'])->middleware(\App\Http\Middleware\EnsurePermissionNotRevoked::for('teacher.assessment-create'))->name('papers.pdf.edit');
        Route::put('papers/{assessment}/pdf', [TeacherAssessmentController::class, 'papersPdfUpdate'])->middleware(\App\Http\Middleware\EnsurePermissionNotRevoked::for('teacher.assessment-create'))->name('papers.pdf.update');
        // SỬA 9/9 (khách: "thêm nút tải file Excel mẫu về để điền" + "nút upload file Excel đáp
        // án") — 2 route phụ trợ cho khối "Đáp án đúng từng câu" ở màn Quản lý đề PDF. Nhập tệp
        // CHỈ đổ dữ liệu ra form, việc ghi vẫn qua papers.pdf.update ở trên.
        Route::get('papers/{assessment}/answer-keys/template', [TeacherAssessmentController::class, 'papersAnswerKeysTemplate'])->name('papers.answer-keys.template');
        Route::post('papers/{assessment}/answer-keys/import', [TeacherAssessmentController::class, 'papersAnswerKeysImport'])->middleware(\App\Http\Middleware\EnsurePermissionNotRevoked::for('teacher.assessment-create'))->name('papers.answer-keys.import');
        Route::post('papers/{assessment}/coding-items', [TeacherAssessmentController::class, 'papersCodingItemsStore'])->middleware(\App\Http\Middleware\EnsurePermissionNotRevoked::for('teacher.assessment-create'))->name('papers.coding-items.store');
        Route::put('papers/coding-items/{codingItem}', [TeacherAssessmentController::class, 'papersCodingItemsUpdate'])->middleware(\App\Http\Middleware\EnsurePermissionNotRevoked::for('teacher.assessment-create'))->name('papers.coding-items.update');
        Route::delete('papers/coding-items/{codingItem}', [TeacherAssessmentController::class, 'papersCodingItemsDestroy'])->middleware(\App\Http\Middleware\EnsurePermissionNotRevoked::for('teacher.assessment-create'))->name('papers.coding-items.destroy');
        Route::post('papers/coding-items/{codingItem}/test-cases/import', [TeacherAssessmentController::class, 'papersCodingItemsTestCasesImport'])->middleware(\App\Http\Middleware\EnsurePermissionNotRevoked::for('teacher.assessment-create'))->name('papers.coding-items.test-cases.import');

        // SỬA 12/10 — mục "Bài & đề" (danh sách lượt giao từng học sinh + giao bài/đề + nhận xét bài nộp).
        Route::get('bai-va-de', [TeacherWorkController::class, 'index'])->name('work.index');
        Route::post('bai-va-de/{assignment}/nhan-xet', [TeacherWorkController::class, 'feedback'])->whereNumber('assignment')->name('work.feedback');

        Route::get('results', [TeacherResultController::class, 'index'])->name('results.index');
        Route::get('results/export', [TeacherResultController::class, 'export'])->name('results.export');
        Route::get('results/attempts/{attempt}', [TeacherResultController::class, 'attempt'])->name('results.attempt');

        Route::get('schedule', [TeacherScheduleController::class, 'index'])->name('schedule.index');
        Route::post('schedule', [TeacherScheduleController::class, 'store'])->name('schedule.store');
        Route::put('schedule/{session}', [TeacherScheduleController::class, 'update'])->whereNumber('session')->name('schedule.update'); // SỬA 6/11 — sửa buổi học
        Route::get('schedule/{session}/attendance', [TeacherScheduleController::class, 'attendance'])->name('schedule.attendance');
        Route::post('schedule/{session}/attendance', [TeacherScheduleController::class, 'saveAttendance'])->name('schedule.attendance.save');
        Route::post('schedule/{session}/summary', [TeacherScheduleController::class, 'saveSummary'])->name('schedule.summary.save');
        // SỬA 9/9 (4) ("tạo hoạt động" trong buổi học; icon play để phát cho học sinh) — xem
        // App\Services\Teacher\ScheduleService::createActivity()/toggleActivityPublish().
        Route::post('schedule/{session}/activities', [TeacherScheduleController::class, 'storeActivity'])->name('schedule.activities.store');
        Route::post('schedule/{session}/activities/{activity}/publish', [TeacherScheduleController::class, 'toggleActivityPublish'])->name('schedule.activities.publish');
        Route::delete('schedule/{session}/activities/{activity}', [TeacherScheduleController::class, 'destroyActivity'])->name('schedule.activities.destroy');
        Route::post('schedule/{session}/resources', [TeacherScheduleController::class, 'addResource'])->name('schedule.resources.save');
        Route::delete('schedule/{session}/resources/{resource}', [TeacherScheduleController::class, 'removeResource'])->name('schedule.resources.delete');

        Route::get('notifications', [TeacherNotificationController::class, 'index'])->name('notifications.index');
        // SỬA 12/10 — soạn / đăng thông báo lớp (nháp → đăng → gửi thông báo tới học sinh, phụ huynh).
        Route::post('notices', [TeacherNoticeController::class, 'store'])->name('notices.store');
        Route::delete('notices/{notice}', [TeacherNoticeController::class, 'destroy'])->whereNumber('notice')->name('notices.destroy');
        Route::delete('classes/{class}/notices/{notice}', [TeacherNoticeController::class, 'destroyFromClass'])->whereNumber(['class', 'notice'])->name('classes.notices.destroy'); // SỬA 6/11

        Route::get('profile', [TeacherProfileController::class, 'show'])->name('profile.show');
        Route::put('profile', [TeacherProfileController::class, 'update'])->name('profile.update');
        Route::put('profile/teacher-profile', [TeacherProfileController::class, 'updateTeacherProfile'])->name('profile.teacherProfile.update');
        Route::put('profile/password', [TeacherProfileController::class, 'updatePassword'])->name('profile.password');
        // SỬA 9/10 — màn Đổi mật khẩu riêng (App\Http\Controllers\Account\PasswordController); khu suy ra từ tên route.
        Route::get('password', [AccountPasswordController::class, 'edit'])->name('password.edit');
        Route::put('password', [AccountPasswordController::class, 'update'])->middleware('throttle:6,1')->name('password.update');
    });

    Route::middleware(['role:parent'])->prefix('parent')->name('parent.')->group(function () {
        Route::get('/', [ParentDashboardController::class, 'index'])->name('dashboard');
        Route::get('children', [ParentChildController::class, 'index'])->name('children.index');
        Route::post('children/link-requests', [ParentChildController::class, 'storeLinkRequest'])->name('children.linkRequest');
        Route::get('children/{child}', [ParentChildController::class, 'show'])->name('children.show');
        // SỬA 12/10 — 2 mục mới theo source (ParentContent): "Bài được giao" + "Đánh giá lớp".
        Route::get('assignments', [ParentAssignmentController::class, 'index'])->name('assignments.index');
        Route::get('class-reviews', [ParentClassReviewController::class, 'index'])->name('reviews.index');
        Route::get('schedule', [ParentScheduleController::class, 'index'])->name('schedule.index');
        Route::get('results', [ParentResultController::class, 'index'])->name('results.index');
        Route::get('notifications', [ParentNotificationController::class, 'index'])->name('notifications.index');
        Route::get('profile', [ParentProfileController::class, 'show'])->name('profile');
        Route::put('profile', [ParentProfileController::class, 'update'])->name('profile.update');
        // SỬA 4/11 — "Máy tính của con" (Chocon Desktop).
        Route::get('devices', [ParentDeviceController::class, 'index'])->name('devices.index');
        Route::get('devices/status', [ParentDeviceController::class, 'status'])->name('devices.status');
        Route::post('devices/pairing-code', [ParentDeviceController::class, 'pairingCode'])->middleware('throttle:10,1')->name('devices.pairingCode');
        Route::post('devices/lock', [ParentDeviceController::class, 'lock'])->name('devices.lock');
        Route::post('devices/lock-all', [ParentDeviceController::class, 'lockAll'])->name('devices.lockAll');
        Route::put('devices/policy', [ParentDeviceController::class, 'updatePolicy'])->name('devices.policy');
        Route::post('devices/pin', [ParentDeviceController::class, 'pin'])->middleware('throttle:10,1')->name('devices.pin');
        Route::post('devices/requests/{extraTimeRequest}/decide', [ParentDeviceController::class, 'decide'])
            ->whereNumber('extraTimeRequest')->name('devices.requests.decide');
        Route::delete('devices/{device}', [ParentDeviceController::class, 'destroy'])->whereNumber('device')->name('devices.destroy');
        // SỬA 9/10 — màn Đổi mật khẩu riêng (App\Http\Controllers\Account\PasswordController); khu suy ra từ tên route.
        Route::get('password', [AccountPasswordController::class, 'edit'])->name('password.edit');
        Route::put('password', [AccountPasswordController::class, 'update'])->middleware('throttle:6,1')->name('password.update');
    });

    Route::prefix('danh-gia')->name('reviews.')->group(function () {
        Route::get('/', [ReviewController::class, 'index'])->name('index');
        Route::get('/viet', [ReviewController::class, 'form'])->name('form');
        Route::post('/viet', [ReviewController::class, 'store'])->name('store');
        Route::get('/chua-du-dieu-kien', [ReviewController::class, 'ineligible'])->name('ineligible');
        Route::get('/cua-toi', [ReviewController::class, 'myReviews'])->name('myReviews');
    });

    Route::prefix('quyen')->name('access.')->group(function () {
        Route::get('/dat-don/{product}', [AccessController::class, 'checkout'])->name('checkout');
        // SỬA 25/8 — nối "Đặt đơn" thành submit thật (trước đây chỉ có GET hiển thị trang, xem
        // AccessService::placeOrder()).
        Route::post('/dat-don/{product}', [AccessController::class, 'store'])->name('checkout.store');
        // C3 (15/9) — mua khoá học xong thì tự chọn một lớp đang mở. Đường nhập mã lớp
        // (student.classes.join) vẫn giữ nguyên làm lối phụ.
        Route::get('/chon-lop/{course}', [AccessCourseEnrollmentController::class, 'chooseClass'])->name('chooseClass');
        Route::post('/chon-lop/{course}', [AccessCourseEnrollmentController::class, 'enroll'])->name('chooseClass.store');
        Route::get('/kich-hoat', [AccessController::class, 'activate'])->name('activate');
        // SỬA 25/8 — nối "Kích hoạt" thành submit thật (xem AccessService::activateCode()).
        Route::post('/kich-hoat', [AccessController::class, 'activateStore'])->name('activate.store');
        Route::get('/cua-toi', [AccessController::class, 'myAccess'])->name('myAccess');
        Route::get('/khoa/{material}', [AccessController::class, 'blocked'])->name('blocked');
        // SỬA 25/8 (2) — "lưu lại lịch sử đặt mua có học sinh luôn", xem
        // AccessService::purchaseHistoryData().
        Route::get('/lich-su', [AccessController::class, 'history'])->name('history');
        // SỬA 27/8 ("4 file đính kèm sản phẩm", đủ 4 ô) — tải/xem PDF nội dung chính/PDF
        // hướng dẫn/ZIP bài tập/học liệu media của 1 sản phẩm. Đặt ở group role-agnostic này
        // (giống checkout/blocked) vì mọi vai trò đã mua đều tải/xem được — TRỪ RIÊNG kind
        // 'guide': SỬA 28/8 ("học sinh xem toàn bộ file trừ hướng dẫn") chặn hẳn cho vai trò
        // học sinh ngay trong AccessService::downloadResource(), không chỉ ẩn ở UI.
        Route::get('/tai-nguyen/{product}/{kind}', [AccessController::class, 'resource'])
            ->whereIn('kind', ['content', 'guide', 'exercise', 'media'])
            ->name('resource');
        // SỬA 31/8 ("ZIP bài tập" gắn vào sản phẩm) — đề bài/lời giải/code mẫu của 1 bài tập cụ
        // thể (khác 4 tệp gắn thẳng Product ở route ngay trên) — xem
        // AccessService::downloadExerciseAttachment().
        Route::get('/tai-nguyen/{product}/bai-tap/{exercise}/{kind}', [AccessController::class, 'exerciseAttachment'])
            ->whereIn('kind', ['statement', 'solution', 'reference'])
            ->name('resource.exerciseAttachment');
    });

    Route::prefix('vi')->name('wallet.')->group(function () {
        Route::get('/', [WalletController::class, 'index'])->name('index');
        Route::post('/nap', [WalletController::class, 'requestTopup'])->name('request');
        // SỬA 3/11 — "Tôi đã chuyển khoản" → Chờ duyệt + báo admin.
        Route::post('/nap/{tokenTopup}/da-chuyen-khoan', [WalletController::class, 'confirmTransfer'])->middleware('throttle:10,1')->name('confirm');
        Route::get('/qr', [WalletController::class, 'qrImage'])->name('qr'); // SỬA 21/10 — ảnh QR ngân hàng
    });

    // SỬA 28/10 (khách: "phân quyền từng tính năng sidebar admin") — mở cho cả Editor; chặn THẬT từng mục / thao tác bằng
    // middleware admin.perm (App\Support\AdminPermissions). Admin mặc định có hết, Editor chỉ có mục được cấp.
    Route::middleware(['role:admin,super_admin,editor', 'admin.perm'])->prefix('admin')->name('admin.')->group(function () {
        Route::get('/', [AdminDashboardController::class, 'index'])->name('dashboard');

        Route::get('users', [AdminUserController::class, 'index'])->name('users.index');
        Route::get('users/create', [AdminUserController::class, 'create'])->name('users.create');
        Route::post('users', [AdminUserController::class, 'store'])->name('users.store');
        Route::get('users/{user}/edit', [AdminUserController::class, 'edit'])->name('users.edit');
        Route::put('users/{user}', [AdminUserController::class, 'update'])->name('users.update');
        Route::put('users/{user}/roles', [AdminUserController::class, 'updateRoles'])->name('users.roles.update');
        Route::put('users/{user}/password', [AdminUserController::class, 'resetPassword'])->name('users.password.update');
        Route::put('users/{user}/permissions', [AdminUserController::class, 'updatePermissions'])->name('users.permissions.update');
        Route::get('users/{user}/panel', [AdminUserController::class, 'panel'])->name('users.panel');
        Route::post('users/{user}/restore', [AdminUserController::class, 'restore'])->name('users.restore');
        // SỬA 12/11 — nút Khóa / Mở khóa ở từng dòng danh sách người dùng (popup xử phạt).
        Route::post('users/{user}/lock', [AdminLeaderboardPenaltyController::class, 'lockUser'])->name('users.lock');
        Route::post('users/{user}/unlock', [AdminLeaderboardPenaltyController::class, 'unlockUser'])->name('users.unlock');
        Route::delete('users/{user}', [AdminUserController::class, 'destroy'])->name('users.destroy');
        Route::get('users/{user}', [AdminUserController::class, 'show'])->name('users.show');
        Route::post('parent-links/{parentLink}/approve', [AdminUserController::class, 'approveParentLink'])->name('parent-links.approve');
        Route::post('parent-links/{parentLink}/reject', [AdminUserController::class, 'rejectParentLink'])->name('parent-links.reject');
        Route::get('teacher-approvals', [AdminTeacherApprovalController::class, 'index'])->name('teacher-approvals.index');
        Route::get('teacher-approvals/{teacherApproval}', [AdminTeacherApprovalController::class, 'show'])->name('teacher-approvals.show');
        Route::post('teacher-approvals/{teacherApproval}/approve', [AdminTeacherApprovalController::class, 'approve'])->name('teacher-approvals.approve');
        Route::post('teacher-approvals/{teacherApproval}/reject', [AdminTeacherApprovalController::class, 'reject'])->name('teacher-approvals.reject');
        Route::post('teacher-approvals/{teacherApproval}/suspend', [AdminTeacherApprovalController::class, 'suspend'])->name('teacher-approvals.suspend');
        Route::post('teacher-approvals/{teacherApproval}/reinstate', [AdminTeacherApprovalController::class, 'reinstate'])->name('teacher-approvals.reinstate');

        /*
         * LỘ TRÌNH HỌC (A6–A9, A12) — cấp trên của Khoá học.
         * Đặt ngay trước nhóm khoá học vì hai thứ đi liền nhau trong đầu người dùng.
         */
        Route::get('learning-paths', [AdminLearningPathController::class, 'index'])->name('learning-paths.index');
        Route::get('learning-paths/create', [AdminLearningPathController::class, 'create'])->name('learning-paths.create');
        Route::post('learning-paths', [AdminLearningPathController::class, 'store'])->name('learning-paths.store');
        Route::get('learning-paths/{learningPath}/edit', [AdminLearningPathController::class, 'edit'])->name('learning-paths.edit');
        Route::put('learning-paths/{learningPath}', [AdminLearningPathController::class, 'update'])->name('learning-paths.update');
        // Màn xếp bậc và các thao tác của nó.
        Route::get('learning-paths/{learningPath}/steps', [AdminLearningPathController::class, 'steps'])->name('learning-paths.steps');
        Route::post('learning-paths/{learningPath}/steps', [AdminLearningPathController::class, 'attachCourse'])->name('learning-paths.steps.attach');
        Route::delete('learning-paths/{learningPath}/steps', [AdminLearningPathController::class, 'detachCourse'])->name('learning-paths.steps.detach');
        Route::post('learning-paths/{learningPath}/steps/reorder', [AdminLearningPathController::class, 'reorder'])->name('learning-paths.steps.reorder');
        Route::post('learning-paths/{learningPath}/status', [AdminLearningPathController::class, 'changeStatus'])->name('learning-paths.status');
        Route::delete('learning-paths/{learningPath}', [AdminLearningPathController::class, 'destroy'])->name('learning-paths.destroy');

        Route::get('courses', [AdminCourseController::class, 'index'])->name('courses.index');
        Route::get('courses/create', [AdminCourseController::class, 'create'])->name('courses.create');
        Route::post('courses', [AdminCourseController::class, 'store'])->name('courses.store');
        Route::get('courses/{course}', [AdminCourseController::class, 'show'])->name('courses.show');
        Route::get('courses/{course}/edit', [AdminCourseController::class, 'edit'])->name('courses.edit');
        Route::put('courses/{course}', [AdminCourseController::class, 'update'])->name('courses.update');
        Route::delete('courses/{course}', [AdminCourseController::class, 'destroy'])->name('courses.destroy');
        Route::get('courses/{course}/classes/create', [AdminCourseController::class, 'classesCreate'])->name('courses.classes.create');
        Route::post('courses/{course}/classes', [AdminCourseController::class, 'classesStore'])->name('courses.classes.store');
        Route::get('classes/{classRoom}/edit', [AdminCourseController::class, 'classesEdit'])->name('classes.edit');
        Route::put('classes/{classRoom}', [AdminCourseController::class, 'classesUpdate'])->name('classes.update');
        Route::delete('classes/{classRoom}', [AdminCourseController::class, 'classesDestroy'])->name('classes.destroy');
        // SỬA 3/11 (khách: "admin add tài liệu vào lớp giùm giáo viên nếu giáo viên chưa mua") — học liệu của lớp.
        Route::post('classes/{classRoom}/materials', [AdminCourseController::class, 'classMaterialAttach'])->whereNumber('classRoom')->name('classes.materials.attach');
        Route::delete('classes/{classRoom}/materials/{classMaterial}', [AdminCourseController::class, 'classMaterialDetach'])
            ->whereNumber(['classRoom', 'classMaterial'])->name('classes.materials.detach');

        Route::get('products', [AdminProductController::class, 'index'])->name('products.index');
        Route::get('products/create', [AdminProductController::class, 'create'])->name('products.create');
        Route::post('products', [AdminProductController::class, 'store'])->name('products.store');
        Route::get('products/{product}/edit', [AdminProductController::class, 'edit'])->name('products.edit');
        Route::put('products/{product}', [AdminProductController::class, 'update'])->name('products.update');
        Route::delete('products/{product}', [AdminProductController::class, 'destroy'])->name('products.destroy');
        // SỬA 16/10 — đổi thứ tự tài liệu bằng nút ↑ / ↓ ở danh sách (thứ tự này dùng luôn cho trang Tài liệu public).
        Route::post('products/{product}/move', [AdminProductController::class, 'move'])->name('products.move');
        Route::get('products/{product}', [AdminProductController::class, 'show'])->name('products.show');
        // SỬA 7/11 (khách: "up cả quyển sách, chỉ lưu lại, xem trước, in, tải PDF") — tệp PDF cả cuốn lưu nội bộ để in khi có khách đặt
        // bản in (Admin\ProductPrintBookController). Chỉ thêm, không đụng các route tài liệu khác.
        Route::post('products/{product}/ban-in-ca-cuon', [\App\Http\Controllers\Admin\ProductPrintBookController::class, 'upload'])->whereNumber('product')->name('products.print-book.upload');
        Route::get('products/{product}/ban-in-ca-cuon', [\App\Http\Controllers\Admin\ProductPrintBookController::class, 'file'])->whereNumber('product')->name('products.print-book.file');
        Route::delete('products/{product}/ban-in-ca-cuon', [\App\Http\Controllers\Admin\ProductPrintBookController::class, 'destroy'])->whereNumber('product')->name('products.print-book.destroy');
        // SỬA 18/10 — MODULE BỘ ĐỀ (Admin\ExamBundleController -> App\Services\ExamBundle\ExamBundleService).
        Route::prefix('products/{product}/bundle')->name('products.bundle.')->group(function () {
            $c = \App\Http\Controllers\Admin\ExamBundleController::class;
            Route::post('filters', [$c, 'saveFilters'])->name('filters');
            Route::post('lock', [$c, 'lock'])->name('lock');
            Route::post('items', [$c, 'add'])->name('add');
            Route::delete('items/{assessment}', [$c, 'remove'])->whereNumber('assessment')->name('remove');
            Route::post('items/{assessment}/restore', [$c, 'restore'])->whereNumber('assessment')->name('restore');
            Route::post('items/{assessment}/move', [$c, 'move'])->whereNumber('assessment')->name('move');
            Route::post('reset-order', [$c, 'resetOrder'])->name('resetOrder');
        });
        Route::post('content/assessments/{assessment}/bundle-only', [\App\Http\Controllers\Admin\ExamBundleController::class, 'assessmentVisibility'])->name('content.assessments.bundle.visibility');
        Route::post('content/assessments/{assessment}/bundles', [\App\Http\Controllers\Admin\ExamBundleController::class, 'assessmentAttach'])->name('content.assessments.bundle.attach');
        // SỬA 3/11 — NHÓM MÃ ĐỀ (xem App\Services\ExamVariantService): gắn / đổi tên mã / gỡ khỏi nhóm.
        Route::post('content/assessments/{assessment}/variants', [\App\Http\Controllers\Admin\ExamVariantController::class, 'attach'])->name('content.assessments.variants.attach');
        Route::post('content/assessments/{assessment}/variant-code', [\App\Http\Controllers\Admin\ExamVariantController::class, 'code'])->name('content.assessments.variants.code');
        Route::post('content/assessments/{assessment}/variant-detach', [\App\Http\Controllers\Admin\ExamVariantController::class, 'detach'])->name('content.assessments.variants.detach');

        // SỬA 14/10 (khách: "admin đọc được tất cả tài liệu, không cần mua") — màn đọc tài liệu cho
        // admin, dùng chung bộ đọc với học sinh/giáo viên. Xem Admin\MaterialReadController.
        Route::get('doc-tai-lieu/{material}', [AdminMaterialReadController::class, 'read'])
            ->whereNumber('material')->name('materials.read');
        Route::get('doc-tai-lieu/{material}/file', [AdminMaterialReadController::class, 'pdfFile'])
            ->whereNumber('material')->name('materials.file');
        Route::get('doc-tai-lieu/san-pham/{product}', [AdminMaterialReadController::class, 'product'])
            ->whereNumber('product')->name('products.read');
        Route::get('doc-tai-lieu/san-pham/{product}/{material}/file', [AdminMaterialReadController::class, 'productFile'])
            ->whereNumber(['product', 'material'])->name('products.read.file');
        Route::get('doc-tai-lieu/san-pham/{product}/{material}/asset/{kind}', [AdminMaterialReadController::class, 'productAsset'])
            ->whereNumber(['product', 'material'])->whereIn('kind', ['audio', 'image'])
            ->name('products.read.asset');

        // SỬA 31/8 ("ZIP bài tập" gắn vào sản phẩm) — CHỈ Admin/Super Admin quản lý (cùng
        // middleware role:admin,super_admin với các route products.* ở trên) — không mở cho
        // editor/giáo viên. Xem App\Http\Controllers\Admin\ProductExerciseController.
        Route::post('products/{product}/exercises', [AdminProductExerciseController::class, 'store'])->name('products.exercises.store');
        // SỬA 27/10 — nhập HÀNG LOẠT (kiểm trùng trước, rồi nhập lần lượt từng bài). Xem Admin\ProductExerciseBulkController.
        Route::post('products/{product}/exercises/bulk', [AdminProductExerciseBulkController::class, 'prepare'])->name('products.exercises.bulk.prepare');
        Route::get('products/{product}/exercises/kiem-tra-ma', [AdminProductExerciseBulkController::class, 'checkCode'])->name('products.exercises.checkCode');
        // SỬA 27/10 — chọn nhiều bài rồi xoá một lần (danh sách Bài tập đính kèm). Xem ProductExerciseBulkController::destroyMany().
        Route::delete('products/{product}/exercises', [AdminProductExerciseBulkController::class, 'destroyMany'])->name('products.exercises.destroyMany');
        // SỬA 27/10 — "Lấy từ bài có sẵn" (bài tập của tài liệu khác → bản sao vào tài liệu này). Xem Admin\ProductExercisePickController.
        Route::get('products/{product}/exercises/lay-tu-bai-co-san', [AdminProductExercisePickController::class, 'sources'])->name('products.exercises.pick.sources');
        Route::post('products/{product}/exercises/lay-tu-bai-co-san', [AdminProductExercisePickController::class, 'store'])->name('products.exercises.pick.store');
        // SỬA 27/10 lần 2 — gỡ bài DÙNG KÉ khỏi tài liệu (bài gốc giữ nguyên).
        Route::delete('products/{product}/exercises/{exercise}/dung-ke', [AdminProductExercisePickController::class, 'unlink'])->name('products.exercises.pick.unlink');
        // SỬA 27/10 — chọn nhiều bài dùng chung rồi gỡ một lần.
        Route::delete('products/{product}/bai-dung-chung', [AdminProductExercisePickController::class, 'unlinkMany'])->name('products.exercises.pick.unlinkMany');
        Route::post('products/{product}/exercises/bulk/{token}/{index}', [AdminProductExerciseBulkController::class, 'import'])
            ->where('token', '[A-Za-z0-9]{32}')->whereNumber('index')->name('products.exercises.bulk.import');
        Route::post('products/{product}/exercises/bulk/{token}/xong', [AdminProductExerciseBulkController::class, 'finish'])
            ->where('token', '[A-Za-z0-9]{32}')->name('products.exercises.bulk.finish');
        // SỬA 4/9 (khách yêu cầu "vừa thêm được từ ZIP và thêm thủ công nữa") — form nhập tay
        // riêng, xem ProductExerciseController::createManual()/storeManual().
        Route::get('products/{product}/exercises/create', [AdminProductExerciseController::class, 'createManual'])->name('products.exercises.createManual');
        Route::post('products/{product}/exercises/manual', [AdminProductExerciseController::class, 'storeManual'])->name('products.exercises.storeManual');
        Route::get('products/{product}/exercises/{exercise}/edit', [AdminProductExerciseController::class, 'edit'])->name('products.exercises.edit');
        Route::put('products/{product}/exercises/{exercise}', [AdminProductExerciseController::class, 'update'])->name('products.exercises.update');
        Route::delete('products/{product}/exercises/{exercise}', [AdminProductExerciseController::class, 'destroy'])->name('products.exercises.destroy');
        Route::get('products/{product}/exercises/{exercise}/attachment/{kind}', [AdminProductExerciseController::class, 'attachmentDownload'])->name('products.exercises.attachment');
        // SỬA 31/8 (2, "mở rộng ZIP bài tập" — audio/ảnh...): xem lý do tách riêng khỏi route
        // 'attachment' ở trên (3 tên CỐ ĐỊNH) ở Admin\ProductExerciseController::assetDownload().
        Route::get('products/{product}/exercises/{exercise}/asset/{asset}', [AdminProductExerciseController::class, 'assetDownload'])->name('products.exercises.asset');

        // SỬA 4/9 (khách yêu cầu "Chương/Phần/Đề") — CRUD gọn (chỉ Tiêu đề+Thứ tự) cho mục
        // lục chương/phần/đề của 1 sản phẩm, xem App\Http\Controllers\Admin\
        // ProductChapterController + ContentService::productChapter*().
        Route::post('products/{product}/chapters', [AdminProductChapterController::class, 'store'])->name('products.chapters.store');
        Route::put('products/{product}/chapters/{chapter}', [AdminProductChapterController::class, 'update'])->name('products.chapters.update');
        Route::delete('products/{product}/chapters/{chapter}', [AdminProductChapterController::class, 'destroy'])->name('products.chapters.destroy');
        // SỬA 15/10 — đảo thứ tự chương bằng nút ↑ / ↓.
        Route::post('products/{product}/chapters/{chapter}/move', [AdminProductChapterController::class, 'move'])->name('products.chapters.move');

        Route::get('access-rights', [AdminAccessRightController::class, 'index'])->name('access-rights.index');
        Route::get('access-rights/create', [AdminAccessRightController::class, 'create'])->name('access-rights.create');
        Route::post('access-rights', [AdminAccessRightController::class, 'store'])->name('access-rights.store');
        Route::post('access-rights/{accessRight}/revoke', [AdminAccessRightController::class, 'revoke'])->name('access-rights.revoke');
        Route::get('access-rights/{accessRight}', [AdminAccessRightController::class, 'show'])->name('access-rights.show');

        Route::get('orders', [AdminOrderController::class, 'index'])->name('orders.index');
        Route::post('orders/{order}/approve', [AdminOrderController::class, 'approve'])->name('orders.approve');
        Route::post('orders/{order}/reject', [AdminOrderController::class, 'reject'])->name('orders.reject');
        // SỬA 9/11 — cập nhật trạng thái giao sách in (Chờ giao / Đang giao / Đã giao / Huỷ giao). Xem OrderService::updateDelivery().
        Route::post('orders/{order}/giao-hang', [AdminOrderController::class, 'updateDelivery'])->name('orders.delivery');
        Route::get('orders/{order}', [AdminOrderController::class, 'show'])->name('orders.show');
        Route::get('activation-codes', [AdminActivationCodeController::class, 'index'])->name('activation-codes.index');
        // SỬA 18/9 (khách: "thêm tính năng thêm mã kích hoạt") — admin cấp tay 1 mã cho đúng 1
        // tài khoản; luật "mã của ai thì người đó mở" thi hành ở OrderActivationService::canActivate().
        Route::get('activation-codes/create', [AdminActivationCodeController::class, 'create'])->name('activation-codes.create');
        Route::post('activation-codes', [AdminActivationCodeController::class, 'store'])->name('activation-codes.store');
        Route::post('activation-codes/{activationCode}/revoke', [AdminActivationCodeController::class, 'revoke'])->name('activation-codes.revoke');

        Route::post('orders/token-topups/{tokenTopup}/approve', [AdminOrderController::class, 'approveTopup'])->name('orders.token-topups.approve');
        Route::post('orders/token-topups/{tokenTopup}/reject', [AdminOrderController::class, 'rejectTopup'])->name('orders.token-topups.reject');

        Route::get('reviews', [AdminReviewController::class, 'index'])->name('reviews.index');
        Route::post('reviews/{review}/publish', [AdminReviewController::class, 'publish'])->name('reviews.publish');
        Route::post('reviews/{review}/reject', [AdminReviewController::class, 'reject'])->name('reviews.reject');
        Route::post('reviews/{review}/request-revision', [AdminReviewController::class, 'requestRevision'])->name('reviews.request-revision');
        Route::post('reviews/{review}/hide', [AdminReviewController::class, 'hide'])->name('reviews.hide');
        Route::post('reviews/{review}/reply', [AdminReviewController::class, 'reply'])->name('reviews.reply');
        Route::get('reviews/{review}', [AdminReviewController::class, 'show'])->name('reviews.show');

        /*
         * Yêu cầu hỗ trợ gửi từ form ở trang Thông tin công khai.
         * CHỈ QUẢN TRỊ VIÊN đọc được — nhóm này đang ở trong middleware role:admin,super_admin
         * nên tài khoản biên tập / giáo viên / học sinh gõ thẳng địa chỉ cũng bị chặn.
         */
        // SỬA 4/11 (khách: "admin có thể thông báo cho học sinh và phụ huynh") — mục Thông báo (App\Support\AdminPermissions: announcements).
        Route::get('announcements', [AdminAnnouncementController::class, 'index'])->name('announcements.index');
        Route::get('announcements/preview', [AdminAnnouncementController::class, 'preview'])->name('announcements.preview');
        Route::post('announcements', [AdminAnnouncementController::class, 'store'])->name('announcements.store');
        Route::post('announcements/{announcement}/recall', [AdminAnnouncementController::class, 'recall'])->whereNumber('announcement')->name('announcements.recall');
        Route::post('announcements/{announcement}/pin', [AdminAnnouncementController::class, 'pin'])->whereNumber('announcement')->name('announcements.pin');
        Route::delete('announcements/{announcement}', [AdminAnnouncementController::class, 'destroy'])->whereNumber('announcement')->name('announcements.destroy');

        Route::get('contact-messages', [AdminContactMessageController::class, 'index'])->name('contact-messages.index');
        Route::post('contact-messages/{contactMessage}/status', [AdminContactMessageController::class, 'updateStatus'])->name('contact-messages.status');
        Route::post('contact-messages/{contactMessage}/note', [AdminContactMessageController::class, 'note'])->name('contact-messages.note');
        // Đường dẫn cũ, giữ lại cho liên kết/dấu trang đã lưu.
        Route::post('contact-messages/{contactMessage}/resolve', [AdminContactMessageController::class, 'resolve'])->name('contact-messages.resolve');

        Route::get('competitions', [AdminCompetitionController::class, 'index'])->name('competitions.index');
        Route::get('competitions/create', [AdminCompetitionController::class, 'create'])->name('competitions.create');
        Route::post('competitions', [AdminCompetitionController::class, 'store'])->name('competitions.store');
        Route::get('competitions/{competition}/edit', [AdminCompetitionController::class, 'edit'])->name('competitions.edit');
        Route::put('competitions/{competition}', [AdminCompetitionController::class, 'update'])->name('competitions.update');
        Route::post('competitions/{competition}/archive', [AdminCompetitionController::class, 'archive'])->name('competitions.archive');
        Route::post('competitions/{competition}/unarchive', [AdminCompetitionController::class, 'unarchive'])->name('competitions.unarchive');
        // SỬA 24/10 — nút Xoá ở danh sách cuộc thi: xoá vĩnh viễn cuộc thi + kỳ thi + bài làm + đề liên quan.
        Route::delete('competitions/{competition}', [AdminCompetitionController::class, 'destroy'])->name('competitions.destroy');
        Route::get('competitions/{competition}', [AdminCompetitionController::class, 'show'])->name('competitions.show');
        Route::post('competitions/{competition}/exams', [AdminCompetitionController::class, 'examStore'])->name('competitions.exams.store');
        Route::put('competitions/exams/{competitionExam}', [AdminCompetitionController::class, 'examUpdate'])->name('competitions.exams.update');
        Route::delete('competitions/exams/{competitionExam}', [AdminCompetitionController::class, 'examDestroy'])->name('competitions.exams.destroy');
        // SỬA 19/9 (khách: "click đăng ký tham gia thì admin sẽ duyệt") — duyệt/từ chối đơn đăng
        // ký cuộc thi, đặt ngay trong màn chi tiết cuộc thi chứ không đẻ trang riêng. Xem
        // Admin\CompetitionService::registrationsData().
        Route::post('competitions/{competition}/registrations/{registration}/approve', [AdminCompetitionController::class, 'approveRegistration'])
            ->whereNumber(['competition', 'registration'])->name('competitions.registrations.approve');
        Route::post('competitions/{competition}/registrations/{registration}/reject', [AdminCompetitionController::class, 'rejectRegistration'])
            ->whereNumber(['competition', 'registration'])->name('competitions.registrations.reject');
        // SỬA 19/9 (11) — GỠ thí sinh đã duyệt khỏi cuộc thi (khác 'reject' vốn chỉ áp dụng cho
        // đơn ĐANG CHỜ duyệt).
        Route::post('competitions/{competition}/registrations/{registration}/revoke', [AdminCompetitionController::class, 'revokeRegistration'])
            ->whereNumber(['competition', 'registration'])->name('competitions.registrations.revoke');
        Route::post('competitions/{competition}/recompute-aggregate', [AdminCompetitionController::class, 'recomputeAggregate'])->name('competitions.recompute-aggregate');
        // SỬA 12/9 — khối "Câu chuyện đồng hành" của trang chủ ([HOME-10]) giờ do Admin đăng.
        Route::get('testimonials', [AdminTestimonialController::class, 'index'])->name('testimonials.index');
        Route::get('testimonials/create', [AdminTestimonialController::class, 'create'])->name('testimonials.create');
        Route::post('testimonials', [AdminTestimonialController::class, 'store'])->name('testimonials.store');
        Route::get('testimonials/{testimonial}/edit', [AdminTestimonialController::class, 'edit'])->name('testimonials.edit');
        Route::put('testimonials/{testimonial}', [AdminTestimonialController::class, 'update'])->name('testimonials.update');
        Route::post('testimonials/{testimonial}/toggle', [AdminTestimonialController::class, 'togglePublish'])->name('testimonials.toggle');
        Route::delete('testimonials/{testimonial}', [AdminTestimonialController::class, 'destroy'])->name('testimonials.destroy');

        Route::get('featured-teachers', [AdminFeaturedTeacherController::class, 'index'])->name('featured-teachers.index');
        // SỬA 4/10 (khách: "thêm cho tôi mục thêm giáo viên chuyên gia nữa nha để người ta thêm
        // trực tiếp bên này luôn") — tạo hồ sơ trưng bày không gắn tài khoản, và xoá hẳn hồ sơ
        // loại đó. Hồ sơ gắn tài khoản thật thì destroy() từ chối, xem controller.
        Route::post('featured-teachers', [AdminFeaturedTeacherController::class, 'store'])->name('featured-teachers.store');
        Route::delete('featured-teachers/{featuredTeacher}', [AdminFeaturedTeacherController::class, 'destroy'])->name('featured-teachers.destroy');
        Route::post('featured-teachers/{featuredTeacher}/feature', [AdminFeaturedTeacherController::class, 'feature'])->name('featured-teachers.feature');
        // SỬA 4/10 (khách: "admin có thể thêm sửa xoá") — thêm đường SỬA. "Xoá" ở màn này là rút
        // tên khỏi trang vinh danh (unfeature), KHÔNG xoá hồ sơ/tài khoản giáo viên.
        Route::put('featured-teachers/{featuredTeacher}', [AdminFeaturedTeacherController::class, 'update'])->name('featured-teachers.update');
        Route::post('featured-teachers/{featuredTeacher}/unfeature', [AdminFeaturedTeacherController::class, 'unfeature'])->name('featured-teachers.unfeature');
        Route::get('ranking', [AdminRankingController::class, 'index'])->name('ranking.index');
        // SỬA 12/11 — xử phạt tài khoản vi phạm (hiện ở tab "Tài khoản vi phạm" của trang Bảng xếp hạng công khai).
        Route::get('ranking/violations', [AdminLeaderboardPenaltyController::class, 'index'])->name('ranking.violations.index');
        Route::get('ranking/violations/accounts', [AdminLeaderboardPenaltyController::class, 'accounts'])->name('ranking.violations.accounts');
        Route::post('ranking/violations', [AdminLeaderboardPenaltyController::class, 'store'])->name('ranking.violations.store');
        Route::post('ranking/violations/{penalty}/unlock', [AdminLeaderboardPenaltyController::class, 'unlock'])->whereNumber('penalty')->name('ranking.violations.unlock');
        Route::delete('ranking/violations/{penalty}', [AdminLeaderboardPenaltyController::class, 'destroy'])->whereNumber('penalty')->name('ranking.violations.destroy');
        Route::get('ranking/{scope}/{id}', [AdminRankingController::class, 'show'])
            ->whereIn('scope', ['competition', 'class', 'exam'])
            ->where('id', '[0-9]+')
            ->name('ranking.show');

        Route::get('reports', [AdminReportController::class, 'index'])->name('reports.index');

        Route::middleware('role:super_admin')->group(function () {
            Route::get('settings', [AdminSettingsController::class, 'index'])->name('settings.index');
            Route::put('settings/rating-threshold', [AdminSettingsController::class, 'updateRatingThreshold'])->name('settings.rating-threshold.update');
            Route::put('settings/wallet-bank', [AdminSettingsController::class, 'updateWalletBankInfo'])->name('settings.wallet-bank.update');
        });
    });

    Route::middleware(['role:admin,super_admin,editor', 'admin.perm'])->prefix('admin')->name('admin.')->group(function () {
        Route::get('content', [AdminContentController::class, 'index'])->name('content.index');

        Route::get('content/materials/create', [AdminContentController::class, 'materialsCreate'])->name('content.materials.create');
        Route::post('content/materials', [AdminContentController::class, 'materialsStore'])->name('content.materials.store');
        // SỬA 25/8 — "tải bài hàng loạt" qua ZIP (16 mục "tải bài"): xem
        // Admin\ContentService::materialsBulkImportFromZip(). Đặt TRƯỚC {material}/edit bên
        // dưới theo đúng quy ước của content/assessments/bulk ở dưới (dễ đọc, dù không bắt buộc
        // vì 'bulk' không trùng số đoạn với '{material}/edit').
        Route::get('content/materials/bulk', [AdminContentController::class, 'materialsBulkImportCreate'])->name('content.materials.bulk.create');
        Route::post('content/materials/bulk', [AdminContentController::class, 'materialsBulkImportStore'])->name('content.materials.bulk.store');
        Route::get('content/materials/{material}/edit', [AdminContentController::class, 'materialsEdit'])->name('content.materials.edit');
        Route::put('content/materials/{material}', [AdminContentController::class, 'materialsUpdate'])->name('content.materials.update');
        Route::post('content/materials/{material}/publish', [AdminContentController::class, 'materialsPublish'])->name('content.materials.publish');
        Route::post('content/materials/{material}/reject', [AdminContentController::class, 'materialsReject'])->name('content.materials.reject');
        Route::post('content/materials/{material}/archive', [AdminContentController::class, 'materialsArchive'])->name('content.materials.archive');
        // SỬA 25/8 (7) — "thêm tính năng xóa cho admin, xóa luôn file liên quan tránh rác", xem
        // ContentService::materialDelete().
        Route::delete('content/materials/{material}', [AdminContentController::class, 'materialsDestroy'])->name('content.materials.destroy');

        Route::get('content/questions/create', [AdminContentController::class, 'questionsCreate'])->name('content.questions.create');
        Route::post('content/questions', [AdminContentController::class, 'questionsStore'])->name('content.questions.store');
        Route::get('content/questions/{question}/edit', [AdminContentController::class, 'questionsEdit'])->name('content.questions.edit');
        Route::put('content/questions/{question}', [AdminContentController::class, 'questionsUpdate'])->name('content.questions.update');
        Route::patch('content/questions/{question}/display-order', [AdminContentController::class, 'questionsDisplayOrder'])->name('content.questions.displayOrder');
        Route::post('content/questions/{question}/new-version', [AdminContentController::class, 'questionsNewVersion'])->name('content.questions.newVersion');
        Route::post('content/questions/{question}/publish', [AdminContentController::class, 'questionsPublish'])->name('content.questions.publish');
        Route::post('content/questions/{question}/reject', [AdminContentController::class, 'questionsReject'])->name('content.questions.reject');
        Route::post('content/questions/{question}/archive', [AdminContentController::class, 'questionsArchive'])->name('content.questions.archive');
        // SỬA 4/10 (khách: "phần danh sách bài không thấy nút xoá") — xoá câu hỏi/đề kèm toàn bộ
        // tệp trên đĩa. Service từ chối khi đã có người làm hoặc đang nằm trong đề/cuộc thi.
        Route::delete('content/questions/{question}', [AdminContentController::class, 'questionsDestroy'])->name('content.questions.destroy');
        Route::delete('content/assessments/{assessment}', [AdminContentController::class, 'assessmentsDestroy'])->name('content.assessments.destroy');

        // SỬA 24/8 — "Nhập từ gói ZIP" (OT360-QPACK) cho câu hỏi lập trình: xem
        // Admin\ContentService::questionStoreFromZipPackage() + questionAttachmentInfo().
        Route::post('content/questions/zip-import', [AdminContentController::class, 'questionsZipImportStore'])->name('content.questions.zipImport');
        // SỬA 3/11 — nhập "Bài phổ thông" (1 bài nhiều câu) từ gói ZIP — App\Http\Controllers\GeneralSetController.
        Route::post('content/general-sets/zip-import', [\App\Http\Controllers\GeneralSetController::class, 'adminImport'])->name('content.generalSets.zipImport');
        // SỬA 3/11 — form nhập tay "Bài phổ thông" (đóng thành gói ZIP rồi nhập như trên).
        Route::post('content/general-sets/form', [\App\Http\Controllers\GeneralSetController::class, 'adminForm'])->name('content.generalSets.formStore');
        Route::post('content/general-sets/{assessment}/publish', [\App\Http\Controllers\GeneralSetController::class, 'adminPublish'])->whereNumber('assessment')->name('content.generalSets.publish');
        Route::post('content/general-sets/{assessment}/unpublish', [\App\Http\Controllers\GeneralSetController::class, 'adminUnpublish'])->whereNumber('assessment')->name('content.generalSets.unpublish');
        Route::delete('content/general-sets/{assessment}', [\App\Http\Controllers\GeneralSetController::class, 'adminDestroy'])->whereNumber('assessment')->name('content.generalSets.destroy');
        Route::get('content/questions/{question}/attachment/{kind}', [AdminContentController::class, 'questionsAttachmentDownload'])->name('content.questions.attachment');

        Route::get('content/questions/import', [AdminContentController::class, 'questionsImport'])->name('content.questions.import');
        Route::post('content/questions/import', [AdminContentController::class, 'questionsImportStore'])->name('content.questions.import.store');
        Route::get('content/questions/review-draft', [AdminContentController::class, 'questionsReviewDraft'])->name('content.questions.reviewDraft');
        Route::get('content/documents/{document}/file', [AdminContentController::class, 'downloadDocument'])->name('content.documents.download');
        Route::post('content/documents/{document}/drafts', [AdminContentController::class, 'draftStore'])->name('content.drafts.store');
        Route::post('content/drafts/{draft}', [AdminContentController::class, 'draftUpdate'])->name('content.drafts.update');
        Route::post('content/drafts/{draft}/merge', [AdminContentController::class, 'draftMerge'])->name('content.drafts.merge');
        Route::post('content/drafts/{draft}/discard', [AdminContentController::class, 'draftDiscard'])->name('content.drafts.discard');

        Route::post('content/tags', [AdminContentController::class, 'tagsStore'])->name('content.tags.store');
        Route::put('content/tags/{tag}', [AdminContentController::class, 'tagsUpdate'])->name('content.tags.update');
        Route::delete('content/tags/{tag}', [AdminContentController::class, 'tagsDestroy'])->name('content.tags.destroy');

        Route::get('content/assessments/create', [AdminContentController::class, 'assessmentsCreate'])->name('content.assessments.create');
        Route::post('content/assessments', [AdminContentController::class, 'assessmentsStore'])->name('content.assessments.store');
        // SỬA 16/10 — nhập cả đề (PDF + đáp án + bài lập trình) từ 1 gói ZIP OT360-EPACK, xem ExamZipImportService.
        Route::post('content/assessments/zip-import', [AdminContentController::class, 'assessmentsZipImportStore'])->name('content.assessments.zipImport');
        Route::get('content/assessments/bulk', [AdminContentController::class, 'assessmentsBulkCreate'])->name('content.assessments.bulk.create');
        Route::post('content/assessments/bulk/split', [AdminContentController::class, 'assessmentsBulkSplit'])->name('content.assessments.bulk.split');
        Route::post('content/assessments/bulk/multi', [AdminContentController::class, 'assessmentsBulkMulti'])->name('content.assessments.bulk.multi');
        Route::get('content/assessments/{assessment}/edit', [AdminContentController::class, 'assessmentsEdit'])->name('content.assessments.edit');
        Route::put('content/assessments/{assessment}', [AdminContentController::class, 'assessmentsUpdate'])->name('content.assessments.update');
        Route::get('content/assessments/{assessment}/items', [AdminContentController::class, 'assessmentsItemsEdit'])->name('content.assessments.items.edit');
        Route::put('content/assessments/{assessment}/items', [AdminContentController::class, 'assessmentsItemsUpdate'])->name('content.assessments.items.update');
        // SỬA 9/10 — dời một câu lên/xuống ngay ở trang chi tiết đề (khỏi mở form Chọn câu hỏi).
        Route::post('content/assessments/{assessment}/items/{item}/move', [AdminContentController::class, 'assessmentsItemsMove'])->name('content.assessments.items.move');
        // SỬA 16/10 — sửa/xoá/phát hành ngay trong danh sách "Câu hỏi trong đề".
        Route::delete('content/assessments/{assessment}/items/{item}', [AdminContentController::class, 'assessmentsItemsDestroy'])->name('content.assessments.items.destroy');
        Route::post('content/assessments/{assessment}/items/{item}/publish', [AdminContentController::class, 'assessmentsItemsPublishQuestion'])->name('content.assessments.items.publish');
        Route::post('content/assessments/{assessment}/items-publish-all', [AdminContentController::class, 'assessmentsItemsPublishAll'])->name('content.assessments.items.publishAll');
        Route::patch('content/assessments/{assessment}/items/{item}/points', [AdminContentController::class, 'assessmentsItemsPoints'])->name('content.assessments.items.points');
        Route::post('content/assessments/{assessment}/publish', [AdminContentController::class, 'assessmentsPublish'])->name('content.assessments.publish');
        Route::post('content/assessments/{assessment}/reject', [AdminContentController::class, 'assessmentsReject'])->name('content.assessments.reject');
        Route::post('content/assessments/{assessment}/archive', [AdminContentController::class, 'assessmentsArchive'])->name('content.assessments.archive');
        Route::post('content/assessments/{assessment}/promote-shared', [AdminContentController::class, 'assessmentsPromoteToShared'])->name('content.assessments.promoteShared');
        Route::get('content/assessments/{assessment}/pdf', [AdminContentController::class, 'assessmentsPdfEdit'])->name('content.assessments.pdf.edit');
        Route::put('content/assessments/{assessment}/pdf', [AdminContentController::class, 'assessmentsPdfUpdate'])->name('content.assessments.pdf.update');
        Route::post('content/assessments/{assessment}/coding-items', [AdminContentController::class, 'assessmentsCodingItemsStore'])->name('content.assessments.coding-items.store');
        Route::put('content/coding-items/{codingItem}', [AdminContentController::class, 'assessmentsCodingItemsUpdate'])->name('content.assessments.coding-items.update');
        Route::delete('content/coding-items/{codingItem}', [AdminContentController::class, 'assessmentsCodingItemsDestroy'])->name('content.assessments.coding-items.destroy');
        Route::post('content/coding-items/{codingItem}/test-cases/import', [AdminContentController::class, 'assessmentsCodingItemsTestCasesImport'])->name('content.assessments.coding-items.test-cases.import');

        Route::get('content/{content}', [AdminContentController::class, 'show'])->name('content.show');

        Route::get('profile', [AdminProfileController::class, 'show'])->name('profile.show');
        Route::put('profile', [AdminProfileController::class, 'update'])->name('profile.update');
        Route::put('profile/password', [AdminProfileController::class, 'updatePassword'])->name('profile.password');
        // SỬA 9/10 — màn Đổi mật khẩu riêng (App\Http\Controllers\Account\PasswordController); khu suy ra từ tên route.
        Route::get('password', [AccountPasswordController::class, 'edit'])->name('password.edit');
        Route::put('password', [AccountPasswordController::class, 'update'])->middleware('throttle:6,1')->name('password.update');
    });
});
