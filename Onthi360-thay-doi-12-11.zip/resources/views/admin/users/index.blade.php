@extends('layouts.admin')

@section('title', 'Người dùng')
@section('page-title', 'Người dùng')

@section('content')
    @php
        $tab = $tab ?? 'all';
        $tabs = $tabs ?? [];
        $users = $users ?? [];
        $total = $total ?? count($users);
        // Nhãn vai trò -> màu (chỉ là kiểu hiển thị; nhãn do UserService::presentUser() trả về, không đổi).
        $roleClass = function (string $label): string {
            $l = mb_strtolower($label);
            return match (true) {
                str_contains($l, 'admin') || str_contains($l, 'quản trị') || str_contains($l, 'editor') || str_contains($l, 'biên tập') => 'aux-role--admin',
                str_contains($l, 'giáo viên') => 'aux-role--teacher',
                str_contains($l, 'phụ huynh') => 'aux-role--parent',
                str_contains($l, 'học sinh') => 'aux-role--student',
                default => '',
            };
        };
        // SỬA 12/11 (khách: "thêm 1 tab hiển thị học sinh đã khóa") — tab "Đã khóa". UserService mới đã tự thêm tab + lọc; nếu
        // máy chủ còn UserService cũ thì dựng tab + lọc ngay tại đây (chỉ cần file view này là có tab).
        $isLockedUser = fn ($x) => ! ($x['trashed'] ?? false) && (($x['locked'] ?? false) || ! empty($x['lock']));
        if (! collect($tabs)->contains(fn ($t) => ($t['label'] ?? '') === 'Đã khóa')) {
            if ($tab === 'locked') {
                $users = array_values(array_filter($users, $isLockedUser));
                $total = count($users);
            }
            $lockedTab = ['label' => 'Đã khóa', 'href' => route('admin.users.index', ['tab' => 'locked']), 'active' => $tab === 'locked'];
            if (in_array($tab, ['all', 'locked'], true)) {
                $lockedTab['count'] = count(array_filter($users, $isLockedUser));
            }
            $pos = collect($tabs)->search(fn ($t) => ($t['label'] ?? '') === 'Đã xóa');
            array_splice($tabs, $pos === false ? count($tabs) : $pos, 0, [$lockedTab]);
        }
        $statusOptions = collect($users)->map(fn ($x) => (! ($x['trashed'] ?? false) && (($x['locked'] ?? false) || ! empty($x['lock']))) ? 'Đã khóa' : $x['status'])->unique()->values();
    @endphp

    @if (session('status') === 'user-created')
        @include('partials.toast-flash', ['type' => 'success', 'message' => 'Đã tạo tài khoản mới.'])
    @elseif (session('status') === 'user-deleted')
        @include('partials.toast-flash', ['type' => 'success', 'message' => 'Đã xóa người dùng. Có thể khôi phục ở tab "Đã xóa".'])
    @elseif (session('status') === 'user-restored')
        @include('partials.toast-flash', ['type' => 'success', 'message' => 'Đã khôi phục người dùng.'])
    @elseif (session('status') === 'user-locked')
        @include('partials.toast-flash', ['type' => 'success', 'message' => 'Đã khóa tài khoản '.session('lockedName').' — không đăng nhập được nữa.'])
    @elseif (session('status') === 'user-unlocked')
        @include('partials.toast-flash', ['type' => 'success', 'message' => 'Đã mở khóa tài khoản '.session('lockedName').'.'])
    @endif
    <style>
        /* SỬA 12/11 — nút Khóa / Mở khóa + dòng hạn khóa ở danh sách */
        .aux-rowbtn--lock { color: #c2410c; }
        .aux-rowbtn--lock:hover:not(:disabled) { color: #9a3412; text-decoration: underline; }
        .aux-rowbtn--lock:disabled { opacity: .45; cursor: not-allowed; }
        .aux-rowbtn--unlock { color: #047857; }
        .aux-rowbtn--unlock:hover { color: #065f46; text-decoration: underline; }
        .aux-lockinfo { display: block; margin-top: 3px; font-size: 11px; font-weight: 600; color: #be123c; white-space: nowrap; }
        .aux-lockinfo + .aux-lockinfo { color: #94a3b8; font-weight: 500; }
    </style>

    {{--
      SỬA 8/10 (khách: "cập nhật lại UI màn người dùng theo source mới, logic giữ nguyên") — dựng lại theo
      AdminUsers.jsx: dải tab vai trò có số đếm, thanh tìm + lọc trạng thái, bảng ô định danh (avatar + tên + email),
      nhãn vai trò, chấm trạng thái, phân trang 10 người/trang. Dữ liệu ($tabs, $users) và route Xem/Thêm/Hàng đợi
      duyệt giáo viên GIỮ NGUYÊN; tìm/lọc/chia trang chạy ngay trên các dòng đã có, không thêm truy vấn hay tham số.
    --}}
    @include('partials.admin-users-ui')

    <x-ws.page-header title="Người dùng" icon="users" subtitle="Quản lý người dùng, vai trò và trạng thái phê duyệt giáo viên (3.3).">
        <x-slot:actions>
            <a href="{{ route('admin.users.create') }}" class="inline-flex min-h-10 shrink-0 items-center justify-center gap-1.5 rounded-xl bg-white px-4 py-2 text-xs font-bold text-blue-700 shadow-sm transition-colors hover:bg-sky-50">+ Thêm người dùng</a>
            <a href="{{ route('admin.teacher-approvals.index') }}" class="inline-flex min-h-10 shrink-0 items-center justify-center gap-1.5 rounded-xl border border-white/35 bg-white/10 px-4 py-2 text-xs font-bold text-white backdrop-blur-sm transition-colors hover:bg-white/20">
                Hàng đợi duyệt giáo viên
            </a>
        </x-slot:actions>
    </x-ws.page-header>

    <section class="acx-panel" style="margin-top:16px" aria-label="Danh sách người dùng">
        <nav class="acx-seg" aria-label="Nhóm người dùng">
            @foreach ($tabs as $t)
                <a href="{{ $t['href'] }}" @if ($t['active'] ?? false) aria-current="page" @endif>{{ $t['label'] }}@isset($t['count'])<span>{{ $t['count'] }}</span>@endisset</a>
            @endforeach
        </nav>

        <div class="acx-toolbar">
            <label class="acx-search">
                <x-lucide name="search" />
                <input type="search" id="auxQuery" aria-label="Tìm người dùng" autocomplete="off" placeholder="Tìm tên hoặc email…">
                <button type="button" class="acx-clear" id="auxClear" aria-label="Xóa tìm kiếm"><x-lucide name="x" class="h-4 w-4" /></button>
            </label>
            <label class="acx-filter">Trạng thái
                <select class="acx-field" id="auxStatus" aria-label="Lọc theo trạng thái">
                    <option value="">Tất cả</option>
                    @foreach ($statusOptions as $o)
                        <option value="{{ $o }}">{{ $o }}</option>
                    @endforeach
                </select>
            </label>
        </div>

        <div class="akx-sub" style="padding-top:0"><span><b id="auxCount">{{ $total }}</b> người dùng</span><span>Mới tạo hiển thị trước</span></div>

        <div class="acx-scroll">
            <table class="acx-table akx-table apx-up">
                <caption class="acx-sr">Danh sách người dùng</caption>
                <thead>
                    <tr>
                        <th scope="col">Người dùng</th>
                        <th scope="col">Vai trò</th>
                        <th scope="col">Trạng thái</th>
                        <th scope="col">Ngày tạo</th>
                        <th scope="col">Thao tác</th>
                    </tr>
                </thead>
                <tbody id="auxBody" data-pg="users" data-unit="người dùng">
                    @foreach ($users as $u)
                        @php
                            // SỬA 12/11 — có khóa đang hiệu lực (kể cả tài khoản bị phạt trước khi có chặn đăng nhập) thì coi là ĐÃ KHÓA:
                            // hiện "Đã khóa" + nút "Mở khóa" thay cho nút "Khóa".
                            $isLockedRow = ! ($u['trashed'] ?? false) && (($u['locked'] ?? false) || ! empty($u['lock']));
                            if ($isLockedRow) { $u['status'] = 'Đã khóa'; $u['tone'] = 'danger'; }
                        @endphp
                        <tr data-pg-item data-search="{{ $u['name'] }} {{ $u['email'] }} {{ implode(' ', $u['roles']) }}" data-status="{{ $u['status'] }}">
                            <td>
                                <div class="aux-who">
                                    <x-ws.avatar :name="$u['name']" size="md" />
                                    <div>
                                        <a href="{{ route('admin.users.show', $u['id']) }}" class="akx-title" data-user-open="{{ $u['id'] }}">{{ $u['name'] }}</a>
                                        <span class="aux-email">{{ $u['email'] }}</span>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="aux-roles">
                                    @foreach ($u['roles'] as $r)
                                        <span class="aux-role {{ $roleClass($r) }}">{{ $r }}</span>
                                    @endforeach
                                </div>
                            </td>
                            <td>
                                <span class="aux-status {{ ($u['tone'] ?? '') === 'warning' ? 'aux-status--warn' : (in_array($u['tone'] ?? '', ['danger', 'error'], true) ? 'aux-status--off' : '') }}">{{ $u['status'] }}</span>
                                @if (! empty($u['lock']))
                                    <span class="aux-lockinfo" title="{{ $u['lock']['reason'] }}">{{ $u['lock']['until'] ? 'Đến '.$u['lock']['until'] : 'Vĩnh viễn' }}</span>
                                    <span class="aux-lockinfo" title="{{ $u['lock']['reason'] }}">{{ \Illuminate\Support\Str::limit($u['lock']['reason'], 28) }}</span>
                                @endif
                            </td>
                            <td><span class="aux-date">{{ $u['created'] }}</span></td>
                            <td>
                                <div class="aux-actions">
                                    <a href="{{ route('admin.users.show', $u['id']) }}" class="akx-lnk" data-user-open="{{ $u['id'] }}">Chi tiết</a>
                                    {{-- SỬA 12/11 — Khóa / Mở khóa ngay trên dòng, mở popup (admin/users/_lock-modal). --}}
                                    @php
                                        $lockPayload = ['id' => $u['id'], 'name' => $u['name'], 'email' => $u['email'], 'avatar' => $u['avatar'] ?? null,
                                            'roles' => $u['roles'], 'tokens' => $u['tokens'] ?? 0, 'province' => $u['province'] ?? null, 'lock' => $u['lock'] ?? null];
                                    @endphp
                                    @unless ($u['trashed'] ?? false)
                                        @if ($isLockedRow)
                                            <button type="button" class="aux-rowbtn aux-rowbtn--unlock" data-user="{{ json_encode($lockPayload) }}"
                                                    onclick="window.dispatchEvent(new CustomEvent('user-unlock', { detail: JSON.parse(this.dataset.user) }))"
                                                    aria-label="Mở khóa {{ $u['name'] }}"><x-lucide name="lock-open" /> Mở khóa</button>
                                        @else
                                            <button type="button" class="aux-rowbtn aux-rowbtn--lock" data-lock-open="{{ $u['id'] }}" data-user="{{ json_encode($lockPayload) }}"
                                                    onclick="window.dispatchEvent(new CustomEvent('user-lock', { detail: JSON.parse(this.dataset.user) }))"
                                                    aria-label="Khóa {{ $u['name'] }}" @disabled($u['is_self'] ?? false) @if ($u['is_self'] ?? false) title="Không thể tự khóa chính mình" @endif><x-lucide name="lock" /> Khóa</button>
                                        @endif
                                    @endunless
                                    @if ($u['trashed'] ?? false)
                                        <button type="button" class="aux-rowbtn aux-rowbtn--restore" data-user-restore="{{ $u['id'] }}" aria-label="Khôi phục {{ $u['name'] }}"><x-lucide name="rotate-ccw" /> Khôi phục</button>
                                    @else
                                        <button type="button" class="aux-rowbtn aux-rowbtn--del" data-user-del="{{ $u['id'] }}" data-name="{{ $u['name'] }}" aria-label="Xóa {{ $u['name'] }}" @disabled($u['is_self'] ?? false) @if ($u['is_self'] ?? false) title="Không thể tự xóa chính mình" @endif><x-lucide name="trash-2" /> Xóa</button>
                                    @endif
                                </div>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
            <div class="akx-empty" id="auxEmpty" style="display:{{ count($users) === 0 ? 'block' : 'none' }}">
                <strong id="auxEmptyTitle">Không có người dùng nào.</strong>
                <span id="auxEmptyHint"></span>
            </div>
        </div>

        <div class="akx-pg" data-pg-nav="users" hidden></div>
        <p class="acx-foot" style="padding-top:12px">Bấm "Chi tiết" để cập nhật thông tin và mật khẩu, phân quyền chức năng và xem lịch sử thay đổi. Người dùng bị xóa được giữ ở tab "Đã xóa" và có thể khôi phục. Bấm "Khóa" để khóa tài khoản (không đăng nhập được, gỡ khỏi bảng xếp hạng).</p>
    </section>

    @include('partials.admin-users-modal')
    @include('admin.users._lock-modal')
@endsection

@push('scripts')
    <script>
        /* Tìm + lọc trạng thái chạy trên các dòng đã có; phân trang 10 người/trang do khối [data-pg] trong partials.admin-content-ui lo.
           Dòng không khớp được gỡ khỏi bộ đếm trang bằng thuộc tính data-pg-item (đổi tên tạm), rồi dựng lại thanh chuyển trang. */
        document.addEventListener('DOMContentLoaded', function () {
            var body = document.getElementById('auxBody');
            if (!body) return;
            var rows = Array.prototype.slice.call(body.querySelectorAll('tr'));
            var q = document.getElementById('auxQuery'), clear = document.getElementById('auxClear');
            var st = document.getElementById('auxStatus');
            var count = document.getElementById('auxCount'), empty = document.getElementById('auxEmpty');
            var title = document.getElementById('auxEmptyTitle'), hint = document.getElementById('auxEmptyHint');
            var total = parseInt(count.textContent, 10) || rows.length;
            var allShown = rows.length === total;
            function norm(s) { return String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/đ/g, 'd'); }
            rows.forEach(function (tr) { tr._s = norm(tr.dataset.search); });
            function apply() {
                var term = norm(q.value).trim(), s = st.value, hits = 0;
                rows.forEach(function (tr) {
                    var ok = (!term || tr._s.indexOf(term) !== -1) && (!s || tr.dataset.status === s);
                    tr.dataset.match = ok ? '1' : '0';
                    if (ok) hits++;
                });
                // Đưa các dòng khớp lên đầu danh sách chia trang bằng cách bật/tắt thuộc tính data-pg-item.
                rows.forEach(function (tr) {
                    if (tr.dataset.match === '1') tr.setAttribute('data-pg-item', ''); else { tr.removeAttribute('data-pg-item'); tr.hidden = true; }
                });
                window.akxRepage && window.akxRepage('users');
                count.textContent = (term || s) ? hits : (allShown ? total : total);
                empty.style.display = hits === 0 ? 'block' : 'none';
                if (hits === 0) {
                    title.textContent = (term || s) ? 'Không tìm thấy người dùng phù hợp' : 'Không có người dùng nào.';
                    hint.textContent = (term || s) ? ' Thử đổi từ khóa hoặc bộ lọc.' : '';
                }
                clear.classList.toggle('is-on', q.value !== '');
            }
            q.addEventListener('input', apply);
            st.addEventListener('change', apply);
            clear.addEventListener('click', function () { q.value = ''; apply(); q.focus(); });
        });
    </script>
@endpush
