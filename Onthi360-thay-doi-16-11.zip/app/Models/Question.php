<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;

use App\Concerns\Auditable;
use App\Enums\ContentStatus;
use App\Enums\OwnerType;
use App\Enums\QuestionType;
use App\Enums\Visibility;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Question extends Model
{
    use HasFactory, Auditable, SoftDeletes;

    /** Đọc bởi App\Concerns\Auditable — lý do khi admin publish/từ chối/lưu trữ câu hỏi (6.2, 10.4). */
    public static ?string $auditReason = null;

    protected $fillable = [
        'bank_id', 'code', 'type', 'title', 'body', 'points', 'grading_config', 'metadata',
        // SỬA 30/9 — độ ưu tiên hiển thị: số càng lớn càng hiện trước, 0 = bình thường.
        // Xem migration add_display_order_to_questions_table.
        'display_order',
        // SỬA 8/9 (3) ("phân loại câu hỏi theo môn") — MÃ môn (App\Support\SubjectCatalog::SUBJECTS,
        // vd "TOAN") + khối lớp 6-12. Xem migration add_subject_grade_to_questions_table.
        'subject', 'grade',
        // SỬA 1/10 (khách: "thêm 1 cái field nữa cho chọn tỉnh thành và năm") — MÃ tỉnh thành
        // (App\Support\ProvinceCatalog, vd "HANOI") + năm của đề. Xem migration
        // add_province_exam_year_to_questions_table.
        'province', 'exam_year',
        // SỬA 10/10 — ô "Nguồn" nhập tay (văn bản tự do), xem migration add_source_name_to_questions_table.
        'source_name',
        'owner_type', 'owner_id', 'visibility', 'status', 'version', 'parent_version_id', 'created_by',
        // SỬA 31/8 ("ZIP bài tập" gắn vào sản phẩm) — product_id khác null nghĩa là câu hỏi
        // này là bài tập riêng của 1 sản phẩm, không thuộc Kho câu hỏi dùng chung. Mọi nơi lấy
        // câu hỏi CHUNG phải whereNull('product_id'), xem QuestionRepository.
        'product_id',
        // SỬA 4/9 (khách yêu cầu "Chương/Phần/Đề") — liên kết TÙY CHỌN tới 1 materials.id
        // (type=chapter) CÙNG product_id với câu hỏi này, để biết bài tập thuộc chương nào
        // (Sách)/phần nào (Chuyên đề)/đề nào (Bộ đề) — xem migration
        // add_material_id_to_questions_table + ContentService::productExerciseSave()/
        // productExerciseStoreManual().
        'material_id',
    ];

    protected $casts = [
        'type' => QuestionType::class,
        'owner_type' => OwnerType::class,
        'visibility' => Visibility::class,
        'status' => ContentStatus::class,
        'grading_config' => 'array',
        'metadata' => 'array',
    ];

    public function bank(): BelongsTo
    {
        return $this->belongsTo(QuestionBank::class, 'bank_id');
    }

    /** SỬA 8/9 (3) — nhãn môn để hiển thị ("TOAN" -> "Toán"); chưa gán/mã lạ -> "Chưa phân loại". */
    public function subjectLabel(): string
    {
        return \App\Support\SubjectCatalog::label($this->subject) ?? 'Chưa phân loại';
    }

    /**
     * SỬA 3/10 (khách: "chỗ chọn khối lớp thì cho chọn nhiều nha") — danh sách khối của câu hỏi.
     *
     * Cột questions.grade giờ chứa các khối ngăn bằng dấu phẩy ("6,7,8"), cùng cách
     * courses.grade đang lưu. Câu cũ chỉ có một số thì ra đúng một phần tử.
     *
     * @return list<string>
     */
    public function gradeList(): array
    {
        return collect(explode(',', (string) $this->grade))
            ->map(fn ($g) => trim($g))
            ->filter(fn ($g) => $g !== '')
            ->unique()
            ->values()
            ->all();
    }

    /** SỬA 8/9 (3) — nhãn khối lớp để hiển thị ("6,7" -> "Lớp 6, 7"); chưa gán -> "—". */
    public function gradeLabel(): string
    {
        $grades = $this->gradeList();

        return $grades === [] ? '—' : 'Lớp '.implode(', ', $grades);
    }

    /** SỬA 1/10 — nhãn tỉnh thành ("HANOI" -> "Hà Nội"); chưa gán hoặc mã lạ -> "—". */
    public function provinceLabel(): string
    {
        return \App\Support\ProvinceCatalog::label($this->province) ?? '—';
    }

    /** SỬA 1/10 — nhãn năm của đề; chưa gán -> "—". */
    public function examYearLabel(): string
    {
        return $this->exam_year !== null ? (string) $this->exam_year : '—';
    }

    /** SỬA 31/8 — sản phẩm sở hữu câu hỏi này (khi đây là "bài tập đính kèm sản phẩm"). */
    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }

    /** SỬA 4/9 — chương/phần/đề (materials.type=chapter) mà bài tập này thuộc về, xem $fillable ở trên. */
    public function chapter(): BelongsTo
    {
        return $this->belongsTo(Material::class, 'material_id');
    }

    public function owner(): BelongsTo
    {
        return $this->belongsTo(User::class, 'owner_id');
    }

    /**
     * SỬA 4/10 (khách: "khi thêm câu hỏi thì sẽ tự động lưu tác giả tên account của mình… ngoài
     * luyện tập public thêm cột tác giả đổ ra nữa nha") — NGƯỜI SOẠN câu hỏi.
     *
     * Cột created_by vốn đã được ghi sẵn từ trước ở cả 2 lối tạo (Admin\ContentService::
     * questionStore() và Teacher\QuestionService), nên không phải thêm gì ở khâu lưu — chỉ
     * thiếu quan hệ này để đọc ra tên.
     *
     * KHÁC owner(): owner_id là CHỦ SỞ HỮU kho (Kho chung hay kho riêng của giáo viên nào),
     * created_by là NGƯỜI BẤM NÚT TẠO. Một câu do admin soạn rồi đẩy vào Kho chung có owner là
     * Kho chung nhưng tác giả vẫn là admin đó.
     */
    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function parentVersion(): BelongsTo
    {
        return $this->belongsTo(Question::class, 'parent_version_id');
    }

    public function assessmentItems(): HasMany
    {
        return $this->hasMany(AssessmentItem::class);
    }

    /** SỬA 19/8 (Giai đoạn 6) — chuyên đề/tag gắn cho câu hỏi, xem App\Models\Tag. */
    public function tags(): BelongsToMany
    {
        $relation = $this->belongsToMany(Tag::class, 'question_tag');
        // SỬA 16/11 — kèm cờ "tag chính" (question_tag.is_primary) khi đã chạy migration 2025_01_01_001500.
        if (self::tagPrimaryReady()) {
            $relation->withPivot('is_primary');
        }

        return $relation;
    }

    /** SỬA 16/11 — bảng nối đã có cột is_primary chưa (kiểm 1 lần mỗi request). */
    public static function tagPrimaryReady(): bool
    {
        static $ready = null;
        if ($ready === null) {
            try {
                $ready = \Illuminate\Support\Facades\Schema::hasColumn('question_tag', 'is_primary');
            } catch (\Throwable $e) {
                $ready = false;
            }
        }

        return $ready;
    }

    /**
     * SỬA 16/11 — danh sách tag đã xếp: TAG CHÍNH đứng đầu, còn lại giữ thứ tự cũ. Nơi hiển thị lấy phần tử đầu làm chuyên đề
     * chính (chip to), các phần tử sau là chuyên đề phụ (chip nhỏ).
     */
    public function orderedTags(): \Illuminate\Support\Collection
    {
        return $this->tags
            ->values()
            ->sortBy(fn ($t, $i) => [(int) ! ($t->pivot->is_primary ?? false), $i])
            ->values();
    }

    /**
     * Điều kiện tối thiểu để publish theo loại câu (6.2). Đây chỉ là kiểm tra cấu trúc dữ liệu;
     * quy tắc đầy đủ (không sửa âm thầm câu đã có người làm, v.v.) nằm ở QuestionPublishGuard.
     */
    public function hasMinimumGradingConfig(): bool
    {
        $config = $this->grading_config ?? [];

        return match ($this->type) {
            QuestionType::Coding => filled($config['test_cases'] ?? null)
                && filled($config['time_limit_ms'] ?? null)
                && filled($config['memory_limit_mb'] ?? null),
            QuestionType::Mcq => filled($config['correct_options'] ?? null) && $this->points > 0,
            QuestionType::FillBlank => filled($config['accepted_answers'] ?? null) && $this->points > 0,
            // SỬA 31/8 (2) — câu Composite CHỈ tạo được qua nhập ZIP (không có form nhập tay
            // tương ứng, xem ContentService::questionUpdate()/questionCreateNewVersion() —
            // grading_config giữ NGUYÊN từ lúc nhập, không qua buildGradingConfig()) — điều
            // kiện tối thiểu ở đây chỉ là có ít nhất 1 phần con và có điểm, không kiểm tra sâu
            // từng phần (gói ZIP đã tự đảm bảo cấu trúc từng phần lúc nhập).
            QuestionType::Composite => filled($config['parts'] ?? null) && $this->points > 0,
        };
    }

    /**
     * SỬA 31/8 (2) — mô tả ngắn gọn cấu hình chấm, dùng ở mọi nơi hiển thị danh sách "Bài tập"
     * (LibraryService::exercisesFor(), ContentService::productExercisesFor()) THAY cho
     * "X test case" cứng cho mọi loại như trước — trước đây chỉ đúng với câu Lập trình, giờ
     * bài tập có thể là bất kỳ dạng nào trong 4 dạng ZIP hỗ trợ (xem ContentService::
     * SUPPORTED_ZIP_CONTENT_TYPES).
     */
    /**
     * SỬA 28/10 (khách: "thêm cột Input/Output để biết bài nào đang đọc từ tệp, bài nào chưa để còn chỉnh") — cách vào/ra của
     * câu Lập trình: file = true khi đề khai tên tệp vào hoặc ra (grading_config.file_io), false = bàn phím / màn hình.
     * null = không phải câu Lập trình (không có khái niệm vào/ra).
     *
     * @return array{file: bool, input: ?string, output: ?string}|null
     */
    public function ioInfo(): ?array
    {
        if ($this->type !== QuestionType::Coding) {
            return null;
        }
        // SỬA 28/10 — danh sách nạp bằng scopeListColumns() không kéo cả grading_config (rất nặng: chứa test), chỉ lấy sẵn
        // 2 tên tệp vào/ra (io_in / io_out). 'null' = giá trị JSON null.
        if (array_key_exists('io_in', $this->attributes) || array_key_exists('io_out', $this->attributes)) {
            $clean = fn ($v) => $v === null || $v === '' || $v === 'null' ? null : $v;
            $names = \App\Services\CodeJudgingService::fileIoNames(['input' => $clean($this->attributes['io_in'] ?? null), 'output' => $clean($this->attributes['io_out'] ?? null)]);
        } else {
            $names = \App\Services\CodeJudgingService::fileIoNames(($this->grading_config ?? [])['file_io'] ?? null);
        }

        return ['file' => $names !== null, 'input' => $names['input'] ?? null, 'output' => $names['output'] ?? null];
    }

    /**
     * SỬA 28/10 (lỗi "Allowed memory size of 536870912 bytes exhausted" ở trang Luyện tập) — grading_config chứa cả dữ liệu
     * test nên có câu nặng hàng chục MB; nạp cả nghìn câu đầy đủ là tràn bộ nhớ PHP. Các trang DANH SÁCH dùng scope này: chỉ
     * lấy cột nhẹ + vài giá trị lẻ trích thẳng từ grading_config bằng SQL (giới hạn thời gian / bộ nhớ, tên tệp vào/ra).
     * KHÔNG dùng cho chỗ cần chấm / sửa bài (những chỗ đó nạp đủ cột như cũ).
     */
    public function scopeListColumns($query)
    {
        return $query->select([
            'questions.id', 'questions.code', 'questions.title', 'questions.type', 'questions.points', 'questions.metadata',
            'questions.status', 'questions.subject', 'questions.grade', 'questions.province', 'questions.exam_year',
            'questions.source_name', 'questions.created_by', 'questions.product_id', 'questions.material_id',
            'questions.owner_type', 'questions.owner_id', 'questions.display_order', 'questions.created_at', 'questions.updated_at',
        ])->addSelect([
            'questions.grading_config->time_limit_ms as cfg_time_ms',
            'questions.grading_config->memory_limit_mb as cfg_memory_mb',
            'questions.grading_config->limits->time_ms as cfg_limits_time_ms',
            'questions.grading_config->limits->memory_mb as cfg_limits_memory_mb',
            'questions.grading_config->file_io->input as io_in',
            'questions.grading_config->file_io->output as io_out',
        ]);
    }

    /**
     * SỬA 29/10 (lỗi 500 "Allowed memory size" khi mở bộ đề) — kèm số test / phương án / đáp án / phần đếm thẳng bằng SQL, để
     * exerciseSummaryLabel() dùng được mà KHÔNG kéo cả grading_config. Gọi SAU listColumns().
     */
    public function scopeWithSummaryCounts($query)
    {
        $fn = $query->getConnection()->getDriverName() === 'sqlite' ? 'json_array_length' : 'JSON_LENGTH';
        foreach (['test_cases' => 'cnt_tests', 'options' => 'cnt_options', 'accepted_answers' => 'cnt_answers', 'parts' => 'cnt_parts'] as $key => $alias) {
            $query->selectRaw($fn.'(questions.grading_config, \'$.'.$key.'\') as '.$alias);
        }

        return $query;
    }

    /**
     * SỬA 28/10 (lỗi MySQL "1038 Out of sort memory") — KHÔNG được ORDER BY trên truy vấn listColumns(): MySQL phải đọc cả
     * grading_config (vài chục MB) của từng dòng vào bộ nhớ sắp xếp để trích giá trị → tràn. Cách làm: sắp xếp + lọc bằng
     * truy vấn CHỈ LẤY id (nhẹ), rồi gọi hàm này nạp các dòng nhẹ theo đúng thứ tự id đó (không ORDER BY).
     *
     * @param  list<int>  $ids
     * @param  array<int|string, mixed>  $with
     * @return \Illuminate\Support\Collection<int, static>
     */
    public static function listByIds(array $ids, array $with = []): \Illuminate\Support\Collection
    {
        if ($ids === []) {
            return collect();
        }
        $pos = array_flip(array_values(array_map('intval', $ids)));
        $rows = collect();
        foreach (array_chunk(array_keys($pos), 1000) as $chunk) {
            $rows = $rows->concat(static::query()->listColumns()->whereIn('questions.id', $chunk)->with($with)->get());
        }

        return $rows->sortBy(fn ($q) => $pos[(int) $q->id] ?? PHP_INT_MAX)->values();
    }

    public function exerciseSummaryLabel(): string
    {
        // SỬA 29/10 — nạp bằng listColumns()->withSummaryCounts(): đã có sẵn số đếm, không có grading_config.
        if (array_key_exists('cnt_tests', $this->attributes)) {
            $n = fn (string $k) => (int) ($this->attributes[$k] ?? 0);

            return match ($this->type) {
                QuestionType::Coding => $n('cnt_tests').' test case',
                QuestionType::Mcq => $n('cnt_options').' phương án',
                QuestionType::FillBlank => $n('cnt_answers').' đáp án chấp nhận',
                QuestionType::Composite => $n('cnt_parts').' phần',
            };
        }

        $config = $this->grading_config ?? [];

        return match ($this->type) {
            QuestionType::Coding => count($config['test_cases'] ?? []).' test case',
            QuestionType::Mcq => count($config['options'] ?? []).' phương án',
            QuestionType::FillBlank => count($config['accepted_answers'] ?? []).' đáp án chấp nhận',
            QuestionType::Composite => count($config['parts'] ?? []).' phần',
        };
    }

    /**
     * SỬA 31/8 (2) — tìm 1 asset (audio/ảnh...) đính kèm theo id, đọc từ metadata.assets (xem
     * ContentService::storeZipAssets()) — dùng ở route phục vụ tệp cho học sinh nghe/xem lúc
     * "Làm bài" (Student\PracticeByQuestionController::asset()). null nếu không có asset nào
     * khớp id (asset id sai, hoặc câu hỏi này không có asset nào).
     *
     * @return array{path:string, filename:string, kind:string}|null
     */
    public function findAsset(string $assetId): ?array
    {
        foreach (($this->metadata['assets'] ?? []) as $asset) {
            if (($asset['id'] ?? null) === $assetId && isset($asset['path'])) {
                return [
                    'path' => $asset['path'],
                    'filename' => $asset['filename'] ?? basename($asset['path']),
                    'kind' => $asset['kind'] ?? 'file',
                ];
            }
        }

        return null;
    }

    /**
     * SỬA (nối "Xem đề bài" PDF cho học sinh) — 1 trong 3 tệp đính kèm CỐ ĐỊNH của câu hỏi
     * nhập từ gói ZIP (statement.pdf/solution.pdf/reference, xem App\Services\Admin\
     * ContentService::parseZipQuestionPackage()) — lưu trong metadata.attachments, KHÁC hẳn
     * metadata.assets (audio/ảnh... cần để trả lời, xem findAsset() ở trên). Dùng chung ở cả
     * Admin/Teacher (trang Sửa câu hỏi, đã có sẵn từ trước — xem Admin\ContentService::
     * questionAttachmentInfo()/Teacher\QuestionService::attachmentInfo(), 2 hàm đó KHÔNG đổi,
     * chỉ thêm hàm này để Student\PracticeByQuestionController::statement() dùng lại đúng 1
     * chỗ đọc dữ liệu, không chép lại logic lần 3) LẪN học sinh lúc luyện tập (statement()
     * CHỈ cho phép kind='statement', KHÔNG bao giờ lộ 'solution'/'reference' ra cho học sinh
     * — xem route/controller). null nếu câu hỏi này không có đính kèm loại đó.
     *
     * @return array{path:string, filename:string}|null
     */
    public function attachmentInfo(string $kind): ?array
    {
        $path = $this->metadata['attachments'][$kind]['path'] ?? null;

        if ($path === null) {
            return null;
        }

        return [
            'path' => $path,
            'filename' => $this->metadata['attachments'][$kind]['filename'] ?? basename($path),
        ];
    }
}
