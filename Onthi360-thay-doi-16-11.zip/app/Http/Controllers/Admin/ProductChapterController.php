<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Material;
use App\Models\Product;
use App\Services\Admin\ContentService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

/**
 * SỬA 4/9 (khách yêu cầu "Chương/Phần/Đề" — "nếu loại sách thì thêm chương, loại chuyên đề
 * là thêm phần, loại bộ đề thì thêm đề, field chỉ cần title") — CRUD gọn cho mục lục chương/
 * phần/đề của 1 sản phẩm, tái dùng Material (type=chapter) có sẵn qua ContentService::
 * productChapter*(). CHỈ Admin/Super Admin quản lý (cùng nhóm middleware role:admin,
 * super_admin với ProductController/ProductExerciseController, xem routes/web.php).
 */
class ProductChapterController extends Controller
{
    public function __construct(private ContentService $contentService) {}

    /**
     * SỬA 12/11 (khách: "thêm chương / sửa chương load lâu quá") — gọi bằng fetch (Accept: JSON) thì KHÔNG chuyển hướng về trang
     * tài liệu (trang đó nặng vì nạp cả danh sách bài tập) mà trả lại riêng khối danh sách chương đã dựng sẵn để thay tại chỗ.
     */
    private function respond(Request $request, Product $product, string $status, string $message, string $anchor = ''): RedirectResponse|JsonResponse
    {
        if (! $request->expectsJson()) {
            return redirect()->to(route('admin.products.show', $product->id).$anchor)->with('status', $status);
        }

        $chapters = $this->contentService->productChaptersFor($product);

        return response()->json([
            'ok' => true,
            'message' => $message,
            // SỬA 12/11 — thời gian MÁY CHỦ xử lý (tính từ lúc PHP nhận xong request), để biết chậm do mạng tải lên hay do máy chủ.
            'serverMs' => (int) round((microtime(true) - (defined('LARAVEL_START') ? LARAVEL_START : ($_SERVER['REQUEST_TIME_FLOAT'] ?? microtime(true)))) * 1000),
            'count' => count($chapters),
            'html' => view('admin.products.partials.chapters-list', [
                'product' => $product,
                'chapters' => $chapters,
                'chapterLabel' => $product->chapterLabel(),
            ])->render(),
        ]);
    }

    private function fail(Request $request, ValidationException $e): RedirectResponse|JsonResponse
    {
        if ($request->expectsJson()) {
            return response()->json(['ok' => false, 'message' => collect($e->errors())->flatten()->first() ?: 'Không lưu được.', 'errors' => $e->errors()], 422);
        }

        return back()->withErrors($e->errors())->withInput();
    }

    /** Chặn admin sửa/xoá "nhầm" chương của sản phẩm KHÁC qua việc tự sửa URL — cùng nguyên tắc với ProductExerciseController::assertBelongsToProduct(). */
    private function assertBelongsToProduct(Product $product, Material $chapter): void
    {
        abort_unless($chapter->product_id === $product->id && $chapter->type === 'chapter', 404);
    }

    /**
     * SỬA 29/9 (khách chốt: "bỏ file pdf sách đi, chỗ chương mỗi chương là thêm từng file pdf")
     * — thêm ô tệp PDF cho chính chương/phần/đề. Vẫn TÙY CHỌN: tạo mục lục rỗng rồi tải tệp
     * sau vẫn được. Giới hạn dung lượng dùng chung ContentService::maxPdfKb() như mọi ô PDF khác.
     */
    public function store(Request $request, Product $product): RedirectResponse|JsonResponse
    {
        $data = $request->validate([
            'title' => ['required', 'string', 'max:255'],
            'order' => ['nullable', 'integer', 'min:0'],
            'pdf' => ['nullable', 'file', 'mimes:pdf', 'max:'.ContentService::maxPdfKb()],
        ], [], ['pdf' => 'Tệp PDF nội dung']);

        try {
            $this->contentService->productChapterStore($product, $data);
        } catch (ValidationException $e) {
            return $this->fail($request, $e);
        }

        return $this->respond($request, $product, 'chapter-created', 'Đã thêm "'.$data['title'].'".');
    }

    public function update(Request $request, Product $product, Material $chapter): RedirectResponse|JsonResponse
    {
        $this->assertBelongsToProduct($product, $chapter);

        $data = $request->validate([
            'title' => ['required', 'string', 'max:255'],
            'order' => ['nullable', 'integer', 'min:0'],
            // SỬA 29/9 — thay tệp PDF của chương, hoặc tích 'remove_pdf' để bỏ tệp hiện có.
            'pdf' => ['nullable', 'file', 'mimes:pdf', 'max:'.ContentService::maxPdfKb()],
            'remove_pdf' => ['nullable', 'boolean'],
        ], [], ['pdf' => 'Tệp PDF nội dung']);

        try {
            $this->contentService->productChapterUpdate($chapter, $data);
        } catch (ValidationException $e) {
            return $this->fail($request, $e);
        }

        return $this->respond($request, $product, 'chapter-updated', 'Đã lưu "'.$data['title'].'".');
    }

    /** SỬA 15/10 — nút ↑ / ↓ ở danh sách chương: đổi chỗ với chương liền trên/dưới. */
    public function move(Request $request, Product $product, Material $chapter): RedirectResponse|JsonResponse
    {
        $this->assertBelongsToProduct($product, $chapter);
        $data = $request->validate(['direction' => ['required', 'in:up,down']]);

        $this->contentService->productChapterMove($chapter, $data['direction']);

        return $this->respond($request, $product, 'chapter-moved', 'Đã đổi thứ tự.', '#chapters');
    }

    public function destroy(Request $request, Product $product, Material $chapter): RedirectResponse|JsonResponse
    {
        $this->assertBelongsToProduct($product, $chapter);

        try {
            $this->contentService->productChapterDestroy($chapter);
        } catch (ValidationException $e) {
            return $this->fail($request, $e);
        }

        return $this->respond($request, $product, 'chapter-deleted', 'Đã xoá.');
    }
}
