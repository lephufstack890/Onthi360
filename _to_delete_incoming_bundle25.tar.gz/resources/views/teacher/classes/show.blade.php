{{--
  Route: teacher.classes.show | Frame: TEA-02 (chi tiết) + TEA-06 (học liệu)
  Spec: 8.2/8.3 (gắn học liệu, lộ trình mở theo chương/mục/mã bài) +
  7.2 (quyền dạy đa lớp — nhãn "Dùng được ở mọi lớp phụ trách đến DD/MM/YYYY").
  TODO controller: truyền $classRoom thật; tab "materials" cần
  App\Services\AccessGateService/TeacherAttachMaterialAction để biết học
  liệu nào giáo viên còn quyền dạy.
--}}
@extends('layouts.teacher')

@section('title', 'Chi tiết lớp')
@section('page-title', 'Chi tiết lớp')

@section('content')
    {{-- Dữ liệu thật do App\Http\Controllers\Teacher\ClassRoomController truyền vào. --}}
    @php
        $tab = $tab ?? 'overview';
        $materials = $materials ?? [];
        $members = $members ?? collect();
        $studentsCount = $studentsCount ?? 0;
        $courseTitle = $classRoom->course->title ?? '';
        $className = $classRoom->name ?? '';
        $nextSessionLabel = isset($nextSession) && $nextSession ? 'Buổi tới: '.$nextSession->starts_at->format('d/m H:i') : 'Chưa có buổi học sắp tới';
        $ratingAverage = $ratingSummary->avg_rating ?? 0;
        $ratingCount = $ratingSummary->review_count ?? 0;
    @endphp

    <a href="{{ route('teacher.classes.index') }}" class="text-sm text-slate-500 mb-4 inline-flex items-center gap-1 hover:text-rose-600">‹ Quay lại Lớp học</a>

    @if (session('status') === 'class-created')
        @include('partials.toast-flash', ['type' => 'success', 'message' => 'Đã tạo lớp thành công — bạn là giáo viên chính của lớp này.'])
    @endif

    <div class="rounded-3xl bg-gradient-to-br from-sky-50 via-white to-emerald-50 border border-slate-200 p-6 lg:p-8 mb-6">
        <div class="flex flex-wrap items-start justify-between gap-4">
            <div class="flex items-start gap-4">
                <div class="w-14 h-14 rounded-2xl bg-white flex items-center justify-center text-3xl shrink-0 shadow-sm">🏫</div>
                <div>
                    <p class="text-xs font-medium text-sky-600 uppercase tracking-wide">{{ $courseTitle }}</p>
                    <h1 class="text-xl lg:text-2xl font-semibold text-slate-800 mt-1">{{ $className }}</h1>
                    <p class="text-sm text-slate-500 mt-1">👥 {{ $studentsCount }} học sinh · 🗓 {{ $nextSessionLabel }}</p>
                </div>
            </div>
            <div class="w-40">
                <x-progress-bar :percent="$completion ?? 0" label="Hoàn thành chung (theo buổi học)" tone="info" />
                @if (($completionTotalSessions ?? 0) > 0)
                    <p class="text-[11px] text-slate-400 mt-1">{{ $completionEndedSessions }}/{{ $completionTotalSessions }} buổi đã học</p>
                @endif
            </div>
        </div>
    </div>

    <x-tabs :tabs="$tabsData" />

    @if ($tab === 'materials')
        @php $attachableMaterials = $attachableMaterials ?? []; @endphp

        @if (session('status') === 'material-attached')
            @include('partials.toast-flash', ['type' => 'success', 'message' => 'Đã thêm học liệu vào lớp.'])
        @elseif (session('status') === 'material-detached')
            @include('partials.toast-flash', ['type' => 'success', 'message' => 'Đã gỡ học liệu — lịch sử bài làm cũ vẫn giữ nguyên (8.2).'])
        @endif
        @if ($errors->any())
            @include('partials.toast-flash', ['type' => 'error', 'message' => implode(' ', $errors->all())])
        @endif

        <div class="space-y-3">
            @forelse ($materials as $m)
                <div class="bg-white rounded-2xl border border-slate-200 p-4 flex items-center justify-between flex-wrap gap-3">
                    <div class="flex items-center gap-3">
                        <x-icon-tile emoji="📚" tone="sky" />
                        <div>
                            <p class="font-medium text-slate-700">{{ $m['title'] }}</p>
                            <p class="text-xs mt-1"><x-status-badge :tone="$m['tone']">{{ $m['scope'] }}</x-status-badge></p>
                        </div>
                    </div>
                    <div class="flex items-center gap-2 text-sm">
                        <x-status-badge tone="success">{{ $m['linkedStatus'] }}</x-status-badge>
                        <form method="POST" action="{{ route('teacher.classes.materials.detach', ['class' => $classRoom->id, 'classMaterial' => $m['id']]) }}" class="inline">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="text-rose-500">Gỡ</button>
                        </form>
                    </div>
                </div>
            @empty
                <x-empty-state title="Lớp chưa gắn học liệu nào" />
            @endforelse

            @if (empty($attachableMaterials))
                <div class="rounded-2xl border-2 border-dashed border-slate-200 text-slate-400 text-sm py-4 text-center">
                    Không có học liệu nào bạn còn quyền dạy để thêm — quyền dạy (teacher_teaching) đã hết hạn hoặc chưa được cấp (7.2).
                </div>
            @else
                <div class="rounded-2xl border-2 border-dashed border-slate-200 p-4">
                    <p class="text-sm text-slate-600 mb-3">+ Thêm học liệu vào lớp (chỉ hiện học liệu bạn còn quyền dạy còn hạn, 8.2):</p>
                    <div class="space-y-2">
                        @foreach ($attachableMaterials as $am)
                            <form method="POST" action="{{ route('teacher.classes.materials.attach', $classRoom->id) }}" class="flex items-center justify-between gap-3 bg-slate-50 rounded-lg px-3 py-2">
                                @csrf
                                <input type="hidden" name="material_id" value="{{ $am['id'] }}">
                                <div class="min-w-0">
                                    <p class="text-sm text-slate-700 truncate">{{ $am['title'] }}</p>
                                    <p class="text-xs text-slate-400">{{ $am['product'] }} · Dùng được ở mọi lớp phụ trách đến {{ $am['expiresAtLabel'] }}</p>
                                </div>
                                <button type="submit" class="px-3 py-1.5 rounded-lg bg-rose-600 text-white text-xs font-medium shrink-0">Thêm vào lớp</button>
                            </form>
                        @endforeach
                    </div>
                </div>
            @endif
        </div>
    @elseif ($tab === 'schedule')
        @php $sessions = $sessions ?? []; @endphp

        @if (session('status') === 'session-created')
            @include('partials.toast-flash', ['type' => 'success', 'message' => 'Đã tạo buổi học mới.'])
        @endif
        @if ($errors->any())
            @include('partials.toast-flash', ['type' => 'error', 'message' => implode(' ', $errors->all())])
        @endif

        <div class="bg-white rounded-2xl border border-slate-200 p-5 mb-4">
            <p class="text-sm font-medium text-slate-600 mb-3">+ Tạo buổi học mới</p>
            <form method="POST" action="{{ route('teacher.schedule.store') }}" x-data="{ startsDate: '{{ old('starts_date', '') }}', endsDate: '{{ old('ends_date', '') }}' }" class="space-y-4">
                @csrf
                <input type="hidden" name="class_room_id" value="{{ $classRoom->id }}">
                <input type="hidden" name="back_to_class" value="1">

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                        <label class="block text-xs font-medium text-slate-500 mb-1" for="topic">Chủ đề buổi học</label>
                        <input id="topic" type="text" name="topic" maxlength="255" value="{{ old('topic') }}" placeholder="Ví dụ: Ôn tập chương 3" class="w-full rounded-lg border border-slate-200 text-sm p-2.5">
                    </div>
                    <div>
                        <label class="block text-xs font-medium text-slate-500 mb-1" for="location">Địa điểm/link</label>
                        <input id="location" type="text" name="location" maxlength="255" value="{{ old('location') }}" placeholder="Phòng học hoặc link online" class="w-full rounded-lg border border-slate-200 text-sm p-2.5">
                    </div>
                </div>

                @include('partials.session-datetime-fields')

                <div>
                    <button type="submit" class="px-4 py-2 rounded-lg bg-rose-600 text-white text-sm font-medium">Tạo buổi học</button>
                </div>
            </form>
        </div>

        <x-data-table :columns="['Thời gian (bắt đầu - kết thúc)', 'Chủ đề', 'Địa điểm', 'Trạng thái', 'Điểm danh', '']">
            @forelse ($sessions as $s)
                <tr class="hover:bg-slate-50">
                    <td class="px-4 py-3 text-slate-700">{{ $s['timeRangeLabel'] }}</td>
                    <td class="px-4 py-3 text-slate-600">{{ $s['topic'] ?? '—' }}</td>
                    <td class="px-4 py-3 text-slate-400">{{ $s['location'] ?? '—' }}</td>
                    <td class="px-4 py-3"><x-status-badge :tone="$s['timeStatusTone']">{{ $s['timeStatusLabel'] }}</x-status-badge></td>
                    <td class="px-4 py-3"><x-status-badge :tone="$s['attendanceTaken'] ? 'success' : 'warning'">{{ $s['attendanceSummary'] }}</x-status-badge></td>
                    <td class="px-4 py-3 text-right"><a href="{{ route('teacher.schedule.attendance', $s['id']) }}" class="text-rose-600 font-medium">Điểm danh</a></td>
                </tr>
            @empty
                <tr><td colspan="6" class="px-4 py-6 text-center text-slate-400">Lớp chưa có buổi học nào — tạo buổi học đầu tiên ở trên.</td></tr>
            @endforelse
        </x-data-table>
    @elseif ($tab === 'assign')
        @php $assignments = $assignments ?? []; @endphp

        <div class="bg-white rounded-2xl border border-slate-200 p-5 mb-4 flex items-center justify-between flex-wrap gap-3">
            <p class="text-sm text-slate-500">Giao đề dùng cho kiểm tra có thời điểm mở-đóng, hạn nộp riêng (8.4). Cũng có thể giao đề có sẵn từ trang <a href="{{ route('teacher.assessments.index') }}" class="text-rose-600 font-medium">Bài tập & Đề</a>.</p>
            <a href="{{ route('teacher.assessments.create') }}" class="px-4 py-2 rounded-lg bg-rose-600 text-white text-sm font-medium shrink-0">+ Tạo bài giao đánh giá mới</a>
        </div>

        <x-data-table :columns="['Tên đề', 'Mở lúc', 'Đóng lúc', 'Trạng thái', '']">
            @forelse ($assignments as $ag)
                <tr class="hover:bg-slate-50">
                    <td class="px-4 py-3 font-medium text-slate-700">
                        {{ $ag['title'] }}
                        @if ($ag['instructions'])
                            <p class="text-xs text-slate-400 font-normal mt-0.5">{{ $ag['instructions'] }}</p>
                        @endif
                    </td>
                    <td class="px-4 py-3 text-slate-500">{{ $ag['opensAtLabel'] }}</td>
                    <td class="px-4 py-3 text-slate-500">{{ $ag['closesAtLabel'] }}</td>
                    <td class="px-4 py-3"><x-status-badge :tone="$ag['statusTone']">{{ $ag['statusLabel'] }}</x-status-badge></td>
                    <td class="px-4 py-3 text-right"><a href="{{ route('teacher.results.index', ['class' => $classRoom->id, 'assessment' => $ag['id']]) }}" class="text-rose-600 font-medium">Xem kết quả</a></td>
                </tr>
            @empty
                <tr><td colspan="5" class="px-4 py-6 text-center text-slate-400">Lớp chưa có đề nào được giao — bấm "+ Tạo bài giao đánh giá mới" để bắt đầu.</td></tr>
            @endforelse
        </x-data-table>
    @elseif ($tab === 'results')
        <div class="bg-white rounded-2xl border border-slate-200 p-6 flex items-start gap-4">
            <x-icon-tile emoji="📈" tone="emerald" />
            <a href="{{ route('teacher.results.index') }}" class="text-sm text-rose-600 font-medium self-center">Xem kết quả chi tiết theo lớp này ›</a>
        </div>
    @elseif ($tab === 'members')
        {{-- Mã lớp (ClassRoom::code) — học sinh tự tham gia bằng mã này (student.classes.join),
             chia sẻ ngoài hệ thống (Zalo/nhóm lớp...) như đã mô tả ở hướng dẫn sử dụng công khai. --}}
        <div class="rounded-2xl bg-rose-50/60 border border-rose-100 p-5 mb-4 flex items-center justify-between gap-4 flex-wrap">
            <div>
                <p class="text-sm font-medium text-slate-700">Mã lớp để học sinh tự tham gia</p>
                <p class="text-xs text-slate-400 mt-0.5">Chia sẻ mã này cho học sinh — các em tự nhập ở trang Khóa học của tôi để vào lớp.</p>
            </div>
            <span class="text-base font-mono font-semibold px-3 py-1.5 rounded-lg bg-white border border-rose-200 text-rose-600 shrink-0">{{ $classRoom->code }}</span>
        </div>
        <div class="bg-white rounded-2xl border border-slate-200 p-5">
            <p class="text-xs text-slate-400 mb-3">{{ $members->count() }} học sinh</p>
            <div class="space-y-2 max-h-96 overflow-y-auto">
                @foreach ($members as $m)
                    <div class="flex items-center gap-3 py-1.5">
                        <img src="https://ui-avatars.com/api/?name={{ urlencode($m->name) }}&background=e0f2fe&color=0369a1&size=64&bold=true"
                             alt="{{ $m->name }}" class="w-8 h-8 rounded-full shrink-0">
                        <p class="text-sm text-slate-600">{{ $m->name }}</p>
                    </div>
                @endforeach
            </div>
        </div>
    @else
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div class="bg-white rounded-2xl border border-slate-200 p-5 flex items-start gap-3">
                <x-icon-tile emoji="⭐" tone="amber" />
                <div>
                    <h3 class="font-medium text-slate-700 mb-2">Rating summary nội bộ</h3>
                    <x-rating-summary :average="$ratingAverage" :count="$ratingCount" />
                </div>
            </div>
            <div class="bg-white rounded-2xl border border-slate-200 p-5 flex items-start gap-3">
                <x-icon-tile emoji="🗓️" tone="sky" />
                <div>
                    <h3 class="font-medium text-slate-700 mb-2">Buổi học gần nhất</h3>
                    <p class="text-sm text-slate-500">{{ $nextSessionLabel }}</p>
                </div>
            </div>
        </div>
    @endif
@endsection
