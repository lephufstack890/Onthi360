#include <bits/stdc++.h>

using namespace std;

int main()
{
    if (fopen("APLUSBCB.INP", "r"))
    {
        freopen("APLUSBCB.INP", "r", stdin);
        freopen("APLUSBCB.OUT", "w", stdout);
    }

    long long A, B;
    cin >> A >> B;

    long long sum = A + B;

    cout << sum << endl;
    return 0;
}
