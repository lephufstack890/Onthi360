#include <bits/stdc++.h>
using namespace std;
int main(){
    int n; cin >> n;
    long long s = 0, x;
    for (int i = 0; i < n; i++) { cin >> x; if (x % 2 == 0) s += x; }
    cout << s << "\n";
}
