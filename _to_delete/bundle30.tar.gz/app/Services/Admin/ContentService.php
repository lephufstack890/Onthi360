<?php

namespace App\Services\Admin;

use App\Enums\AssessmentContentMode;
use App\Enums\AssessmentType;
use App\Enums\ContentStatus;
use App\Enums\OwnerType;
use App\Enums\UploadedDocumentStatus;
use App\Enums\Visibility;
use App\Models\Assessment;
use App\Models\AssessmentCodingItem;
use App\Models\Material;
use App\Models\Product;
use App\Models\Question;
use App\Models\QuestionBank;
use App\Models\UploadedDocument;
use App\Models\User;
use App\Repositories\Contracts\AssessmentRepositoryInterface;
use App\Repositories\Contracts\DraftQuestionRepositoryInterface;
use App\Repositories\Contracts\MaterialRepositoryInterface;
use App\Repositories\Contracts\ProductRepositoryInterface;
use App\Repositories\Contracts\QuestionRepositoryInterface;
use App\Repositories\Contracts\UploadedDocumentRepositoryInterface;
use App\Services\PdfAssessmentEditingService;
use App\Services\PdfAssessmentPublishGuard;
use App\Services\PdfBulkImportService;
use App\Services\QuestionPublishGuard;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Collection;
use Illuminate\Validation\ValidationException;

/**
 * Gom truy vấn/nhãn cho admin.content.* (ADM-03, 6.2/6.4/6.5).
 */
class ContentService
{
    public function __construct(
        private MaterialRepositoryInterface $materials,
        private QuestionRepositoryInterface $questions,
        private AssessmentRepositoryInterface $assessments,
        private DraftQuestionRepositoryInterface $draftQuestions,
        private ProductRepositoryInterface $products,
        private QuestionPublishGuard $publishGuard,
        private UploadedDocumentRepositoryInterface $uploadedDocuments,
        private PdfAssessmentPublishGuard $pdfAssessmentGuard,
        // SỬA 18/8 (2): logic soạn đề PDF (file/đáp án/bài lập trình con) chuyển hết sang
        // App\Services\PdfAssessmentEditingService — dùng CHUNG với Teacher\AssessmentService
        // (Giáo viên cũng tải đề PDF riêng, 16/8 mục 1.2) thay vì lặp lại ở 2 nơi.
        private PdfAssessmentEditingService $pdfEditing,
        // SỬA 19/8 (Giai đoạn 3 — "Bộ đề"): nhập hàng loạt nhiều đề PDF cùng lúc, dùng CHUNG
        // với Teacher\AssessmentService — xem App\Services\PdfBulkImportService.
        private PdfBulkImportService $pdfBulkImport,
    ) {}

    public static function maxPdfKb(): int
    {
        return PdfAssessmentEditingService::maxPdfKb();
    }

    public static function maxBulkSourcePdfKb(): int
    {
        return PdfBulkImportService::maxSourcePdfKb();
    }

    private const TYPE_LABELS = [
        'material' => 'Học liệu',
        'question' => 'Câu hỏi (kho chung)',
        'assessment' => 'Đề/bộ bài',
    ];

    /**
     * Kho câu hỏi chung dùng chung cho toàn hệ thống (6.5: "Kho chung: Editor/Admin/Super
     * Admin quản lý"). Tự tạo nếu chưa seed sẵn (môi trường mới/production chưa chạy
     * DemoDataSeeder) — không bắt admin phải tự quản lý khái niệm "bank" khi tạo câu hỏi.
     */
    private function sharedBank(): QuestionBank
    {
        return QuestionBank::firstOrCreate(
            ['owner_type' => OwnerType::Shared->value, 'name' => 'Kho chung'],
        );
    }

    private function statusLabel(ContentStatus $status): array
    {
        return match ($status) {
            ContentStatus::Draft => ['Nháp', 'neutral'],
            ContentStatus::PendingReview => ['Chờ duyệt', 'warning'],
            ContentStatus::Published => ['Phát hành', 'success'],
            ContentStatus::Archived => ['Lưu trữ', 'neutral'],
        };
    }

    /**
     * Tài liệu OCR đang chờ rà soát/xử lý — hiển thị ở tab "Câu hỏi chờ rà soát (OCR)"
     * (6.4). KHÔNG lọc theo người tải lên: tài liệu thuộc "Kho chung", cả nhóm
     * Admin/Editor cùng thấy và rà soát được (khác Teacher — nơi mỗi giáo viên chỉ
     * thấy tài liệu của chính mình).
     */
    private function pendingDocuments(): array
    {
        $statuses = [
            UploadedDocumentStatus::Uploaded,
            UploadedDocumentStatus::Scanning,
            UploadedDocumentStatus::QueuedOcr,
            UploadedDocumentStatus::Processing,
            UploadedDocumentStatus::NeedsReview,
            UploadedDocumentStatus::Failed,
        ];

        return $this->uploadedDocuments->query()
            ->whereIn('status', $statuses)
            ->with('uploader')
            ->latest()
            ->limit(20)
            ->get()
            ->map(function (UploadedDocument $doc) {
                [$label, $tone, $progress] = match ($doc->status) {
                    UploadedDocumentStatus::Uploaded => ['Đã tải lên — đang chờ quét', 'info', 10],
                    UploadedDocumentStatus::Scanning => ['Đang quét định dạng...', 'info', 25],
                    UploadedDocumentStatus::QueuedOcr => ['Trong hàng chờ OCR...', 'info', 40],
                    UploadedDocumentStatus::Processing => ['Đang trích xuất/OCR...', 'info', 70],
                    UploadedDocumentStatus::NeedsReview => ['Cần rà soát', 'warning', 100],
                    UploadedDocumentStatus::Failed => ['Xử lý lỗi', 'danger', 100],
                    default => ['Không rõ', 'neutral', 0],
                };

                return [
                    'id' => $doc->id,
                    'name' => $doc->original_filename,
                    'uploader' => $doc->uploader->name ?? '?',
                    'status' => $label,
                    'tone' => $tone,
                    'progress' => $progress,
                    'reviewable' => $doc->status === UploadedDocumentStatus::NeedsReview,
                    'errorLog' => $doc->status === UploadedDocumentStatus::Failed ? $doc->error_log : null,
                ];
            })->all();
    }

    /** @return array{tab: string, tabs: array, rows: array, total: int, documents: array} */
    public function indexData(string $tab): array
    {
        $counts = [
            'materials' => $this->materials->count(),
            'questions' => $this->questions->count(),
            'assessments' => $this->assessments->count(),
            'drafts' => $this->draftQuestions->countPendingReview(),
        ];

        $tabs = [
            ['label' => 'Học liệu (Sách/Chuyên đề/Đề thi)', 'href' => route('admin.content.index'), 'active' => $tab === 'materials', 'count' => $counts['materials']],
            ['label' => 'Câu hỏi (Kho chung + Giáo viên)', 'href' => route('admin.content.index', ['tab' => 'questions']), 'active' => $tab === 'questions', 'count' => $counts['questions']],
            ['label' => 'Đề/bộ bài', 'href' => route('admin.content.index', ['tab' => 'assessments']), 'active' => $tab === 'assessments', 'count' => $counts['assessments']],
            ['label' => 'Câu hỏi chờ rà soát (OCR)', 'href' => route('admin.content.index', ['tab' => 'drafts']), 'active' => $tab === 'drafts', 'count' => $counts['drafts']],
        ];

        $documents = [];
        $rows = [];
        if ($tab === 'questions') {
            // Admin xem được toàn bộ câu hỏi — cả Kho chung lẫn kho riêng từng giáo viên
            // (chỉ xem để nắm tình hình; ranh giới sở hữu/sửa vẫn theo 6.5, giống cách
            // tab "Đề/bộ bài" đã hiển thị cả đề của giáo viên bên dưới).
            $rows = $this->questions->allLatestWithOwner(50)->map(function ($q) {
                [$label, $tone] = $this->statusLabel($q->status);

                return ['id' => $q->id, 'title' => $q->title, 'type' => $q->type->value, 'status' => $label, 'tone' => $tone, 'owner' => $q->owner_type === OwnerType::Shared ? 'Kho chung' : ('GV '.($q->owner->name ?? ''))];
            })->all();
        } elseif ($tab === 'assessments') {
            $rows = $this->assessments->latestWithCreator(50)->map(function ($a) {
                [$label, $tone] = $this->statusLabel($a->status);
                $isTeacherOwned = $a->owner_type !== OwnerType::Shared;

                return [
                    'id' => $a->id, 'title' => $a->title, 'type' => $a->type->value, 'status' => $label, 'tone' => $tone,
                    'owner' => $isTeacherOwned ? 'GV '.($a->creator->name ?? '') : 'Kho chung',
                    // SỬA 19/8 (Giai đoạn 4 — "Admin duyệt đưa đề GV ra kho chung"): chỉ đề
                    // của giáo viên mới cần nút duyệt — đề đã ở Kho chung thì không có gì để
                    // duyệt thêm (xem assessmentPromoteToShared() bên dưới + nút bấm ở
                    // admin/content/index.blade.php).
                    'canPromoteToShared' => $isTeacherOwned,
                ];
            })->all();
        } elseif ($tab === 'drafts') {
            $documents = $this->pendingDocuments();
        } else {
            $rows = $this->materials->latestWithProduct(50)->map(function ($m) {
                [$label, $tone] = $this->statusLabel($m->status);

                return ['id' => $m->id, 'title' => $m->title, 'type' => $m->type, 'status' => $label, 'tone' => $tone, 'owner' => $m->product?->owner_type === OwnerType::Teacher ? 'Giáo viên' : 'Kho chung'];
            })->all();
        }

        return [
            'tab' => $tab,
            'tabs' => $tabs,
            'rows' => $rows,
            'documents' => $documents,
            'total' => $tab === 'drafts' ? count($documents) : ($counts[$tab] ?? count($rows)),
        ];
    }

    /**
     * admin.content.questions.reviewDraft — nhận ?document=<id>; nếu không có thì lấy
     * tài liệu "cần rà soát" gần nhất TRÊN TOÀN "Kho chung" (không giới hạn theo người
     * tải lên — khác Teacher). Trả đủ dữ liệu để màn rà soát sửa/gộp/xóa/thêm tay và
     * chuyển vào Kho chung.
     */
    public function reviewDraftFor(?int $documentId): array
    {
        $document = null;
        if ($documentId !== null) {
            $document = $this->uploadedDocuments->query()->find($documentId);
        }
        $document ??= $this->uploadedDocuments->query()
            ->where('status', UploadedDocumentStatus::NeedsReview)
            ->latest()
            ->first();

        $drafts = [];
        if ($document) {
            $allDrafts = $document->draftQuestions()->where('review_status', '!=', 'discarded')->orderBy('order')->get();

            $drafts = $allDrafts->values()->map(function ($d) use ($allDrafts) {
                $confidenceLabel = match ($d->confidence) {
                    'high' => 'Cao',
                    'medium' => 'Trung bình',
                    'low' => 'Thấp — cần kiểm tra kỹ',
                    default => 'Chưa rõ',
                };
                $tone = match ($d->confidence) {
                    'high' => 'success',
                    'medium' => 'warning',
                    'low' => 'danger',
                    default => 'neutral',
                };

                $s = $d->structured_draft ?? [];
                $type = $d->type_guess instanceof \App\Enums\QuestionType ? $d->type_guess->value : $d->type_guess;

                return [
                    'id' => $d->id,
                    'no' => $d->order + 1,
                    'type' => $type,
                    'confidence' => $confidenceLabel,
                    'tone' => $tone,
                    'flagged' => $d->needsManualReview(),
                    'promoted' => $d->promoted_question_id !== null,
                    'title' => $s['title'] ?? ($d->raw_text ? mb_substr($d->raw_text, 0, 160) : '(chưa có nội dung)'),
                    'body' => $s['body'] ?? $d->raw_text ?? '',
                    'points' => $s['points'] ?? 1,
                    'options' => $s['options'] ?? ['', '', '', ''],
                    'correctOption' => $s['correct_option'] ?? null,
                    'acceptedAnswers' => $s['accepted_answers'] ?? '',
                    'caseSensitive' => $s['case_sensitive'] ?? false,
                    'testCases' => $s['test_cases'] ?? '',
                    'timeLimitMs' => $s['time_limit_ms'] ?? 1000,
                    'memoryLimitMb' => $s['memory_limit_mb'] ?? 256,
                    'otherDrafts' => $allDrafts->reject(fn ($other) => $other->id === $d->id || $other->promoted_question_id !== null)
                        ->map(fn ($other) => ['id' => $other->id, 'label' => 'Câu '.($other->order + 1)])
                        ->values()->all(),
                ];
            })->all();
        }

        return ['document' => $document, 'drafts' => $drafts];
    }

    /**
     * admin.content.show dùng chung MỘT route cho cả 3 loại nội dung (Material/Question/
     * Assessment) — route chỉ nhận int $content, không có route-model-binding theo loại vì
     * mỗi tab ở admin.content.index đều trỏ "Xem" vào cùng route với id riêng của loại đó.
     * Ta không thể biết chắc id thuộc loại nào chỉ từ con số (hạn chế thiết kế route có sẵn,
     * không sửa route ở đây) nên tra cứu tuần tự Material -> Question -> Assessment.
     *
     * QuestionPublishGuard::canPublish() chỉ áp dụng cho Question (6.2/6.4 quy định điều kiện
     * phát hành CÂU HỎI). Material và Assessment không đi qua guard này — không có quy tắc
     * publish tương ứng nào được đặc tả cho 2 loại đó, nên $publishErrors luôn ræủ ġ{ 2
     * nhánh đó thay vì ép một Material/Assessment qua guard nhận Question làm tham số.
     *
     * @return array{type: string, typeLabel: string, model: mixed, item: array, publishErrors: array, hasBeenAttempted: bool}
     */
    public function showData(int $id): array
    {
        $material = $this->materials->findWithProduct($id);
        if ($material !== null) {
            [$label, $tone] = $this->statusLabel($material->status);

            return [
                'type' => 'material',
                'typeLabel' => self::TYPE_LABELS['material'],
                'model' => $material,
                'item' => ['id' => $material->id, 'title' => $material->title, 'status' => $label, 'tone' => $tone, 'statusValue' => $material->status->value],
                'publishErrors' => [],
                'hasBeenAttempted' => false,
            ];
        }

        /** @var Question|null $question */
        $question = $this->questions->query()->with('bank')->find($id);
        if ($question !== null) {
            [$label, $tone] = $this->statusLabel($question->status);
            $decision = $this->publishGuard->canPublish($question);

            return [
                'type' => 'question',
                'typeLabel' => self::TYPE_LABELS['question'],
                'model' => $question,
                'item' => ['id' => $question->id, 'title' => $question->title, 'status' => $label, 'tone' => $tone, 'statusValue' => $question->status->value],
                'publishErrors' => $decision->allowed ? [] : [$decision->message ?? 'Chưa đủ điều kiện phát hành.'],
                'hasBeenAttempted' => $this->publishGuard->hasBeenAttempted($question),
            ];
        }

        // SỬA 18/8: thêm eager-load items.question — trước đây chỉ load 'creator', nên màn
        // show.blade.php không có gì để hiện danh sách câu hỏi trong đề (chỉ hiện được TODO).
        // SỬA 18/8 (2, đề PDF): thêm eager-load answerKeys/codingItems.testCases — chỉ có dữ
        // liệu khi content_mode = pdf_answer_sheet, rỗng (không lỗi) khi content_mode = structured.
        $assessment = $this->assessments->query()
            ->with(['creator', 'items.question', 'answerKeys', 'codingItems.testCases'])
            ->find($id);
        if ($assessment !== null) {
            [$label, $tone] = $this->statusLabel($assessment->status);

            $publishErrors = [];
            if ($assessment->isPdfMode()) {
                $decision = $this->pdfAssessmentGuard->canPublish($assessment);
                $publishErrors = $decision->allowed ? [] : [$decision->message ?? 'Chưa đủ điều kiện phát hành.'];
            }

            return [
                'type' => 'assessment',
                'typeLabel' => self::TYPE_LABELS['assessment'],
                'model' => $assessment,
                'item' => ['id' => $assessment->id, 'title' => $assessment->title, 'status' => $label, 'tone' => $tone, 'statusValue' => $assessment->status->value],
                'publishErrors' => $publishErrors,
                'hasBeenAttempted' => false,
            ];
        }

        return [
            'type' => null,
            'typeLabel' => '',
            'model' => null,
            'item' => ['id' => $id, 'title' => 'Không tìm thấy nội dung', 'status' => '', 'tone' => 'neutral', 'statusValue' => null],
            'publishErrors' => [],
            'hasBeenAttempted' => false,
        ];
    }

    // ================= Học liệu (Material) =================

    public function materialCreateFormData(): array
    {
        return [
            'products' => $this->products->query()->orderBy('title')->get(['id', 'title'])->all(),
            'parents' => $this->materials->query()->with('product')->orderBy('product_id')->orderBy('order')->get()
                ->map(fn ($m) => ['id' => $m->id, 'label' => ($m->product->title ?? '?').' › '.$m->title])->all(),
            'assessments' => $this->assessments->query()->orderBy('title')->get(['id', 'title'])->all(),
            'types' => ['chapter' => 'Chương', 'section' => 'Bài/Mục', 'assessment_ref' => 'Tham chiếu đề/bộ bài'],
            'statuses' => $this->statusOptions(),
        ];
    }

    public function materialStore(array $data): Material
    {
        return $this->materials->create([
            'product_id' => $data['product_id'],
            'parent_id' => $data['parent_id'] ?: null,
            'type' => $data['type'],
            'title' => $data['title'],
            'order' => $data['order'] ?? 0,
            'assessment_id' => $data['type'] === 'assessment_ref' ? ($data['assessment_id'] ?: null) : null,
            'status' => $data['status'],
        ]);
    }

    public function materialEditFormData(int $id): array
    {
        return array_merge($this->materialCreateFormData(), [
            'material' => $this->materials->query()->findOrFail($id),
        ]);
    }

    public function materialUpdate(Material $material, array $data): Material
    {
        return $this->materials->update($material, [
            'product_id' => $data['product_id'],
            'parent_id' => $data['parent_id'] ?: null,
            'type' => $data['type'],
            'title' => $data['title'],
            'order' => $data['order'] ?? 0,
            'assessment_id' => $data['type'] === 'assessment_ref' ? ($data['assessment_id'] ?: null) : null,
            'status' => $data['status'],
        ]);
    }

    /** Không có guard đặc thù cho Material (chỉ Question mới có điều kiện phát hành, 6.2). */
    public function materialPublish(Material $material): Material
    {
        return $this->materials->update($material, ['status' => ContentStatus::Published->value]);
    }

    /** Trả về nháp — PHẢI có lý do + audit log (10.4). */
    public function materialReject(Material $material, string $reason): Material
    {
        Material::$auditReason = $reason;
        $this->materials->update($material, ['status' => ContentStatus::Draft->value]);
        Material::$auditReason = null;

        return $material;
    }

    /** Lưu trữ — cách "gỡ khỏi lưu hành" cho nội dung (không có trạng thái xóa, Table 27). */
    public function materialArchive(Material $material, string $reason): Material
    {
        Material::$auditReason = $reason;
        $this->materials->update($material, ['status' => ContentStatus::Archived->value]);
        Material::$auditReason = null;

        return $material;
    }

    // ================= Câu hỏi kho chung (Question, 6.5) =================

    public function questionCreateFormData(): array
    {
        return [
            'types' => ['coding' => 'Lập trình (OJ)', 'mcq' => 'Trắc nghiệm', 'fill_blank' => 'Điền khuyết'],
            'visibilities' => ['public' => 'Công khai', 'private' => 'Riêng tư (nội bộ)'],
        ];
    }

    /**
     * admin.content.questions.store — luôn tạo vào "Kho chung" (owner_type=shared) vì admin
     * đang thao tác ở mục Nội dung CHUNG (6.5) — câu hỏi riêng của giáo viên được tạo ở
     * teacher.questions.create (owner_type=teacher), không đi qua đây.
     */
    public function questionStore(User $admin, array $data): Question
    {
        if ($this->questions->query()->where('code', $data['code'])->exists()) {
            throw ValidationException::withMessages(['code' => 'Mã câu hỏi này đã tồn tại, chọn mã khác.']);
        }

        return $this->questions->create([
            'bank_id' => $this->sharedBank()->id,
            'code' => $data['code'],
            'type' => $data['type'],
            'title' => $data['title'],
            'body' => $data['body'] ?? null,
            'points' => $data['points'] ?? 0,
            'grading_config' => $this->buildGradingConfig($data['type'], $data),
            'owner_type' => OwnerType::Shared->value,
            'owner_id' => null,
            'visibility' => $data['visibility'] ?? Visibility::Public->value,
            'status' => ContentStatus::Draft->value,
            'version' => 1,
            'created_by' => $admin->id,
        ]);
    }

    public function questionEditFormData(int $id): array
    {
        /** @var Question $question */
        $question = $this->questions->query()->findOrFail($id);

        return array_merge($this->questionCreateFormData(), [
            'question' => $question,
            'hasBeenAttempted' => $this->publishGuard->hasBeenAttempted($question),
        ]);
    }

    /**
     * admin.content.questions.update — CHẶN sửa âm thầm câu đã có người làm (6.2: "Câu hỏi
     * đã có người làm — sửa nội dung phải tạo phiên bản mới"). Admin phải dùng
     * questionCreateNewVersion() thay vì gọi hàm này khi $hasBeenAttempted = true.
     */
    public function questionUpdate(Question $question, array $data): Question
    {
        if ($this->publishGuard->hasBeenAttempted($question)) {
            throw ValidationException::withMessages([
                'code' => 'Câu hỏi này đã có học sinh làm bài — không thể sửa trực tiếp, hãy dùng "Tạo phiên bản mới" (6.2).',
            ]);
        }

        return $this->questions->update($question, [
            'code' => $data['code'],
            'title' => $data['title'],
            'body' => $data['body'] ?? null,
            'points' => $data['points'] ?? 0,
            'grading_config' => $this->buildGradingConfig($question->type->value, $data),
            'visibility' => $data['visibility'] ?? Visibility::Public->value,
        ]);
    }

    /** Tạo bản version mới thay vì sửa âm thầm (6.2) — dùng khi câu đã có người làm. */
    public function questionCreateNewVersion(Question $question, array $data): Question
    {
        return $this->publishGuard->createNewVersion($question, [
            'title' => $data['title'],
            'body' => $data['body'] ?? null,
            'points' => $data['points'] ?? 0,
            'grading_config' => $this->buildGradingConfig($question->type->value, $data),
            'visibility' => $data['visibility'] ?? Visibility::Public->value,
        ]);
    }

    /**
     * Dựng grading_config đúng cấu trúc tối thiểu theo từng loại câu (6.1/6.2) từ input có
     * cấu trúc trên form — KHÔNG bắt admin tự viết JSON tay (dễ sai, khó kiểm tra lỗi rõ).
     * Test case coding dùng định dạng đơn giản "input|||output" mỗi dòng — cố ý CHƯA làm
     * trình tải file test/kéo-thả (phạm vi lớn hơn nhiều, để dành cho màn hình OJ chuyên biệt
     * sau này) — vẫn đủ để QuestionPublishGuard::hasMinimumGradingConfig() nhận đúng cấu trúc.
     */
    private function buildGradingConfig(string $type, array $data): array
    {
        return match ($type) {
            'mcq' => [
                'options' => array_values(array_filter($data['options'] ?? [], fn ($o) => filled($o))),
                'correct_options' => isset($data['correct_option']) && $data['correct_option'] !== ''
                    ? [(int) $data['correct_option']]
                    : [],
            ],
            'fill_blank' => [
                'accepted_answers' => array_values(array_filter(
                    array_map('trim', preg_split('/\r?\n|,/', (string) ($data['accepted_answers'] ?? ''))),
                    fn ($a) => $a !== ''
                )),
                'case_sensitive' => (bool) ($data['case_sensitive'] ?? false),
            ],
            'coding' => [
                'test_cases' => $this->parseTestCases($data['test_cases_raw'] ?? ''),
                'time_limit_ms' => filled($data['time_limit_ms'] ?? null) ? (int) $data['time_limit_ms'] : null,
                'memory_limit_mb' => filled($data['memory_limit_mb'] ?? null) ? (int) $data['memory_limit_mb'] : null,
            ],
            default => [],
        };
    }

    /** Mỗi dòng "input|||output" -> 1 test case. Dòng không đúng định dạng bị b�o qua. */
    private function parseTestCases(string $raw): array
    {
        $cases = [];
        foreach (preg_split('/\r?\n/', trim($raw)) as $line) {
            if (blank($line) || ! str_contains($line, '|||')) {
                continue;
            }
            [$input, $output] = explode('|||', $line, 2);
            $cases[] = ['input' => $input, 'output' => $output];
        }

        return $cases;
    }

    /** Phát hành — PHẢI qua QuestionPublishGuard (6.2/6.4), không có ngoại lệ cho admin. */
    public function questionPublish(Question $question): array
    {
        $decision = $this->publishGuard->canPublish($question);
        if (! $decision->allowed) {
            return ['ok' => false, 'message' => $decision->message ?? 'Chưa đủ điều kiện phát hành.'];
        }

        $this->questions->update($question, ['status' => ContentStatus::Published->value]);

        return ['ok' => true, 'message' => null];
    }

    /** Trả về nháp — PHẢI có lý do + audit log (10.4). Auditable đã gắn sẵn ở Question model. */
    public function questionReject(Question $question, string $reason): Question
    {
        Question::$auditReason = $reason;
        $this->questions->update($question, ['status' => ContentStatus::Draft->value]);
        Question::$auditReason = null;

        return $question;
    }

    public function questionArchive(Question $question, string $reason): Question
    {
        Question::$auditReason = $reason;
        $this->questions->update($question, ['status' => ContentStatus::Archived->value]);
        Question::$auditReason = null;

        return $question;
    }

    // ================= Đề/bộ bài (Assessment) =================
    // SỬA 18/8: trước đây phạm vi cố ý chỉ giới hạn ở metadata, với giả định "gắn/gỡ câu hỏi
    // vào đề là luồng riêng của giáo viên khi soạn đề (TEA-xx)" — nhưng giả định đó SAI với
    // đề do chính ADMIN tạo (owner_type=shared, vd "Đề thi quốc gia", "Đề thi cuộc thi"):
    // không giáo viên nào sở hữu đề này để vào teacher.assessments.create sửa cả (màn đó chỉ
    // cho giáo viên soạn đề CỦA CHÍNH HỌ, không có màn sửa lại đề đã tạo), nên loại đề admin tự
    // tạo trước giờ không cách nào gắn câu hỏi được (để lại đúng 1 dòng TODO chết ở
    // admin.content.show). Thêm assessmentItemsFormData()/assessmentItemsUpdate() bên dưới để
    // bù đúng khoảng trống đó — CHỈ áp dụng cho đề admin tự quản (không đụng vào luồng soạn đề
    // riêng của giáo viên, vẫn giữ nguyên như cũ).

    public function assessmentCreateFormData(): array
    {
        return [
            'types' => [
                'practice' => 'Luyện tập', 'assignment' => 'Bài giao', 'exam' => 'Đề thi', 'competition_paper' => 'Đề thi đấu',
            ],
            'publishAnswerRules' => [
                'never' => 'Không bao giờ hiện đáp án', 'after_deadline' => 'Hiện sau hạn nộp', 'immediately' => 'Hiện ngay sau khi nộp',
            ],
        ];
    }

    /**
     * SỬA 18/8 (đề PDF, theo file khách chốt "chốt chức năng đề luyện tập tài liệu" mục
     * 1.1/1.2): content_mode do HỆ THỐNG tự suy ra từ type, KHÔNG cho admin tự chọn — chỉ
     * "Luyện tập" (practice) mới dùng câu hỏi rời (structured); Bài giao/Đề thi/Đề thi đấu
     * đều bắt buộc dùng PDF + phiếu đáp án. Xem App\Enums\AssessmentContentMode.
     */
    private function contentModeForType(string $type): string
    {
        return $type === AssessmentType::Practice->value
            ? AssessmentContentMode::Structured->value
            : AssessmentContentMode::PdfAnswerSheet->value;
    }

    public function assessmentStore(User $admin, array $data): Assessment
    {
        return $this->assessments->create([
            'title' => $data['title'],
            'type' => $data['type'],
            'content_mode' => $this->contentModeForType($data['type']),
            'total_points' => $data['total_points'] ?? 0,
            'duration_minutes' => $data['duration_minutes'] ?: null,
            'publish_answer_rule' => $data['publish_answer_rule'] ?? 'never',
            'status' => ContentStatus::Draft->value,
            'version' => 1,
            'owner_type' => OwnerType::Shared->value,
            'owner_id' => null,
            'created_by' => $admin->id,
        ]);
    }

    public function assessmentEditFormData(int $id): array
    {
        return array_merge($this->assessmentCreateFormData(), [
            'assessment' => $this->assessments->query()->findOrFail($id),
        ]);
    }

    /**
     * admin.content.assessments.items.edit — dữ liệu cho màn chọn câu hỏi. Admin xem/chọn
     * được TOÀN BỘ câu hỏi (Kho chung + kho riêng từng giáo viên — allLatestWithOwner() đã
     * có sẵn, dùng lại đúng chỗ tab "Câu hỏi" ở admin.content.index đang dùng, xem
     * indexData()), không giới hạn theo 1 giáo viên như teacher.assessments.create.
     */
    public function assessmentItemsFormData(Assessment $assessment): array
    {
        $assessment->load('items.question');
        $existingItems = $assessment->items->keyBy('question_id');

        return [
            'assessment' => $assessment,
            'questions' => $this->questions->allLatestWithOwner(200)->map(fn (Question $q) => [
                'id' => $q->id,
                'title' => $q->title,
                'type' => $q->type->value,
                'points' => $q->points,
                'status' => $q->status->value,
                'ownerLabel' => $q->owner_type === OwnerType::Shared ? 'Kho chung' : ('GV '.($q->owner->name ?? '')),
            ])->all(),
            'selectedIds' => $existingItems->keys()->all(),
            'pointsOverrides' => $existingItems->map(fn ($item) => $item->points_override)->filter()->all(),
        ];
    }

    /**
     * admin.content.assessments.items.update — thay TOÀN BỘ danh sách câu hỏi trong đề bằng
     * danh sách mới chọn (xoá hết item cũ rồi tạo lại theo đúng thứ tự tick trên form — đơn
     * giản, đủ dùng cho phạm vi này, giống cách teacher.assessments.store xử lý lúc tạo mới).
     * Tự tính lại total_points = tổng điểm từng câu (ưu tiên points_override nếu có nhập).
     */
    public function assessmentItemsUpdate(Assessment $assessment, array $data): Assessment
    {
        $questionIds = $data['question_ids'];
        $pointsOverride = $data['points_override'] ?? [];

        $validQuestions = $this->questions->query()->whereIn('id', $questionIds)->get()->keyBy('id');

        $assessment->items()->delete();

        $totalPoints = 0;
        foreach (array_values($questionIds) as $order => $questionId) {
            $question = $validQuestions->get($questionId);
            if ($question === null) {
                continue;
            }

            $override = $pointsOverride[$questionId] ?? null;
            $points = filled($override) ? (int) $override : $question->points;

            $assessment->items()->create([
                'question_id' => $question->id,
                'order' => $order,
                'points_override' => filled($override) ? $points : null,
            ]);

            $totalPoints += $points;
        }

        return $this->assessments->update($assessment, ['total_points' => $totalPoints]);
    }

    public function assessmentUpdate(Assessment $assessment, array $data): Assessment
    {
        return $this->assessments->update($assessment, [
            'title' => $data['title'],
            'type' => $data['type'],
            'content_mode' => $this->contentModeForType($data['type']),
            'total_points' => $data['total_points'] ?? 0,
            'duration_minutes' => $data['duration_minutes'] ?: null,
            'publish_answer_rule' => $data['publish_answer_rule'] ?? 'never',
        ]);
    }

    /**
     * SỬA 18/8 (đề PDF): đề content_mode=pdf_answer_sheet PHẢI qua PdfAssessmentPublishGuard
     * trước khi phát hành (16/8 mục 5: "đề chưa hoàn thiện không bị lộ ra ngoài") — đề
     * content_mode=structured giữ nguyên hành vi cũ, không có guard (chưa có quy tắc nào
     * được đặc tả cho loại đó).
     *
     * @return array{ok: bool, message: ?string}
     */
    public function assessmentPublish(Assessment $assessment): array
    {
        if ($assessment->isPdfMode()) {
            $decision = $this->pdfAssessmentGuard->canPublish($assessment);
            if (! $decision->allowed) {
                return ['ok' => false, 'message' => $decision->message ?? 'Chưa đủ điều kiện phát hành.'];
            }
        }

        $this->assessments->update($assessment, ['status' => ContentStatus::Published->value]);

        return ['ok' => true, 'message' => null];
    }

    public function assessmentReject(Assessment $assessment, string $reason): Assessment
    {
        Assessment::$auditReason = $reason;
        $this->assessments->update($assessment, ['status' => ContentStatus::Draft->value]);
        Assessment::$auditReason = null;

        return $assessment;
    }

    public function assessmentArchive(Assessment $assessment, string $reason): Assessment
    {
        Assessment::$auditReason = $reason;
        $this->assessments->update($assessment, ['status' => ContentStatus::Archived->value]);
        Assessment::$auditReason = null;

        return $assessment;
    }

    /**
     * SỬA 19/8 (Giai đoạn 4 — "Admin duyệt đưa đề giáo viên tạo ra kho chung"): trước đây
     * KHÔNG có cơ chế nào để chuyển 1 đề do giáo viên tạo (owner_type=teacher) sang Kho chung
     * (owner_type=shared, owner_id=null) — mọi đề GV tạo mãi mãi thuộc riêng GV đó, kể cả khi
     * chất lượng tốt và Admin muốn dùng chung cho toàn hệ thống. Đây là hành động ĐƠN GIẢN,
     * chỉ đổi quyền sở hữu — KHÔNG đụng tới questions/materials/product đã gắn kèm (nếu có),
     * KHÔNG đổi status/version, và KHÔNG xoá created_by (giữ lại để vẫn biết đề này gốc do ai
     * tạo, hiển thị được ở nơi khác nếu cần — chỉ owner_type/owner_id đổi để đề hiện đúng
     * "Kho chung" ở tab Đề/bộ bài và các màn chọn đề dùng chung khác).
     *
     * Đề đã ở Kho chung rồi (owner_type=shared) thì không có gì để duyệt thêm — chặn sớm bằng
     * ValidationException thay vì âm thầm no-op, để controller trả lỗi rõ ràng nếu có ai bấm
     * nhầm/gọi thẳng route (vd 2 tab admin cùng mở, 1 tab đã duyệt xong trước).
     */
    public function assessmentPromoteToShared(Assessment $assessment): Assessment
    {
        if ($assessment->owner_type === OwnerType::Shared) {
            throw ValidationException::withMessages(['assessment' => 'Đề này đã ở Kho chung rồi, không cần duyệt thêm.']);
        }

        return $this->assessments->update($assessment, [
            'owner_type' => OwnerType::Shared->value,
            'owner_id' => null,
        ]);
    }

    // ================= "Bộ đề" — nhập hàng loạt nhiều đề PDF (Giai đoạn 3, 19/8) ==========
    // 2 cách, theo đúng lựa chọn của khách: (1) tách từ 1 file PDF lớn theo khoảng trang khai
    // sẵn, (2) tải nhiều file PDF riêng lẻ cùng lúc. Toàn bộ đề tạo ra đều content_mode=
    // pdf_answer_sheet, owner_type=shared (kho chung, giống assessmentStore() ở trên) — KHÔNG
    // có type "Luyện tập" (chỉ Luyện tập theo câu mới dùng structured, xem
    // AssessmentContentMode). Đáp án vẫn phải nhập tay sau đó ở màn "Quản lý đề PDF" — bulk chỉ
    // lo tạo khung đề + gắn đúng file PDF, không đọc/OCR nội dung.

    public function assessmentBulkCreateFormData(): array
    {
        return ['types' => $this->bulkTypeOptions()];
    }

    private function bulkTypeOptions(): array
    {
        return [
            AssessmentType::Assignment->value => 'Bài giao',
            AssessmentType::Exam->value => 'Đề thi',
            AssessmentType::CompetitionPaper->value => 'Đề thi đấu',
        ];
    }

    /** @param  array  $rows  @return Collection<int, Assessment> */
    public function assessmentBulkSplit(User $admin, UploadedFile $sourcePdf, array $rows): Collection
    {
        return $this->pdfBulkImport->splitIntoAssessments($admin, OwnerType::Shared, null, $sourcePdf, $rows);
    }

    /**
     * @param  array<int, UploadedFile>  $files
     * @param  array  $meta
     * @return Collection<int, Assessment>
     */
    public function assessmentBulkMulti(User $admin, array $files, array $meta): Collection
    {
        return $this->pdfBulkImport->createFromMultipleFiles($admin, OwnerType::Shared, null, $files, $meta);
    }

    // ================= Đề PDF + phiếu đáp án (16/8 mục 1.2/5/6) =================
    // SỬA 18/8: đề content_mode=pdf_answer_sheet KHÔNG dùng assessmentItemsFormData/Update ở
    // trên (đó là cho content_mode=structured — gắn Question thật vào assessment_items).
    // Đề PDF không có Question nào cả — chỉ có 1 file PDF + đáp án đúng từng câu
    // (AssessmentAnswerKey) và/hoặc bài lập trình con (AssessmentCodingItem).
    // SỬA 18/8 (2): toàn bộ xử lý thật đã chuyển sang App\Services\PdfAssessmentEditingService
    // (dùng chung với Teacher\AssessmentService) — các hàm dưới đây chỉ là lớp mỏng giữ
    // nguyên tên/route cũ cho AdminContentController, không đổi hành vi.

    /** admin.content.assessments.pdf.edit — dữ liệu màn cấu hình đề PDF. */
    public function assessmentPdfFormData(Assessment $assessment): array
    {
        return $this->pdfEditing->formData($assessment);
    }

    /** admin.content.assessments.pdf.update. @param  array  $answerKeyRows */
    public function assessmentPdfUpdate(
        Assessment $assessment,
        array $data,
        array $answerKeyRows,
        ?UploadedFile $pdf,
        ?UploadedFile $solutionPdf,
    ): Assessment {
        return $this->pdfEditing->update($assessment, $data, $answerKeyRows, $pdf, $solutionPdf);
    }

    /** admin.content.assessments.coding-items.store — thêm 1 bài lập trình con vào đề PDF. */
    public function codingItemStore(Assessment $assessment, array $data): AssessmentCodingItem
    {
        return $this->pdfEditing->codingItemStore($assessment, $data);
    }

    public function codingItemUpdate(AssessmentCodingItem $item, array $data): AssessmentCodingItem
    {
        return $this->pdfEditing->codingItemUpdate($item, $data);
    }

    public function codingItemDestroy(AssessmentCodingItem $item): void
    {
        $this->pdfEditing->codingItemDestroy($item);
    }

    /** admin.content.assessments.coding-items.test-cases.import — tải 1 gói ZIP input/output. */
    public function codingItemImportTestCasesZip(AssessmentCodingItem $item, UploadedFile $zip): int
    {
        return $this->pdfEditing->codingItemImportTestCasesZip($item, $zip);
    }

    /** @return array<string, string> */
    private function statusOptions(): array
    {
        return [
            ContentStatus::Draft->value => 'Nháp',
            ContentStatus::PendingReview->value => 'Chờ duyệt',
            ContentStatus::Published->value => 'Phát hành',
            ContentStatus::Archived->value => 'Lưu trữ',
        ];
    }

}
