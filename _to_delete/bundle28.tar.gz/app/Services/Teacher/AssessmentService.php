<?php

namespace App\Services\Teacher;

use App\Enums\AssessmentContentMode;
use App\Enums\AssessmentType;
use App\Enums\AssignmentStatus;
use App\Enums\ContentStatus;
use App\Enums\OwnerType;
use App\Enums\PublishAnswerRule;
use App\Enums\QuestionType;
use App\Enums\UploadedDocumentStatus;
use App\Models\Assessment;
use App\Models\AssessmentCodingItem;
use App\Models\Assignment;
use App\Models\UploadedDocument;
use App\Models\User;
use App\Repositories\Contracts\AssessmentRepositoryInterface;
use App\Repositories\Contracts\AssignmentRepositoryInterface;
use App\Repositories\Contracts\QuestionRepositoryInterface;
use App\Repositories\Contracts\UploadedDocumentRepositoryInterface;
use App\Services\PdfAssessmentEditingService;
use App\Services\PdfAssessmentPublishGuard;
use App\Services\PdfBulkImportService;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Validation\ValidationException;

/** Tổng hợp dữ liệu cho teacher.assessments.* (TEA-04/05, 6.3/6.4/8.4). */
class AssessmentService
{
    public function __construct(
        private readonly UploadedDocumentRepositoryInterface $uploadedDocuments,
        private readonly AssessmentRepositoryInterface $assessments,
        private readonly QuestionRepositoryInterface $questions,
        private readonly AssignmentRepositoryInterface $assignments,
        // SỬA 18/8 (đề PDF, 16/8 mục 1.2: "Đề thi lẻ được Admin HOẶC GIÁO VIÊN tải lên") —
        // giáo viên soạn đề PDF riêng của mình qua đúng logic dùng chung với Admin (xem
        // App\Services\PdfAssessmentEditingService); privacy = owner_type/owner_id như
        // Question riêng của giáo viên đã có, KHÔNG cần cột visibility mới cho Assessment.
        private readonly PdfAssessmentEditingService $pdfEditing,
        private readonly PdfAssessmentPublishGuard $pdfPublishGuard,
        // SỬA 19/8 (Giai đoạn 3 — "Bộ đề"): nhập hàng loạt nhiều đề PDF cùng lúc, dùng CHUNG
        // với Admin\ContentService — xem App\Services\PdfBulkImportService.
        private readonly PdfBulkImportService $pdfBulkImport,
    ) {}

    /** teacher.assessments.import — trạng thái xử lý thật, kể cả tệp lỗi (6.4). */
    public function importStatusFor(User $user): array
    {
        $statuses = [
            UploadedDocumentStatus::Uploaded,
            UploadedDocumentStatus::Scanning,
            UploadedDocumentStatus::QueuedOcr,
            UploadedDocumentStatus::Processing,
            UploadedDocumentStatus::NeedsReview,
            UploadedDocumentStatus::Failed,
        ];

        $processingFiles = $this->uploadedDocuments->forUploaderInStatuses($user->id, $statuses, 20)
            ->map(function (UploadedDocument $doc) {
                [$label, $tone, $progress] = match ($doc->status) {
                    UploadedDocumentStatus::Uploaded => ['Đã tải lên — đang chờ quét', 'info', 10],
                    UploadedDocumentStatus::Scanning => ['Đang quét định dạng...', 'info', 25],
                    UploadedDocumentStatus::QueuedOcr => ['Trong hàng chờ OCR...', 'info', 40],
                    UploadedDocumentStatus::Processing => ['Đang trích xuất/OCR...', 'info', 70],
                    UploadedDocumentStatus::NeedsReview => ['Cần rà soát', 'warning', 100],
                    UploadedDocumentStatus::Failed => ['Xử lý lỗi', 'danger', 100],
                    default => ['Không rõ', 'neutral', 0],
                };

                return [
                    'id' => $doc->id,
                    'name' => $doc->original_filename,
                    'status' => $label,
                    'tone' => $tone,
                    'progress' => $progress,
                    'errorLog' => $doc->status === UploadedDocumentStatus::Failed ? $doc->error_log : null,
                ];
            })->all();

        return ['processingFiles' => $processingFiles];
    }

    /**
     * teacher.assessments.reviewDraft — rà soát; nhận ?document=<id>, nếu không có thì lấy
     * tài liệu "cần rà soát" gần nhất của giáo viên (6.4). Trả đủ dữ liệu để màn rà soát
     * sửa/gộp/xóa/thêm tay và chuyển vào kho — không chỉ hiển thị đọc.
     */
    public function reviewDraftFor(User $user, ?int $documentId): array
    {
        $document = null;
        if ($documentId !== null) {
            $document = $this->uploadedDocuments->findForUploader($user->id, $documentId);
        }
        $document ??= $this->uploadedDocuments->latestNeedsReviewForUploader($user->id);

        $drafts = [];
        if ($document) {
            $allDrafts = $document->draftQuestions()->where('review_status', '!=', 'discarded')->orderBy('order')->get();

            $drafts = $allDrafts->values()->map(function ($d) use ($allDrafts) {
                $confidenceLabel = match ($d->confidence) {
                    'high' => 'Cao',
                    'medium' => 'Trung bình',
                    'low' => 'Thấp — cần kiểm tra kỹ',
                    default => 'Chưa rõ',
                };
                $tone = match ($d->confidence) {
                    'high' => 'success',
                    'medium' => 'warning',
                    'low' => 'danger',
                    default => 'neutral',
                };

                $s = $d->structured_draft ?? [];
                $type = $d->type_guess instanceof QuestionType ? $d->type_guess->value : $d->type_guess;

                return [
                    'id' => $d->id,
                    'no' => $d->order + 1,
                    'type' => $type,
                    'confidence' => $confidenceLabel,
                    'tone' => $tone,
                    'flagged' => $d->needsManualReview(),
                    'promoted' => $d->promoted_question_id !== null,
                    'title' => $s['title'] ?? ($d->raw_text ? mb_substr($d->raw_text, 0, 160) : '(chưa có nội dung)'),
                    'body' => $s['body'] ?? $d->raw_text ?? '',
                    'points' => $s['points'] ?? 1,
                    'options' => $s['options'] ?? ['', '', '', ''],
                    'correctOption' => $s['correct_option'] ?? null,
                    'acceptedAnswers' => $s['accepted_answers'] ?? '',
                    'caseSensitive' => $s['case_sensitive'] ?? false,
                    'testCases' => $s['test_cases'] ?? '',
                    'timeLimitMs' => $s['time_limit_ms'] ?? 1000,
                    'memoryLimitMb' => $s['memory_limit_mb'] ?? 256,
                    'otherDrafts' => $allDrafts->reject(fn ($other) => $other->id === $d->id || $other->promoted_question_id !== null)
                        ->map(fn ($other) => ['id' => $other->id, 'label' => 'Câu '.($other->order + 1)])
                        ->values()->all(),
                ];
            })->all();
        }

        return ['document' => $document, 'drafts' => $drafts];
    }

    /** teacher.assessments.index — đề do chính giáo viên tạo trong kho riêng (6.3, 8.4). */
    public function listForTeacher(User $teacher): array
    {
        $assessments = $this->assessments->byOwner($teacher->id, 100)
            ->map(fn (Assessment $a) => [
                'id' => $a->id,
                'title' => $a->title,
                'itemsCount' => $a->items_count,
                'assignmentsCount' => $a->assignments_count,
                'totalPoints' => $a->total_points,
                'status' => match ($a->status) {
                    ContentStatus::Published => 'Đã phát hành',
                    ContentStatus::Archived => 'Lưu trữ',
                    default => 'Nháp',
                },
                'tone' => match ($a->status) {
                    ContentStatus::Published => 'success',
                    ContentStatus::Archived => 'neutral',
                    default => 'warning',
                },
                'canPublish' => $a->status === ContentStatus::Draft,
            ])->all();

        $classRooms = $teacher->classRoomsTeaching()->get(['class_rooms.id', 'class_rooms.name'])->all();

        return ['assessments' => $assessments, 'classRooms' => $classRooms];
    }

    /** teacher.assessments.create — chọn câu từ kho riêng + lớp đang phụ trách (6.3, 8.4). */
    public function createFormData(User $teacher): array
    {
        $questions = $this->questions->byOwner($teacher->id, null, 200)
            ->map(fn ($q) => [
                'id' => $q->id,
                'title' => $q->title,
                'type' => $q->type->value,
                'points' => $q->points,
                'status' => $q->status->value,
            ])->all();

        $classRooms = $teacher->classRoomsTeaching()->get(['class_rooms.id', 'class_rooms.name'])->all();

        return ['questions' => $questions, 'classRooms' => $classRooms];
    }

    /**
     * teacher.assessments.store — tạo đề trộn nhiều kiểu câu (6.3), luôn bắt đầu "Nháp".
     * Chỉ nhận câu thuộc đúng kho riêng của giáo viên này (16 mục 3: không tin ID client gửi lên).
     *
     * @throws ValidationException nếu không chọn câu nào hoặc không câu nào hợp lệ.
     */
    public function store(User $teacher, array $data): Assessment
    {
        $questionIds = array_map('intval', $data['question_ids'] ?? []);
        $ownedQuestions = $this->questions->query()
            ->whereIn('id', $questionIds)
            ->where('owner_id', $teacher->id)
            ->where('owner_type', 'teacher')
            ->get()
            ->keyBy('id');

        $items = [];
        $totalPoints = 0;
        foreach ($questionIds as $order => $questionId) {
            $question = $ownedQuestions->get($questionId);
            if ($question === null) {
                continue;
            }
            $override = $data['points_override'][$questionId] ?? null;
            $points = filled($override) ? (int) $override : $question->points;
            $items[] = ['question_id' => $question->id, 'order' => $order, 'points_override' => filled($override) ? $points : null];
            $totalPoints += $points;
        }

        if ($items === []) {
            throw ValidationException::withMessages(['question_ids' => 'Chọn ít nhất 1 câu hợp lệ thuộc kho câu hỏi của bạn.']);
        }

        $assessment = $this->assessments->create([
            'title' => $data['title'],
            'type' => AssessmentType::Assignment,
            'total_points' => $totalPoints,
            'duration_minutes' => filled($data['duration_minutes'] ?? null) ? (int) $data['duration_minutes'] : null,
            'resubmission_policy' => filled($data['max_resubmissions'] ?? null) ? ['max_attempts' => (int) $data['max_resubmissions']] : null,
            'publish_answer_rule' => $data['publish_answer_rule'] ?? PublishAnswerRule::AfterDeadline->value,
            'status' => ContentStatus::Draft,
            'version' => 1,
            'owner_type' => OwnerType::Teacher,
            'owner_id' => $teacher->id,
            'created_by' => $teacher->id,
        ]);

        foreach ($items as $item) {
            $assessment->items()->create($item);
        }

        return $assessment;
    }

    /** Chỉ giáo viên sở hữu đề mới được xem/sửa/phát hành/giao (tương tự 6.5 áp cho kho riêng). */
    public function findOwned(User $teacher, int $id): Assessment
    {
        $assessment = $this->assessments->withItemsAndQuestions($id)
            ?? $this->assessments->findOrFail($id);

        abort_unless($assessment->owner_type === OwnerType::Teacher && (int) $assessment->owner_id === $teacher->id, 403);

        return $assessment;
    }

    /**
     * Điều kiện phát hành đề (6.2 áp dụng cho cấp đề): phải có câu, và MỌI câu trong đề
     * phải đã Published — không lộ câu nháp/thiếu cấu hình chấm cho học sinh.
     *
     * @return array{0: bool, 1: ?string}
     */
    public function canPublish(Assessment $assessment): array
    {
        $items = $assessment->items()->with('question')->get();

        if ($items->isEmpty()) {
            return [false, 'Đề chưa có câu nào.'];
        }

        $notPublished = $items->filter(fn ($item) => $item->question === null || $item->question->status !== ContentStatus::Published);

        if ($notPublished->isNotEmpty()) {
            return [false, 'Còn '.$notPublished->count().' câu trong đề chưa được phát hành ở Kho câu hỏi — phát hành từng câu trước (6.2).'];
        }

        return [true, null];
    }

    /**
     * SỬA 18/8 (đề PDF): đề content_mode=pdf_answer_sheet phát hành qua
     * PdfAssessmentPublishGuard (cùng điều kiện với Admin — 16/8 mục 5: "đề chưa hoàn thiện
     * không bị lộ ra ngoài"); đề content_mode=structured (luồng Bài giao cũ) giữ nguyên
     * canPublish() bên dưới, không đổi hành vi.
     *
     * @throws ValidationException nếu chưa đủ điều kiện.
     */
    public function publish(Assessment $assessment): Assessment
    {
        if ($assessment->isPdfMode()) {
            $decision = $this->pdfPublishGuard->canPublish($assessment);
            if (! $decision->allowed) {
                throw ValidationException::withMessages(['publish' => $decision->message ?? 'Chưa đủ điều kiện phát hành.']);
            }

            $assessment->update(['status' => ContentStatus::Published]);

            return $assessment;
        }

        [$ok, $reason] = $this->canPublish($assessment);

        if (! $ok) {
            throw ValidationException::withMessages(['publish' => $reason]);
        }

        $assessment->update(['status' => ContentStatus::Published]);

        return $assessment;
    }

    /**
     * teacher.assessments.assign — "Giao đề" (8.4): chọn đề, lớp, mốc thời gian, hướng dẫn,
     * quy tắc công bố. KHÔNG hỗ trợ ngoại lệ từng học sinh (8.4). Đề phải Published trước
     * khi giao — tự động phát hành nếu đủ điều kiện, ném lỗi cụ thể nếu chưa.
     *
     * shift_count (tùy chọn, > 1) — "chia ca thi" (note họp 13/8, mục 7: "Các kỳ thi nếu
     * đông quá thì mình chia thành các ca thi để chống tấn công ddos"): bắt buộc phải có
     * đủ cả opens_at và closes_at thì mới chia ca được (không có 2 mốc thì không biết chia
     * khung giờ nào) — xem App\Models\Assignment::shiftWindowFor().
     *
     * @throws ValidationException nếu đề chưa đủ điều kiện phát hành, lớp không hợp lệ,
     *                              hoặc yêu cầu chia ca nhưng thiếu mốc mở/đóng.
     */
    public function assignToClass(User $teacher, Assessment $assessment, array $data): Assignment
    {
        if ($assessment->status !== ContentStatus::Published) {
            $this->publish($assessment);
        }

        $classRoom = $teacher->classRoomsTeaching()->where('class_rooms.id', (int) $data['class_room_id'])->first();

        if ($classRoom === null) {
            throw ValidationException::withMessages(['class_room_id' => 'Bạn không phụ trách lớp này.']);
        }

        $opensAt = filled($data['opens_at'] ?? null) ? Carbon::parse($data['opens_at']) : null;
        $closesAt = filled($data['closes_at'] ?? null) ? Carbon::parse($data['closes_at']) : null;
        $dueAt = filled($data['due_at'] ?? null) ? Carbon::parse($data['due_at']) : $closesAt;

        $shiftCount = filled($data['shift_count'] ?? null) ? (int) $data['shift_count'] : null;
        if ($shiftCount !== null && $shiftCount > 1 && ($opensAt === null || $closesAt === null)) {
            throw ValidationException::withMessages([
                'shift_count' => 'Cần đặt đủ cả mốc Mở lúc và Đóng lúc thì mới chia ca thi được.',
            ]);
        }

        return $this->assignments->create([
            'class_room_id' => $classRoom->id,
            'assessment_id' => $assessment->id,
            'opens_at' => $opensAt,
            'closes_at' => $closesAt,
            'due_at' => $dueAt,
            'shift_count' => $shiftCount,
            'rules' => ['publish_answer_rule' => $assessment->publish_answer_rule->value],
            'instructions' => $data['instructions'] ?? null,
            'status' => $this->computeAssignmentStatus($opensAt, $closesAt)->value,
            'created_by' => $teacher->id,
        ]);
    }

    /** Trạng thái khởi tạo theo mốc thời gian (8.4: Nháp → Đã lên lịch → Đang mở → Đã đóng → Đã lưu trữ). */
    private function computeAssignmentStatus(?Carbon $opensAt, ?Carbon $closesAt): AssignmentStatus
    {
        if ($opensAt !== null && $opensAt->isFuture()) {
            return AssignmentStatus::Scheduled;
        }

        if ($closesAt !== null && $closesAt->isPast()) {
            return AssignmentStatus::Closed;
        }

        return AssignmentStatus::Open;
    }

    // ================= Đề thi lẻ (PDF) — 16/8 mục 1.2/2/5/6 =================
    // SỬA 18/8: khác HẲN luồng "Bài giao" cũ ở trên (store()/createFormData()/assignToClass()
    // — chọn Question rời, content_mode=structured, giữ NGUYÊN không đổi). Đề thi lẻ ở đây
    // LUÔN content_mode=pdf_answer_sheet, type Bài giao/Đề thi/Đề thi đấu (Luyện tập theo câu
    // không qua đây — vẫn dùng Question rời như cũ). "Đề giáo viên tạo mặc định riêng tư" =
    // owner_type=teacher/owner_id=$teacher->id (đúng quy ước privacy đã dùng cho Question
    // riêng của giáo viên, không thêm cột visibility mới). "Đưa ra kho chung thì Admin duyệt"
    // (đổi owner_type sang shared) CHƯA làm ở Giai đoạn 1 — để dành Giai đoạn 4/5 (quyền truy
    // cập + Bộ đề/Kỳ thi, đã báo trước với anh Phú 18/8).

    public function paperTypeOptions(): array
    {
        return [
            AssessmentType::Assignment->value => 'Bài giao',
            AssessmentType::Exam->value => 'Đề thi',
            AssessmentType::CompetitionPaper->value => 'Đề thi đấu',
        ];
    }

    /** teacher.papers.index — đề PDF riêng của giáo viên (khác teacher.assessments.index — Bài giao chọn câu rời, không đổi). */
    public function papersForTeacher(User $teacher): array
    {
        $papers = $this->assessments->query()
            ->where('owner_type', OwnerType::Teacher->value)
            ->where('owner_id', $teacher->id)
            ->where('content_mode', AssessmentContentMode::PdfAnswerSheet->value)
            ->withCount(['answerKeys', 'codingItems'])
            ->latest()
            ->get()
            ->map(fn (Assessment $a) => [
                'id' => $a->id,
                'title' => $a->title,
                'type' => $a->type->label(),
                'examCode' => $a->exam_code,
                'hasPdf' => filled($a->pdf_path),
                'answerKeysCount' => $a->answer_keys_count,
                'codingItemsCount' => $a->coding_items_count,
                'status' => match ($a->status) {
                    ContentStatus::Published => 'Đã phát hành',
                    ContentStatus::Archived => 'Lưu trữ',
                    default => 'Nháp',
                },
                'tone' => match ($a->status) {
                    ContentStatus::Published => 'success',
                    ContentStatus::Archived => 'neutral',
                    default => 'warning',
                },
                'canPublish' => $a->status === ContentStatus::Draft,
            ])->all();

        return ['papers' => $papers];
    }

    public function paperCreateFormData(): array
    {
        return ['types' => $this->paperTypeOptions()];
    }

    /** teacher.papers.store — tạo đề PDF trống (Nháp, riêng tư) — hoàn thiện PDF/đáp án ở màn "Quản lý đề PDF". */
    public function paperStore(User $teacher, array $data): Assessment
    {
        return $this->assessments->create([
            'title' => $data['title'],
            'type' => $data['type'],
            'content_mode' => AssessmentContentMode::PdfAnswerSheet->value,
            'total_points' => 0,
            'duration_minutes' => filled($data['duration_minutes'] ?? null) ? (int) $data['duration_minutes'] : null,
            'publish_answer_rule' => $data['publish_answer_rule'] ?? PublishAnswerRule::AfterDeadline->value,
            'status' => ContentStatus::Draft,
            'version' => 1,
            'owner_type' => OwnerType::Teacher,
            'owner_id' => $teacher->id,
            'created_by' => $teacher->id,
        ]);
    }

    public function paperPdfFormData(Assessment $assessment): array
    {
        return $this->pdfEditing->formData($assessment);
    }

    /** @param  array  $answerKeyRows */
    public function paperPdfUpdate(
        Assessment $assessment,
        array $data,
        array $answerKeyRows,
        ?UploadedFile $pdf,
        ?UploadedFile $solutionPdf,
    ): Assessment {
        return $this->pdfEditing->update($assessment, $data, $answerKeyRows, $pdf, $solutionPdf);
    }

    public function paperCodingItemStore(Assessment $assessment, array $data): AssessmentCodingItem
    {
        return $this->pdfEditing->codingItemStore($assessment, $data);
    }

    public function paperCodingItemUpdate(AssessmentCodingItem $item, array $data): AssessmentCodingItem
    {
        return $this->pdfEditing->codingItemUpdate($item, $data);
    }

    public function paperCodingItemDestroy(AssessmentCodingItem $item): void
    {
        $this->pdfEditing->codingItemDestroy($item);
    }

    public function paperCodingItemImportTestCasesZip(AssessmentCodingItem $item, UploadedFile $zip): int
    {
        return $this->pdfEditing->codingItemImportTestCasesZip($item, $zip);
    }

    /**
     * Xác nhận giáo viên sở hữu đề chứa bài lập trình con này — route
     * coding-items/{codingItem}/... không đi qua {assessment} nên phải tự kiểm tra lại đây
     * (16 mục 3: không tin ID client gửi lên), dùng lại đúng điều kiện findOwned() ở trên.
     */
    public function assertOwnsCodingItem(User $teacher, AssessmentCodingItem $item): void
    {
        $this->findOwned($teacher, $item->assessment_id);
    }

    // ================= "Bộ đề" — nhập hàng loạt nhiều đề PDF (Giai đoạn 3, 19/8) ==========
    // 2 cách, dùng CHUNG App\Services\PdfBulkImportService với Admin\ContentService (khác
    // owner_type=teacher/owner_id=$teacher->id thay vì shared) — mọi đề tạo ra đều riêng tư
    // của giáo viên này, giống paperStore() ở trên, cho tới khi Admin duyệt đưa ra kho chung
    // (chưa làm ở Giai đoạn này).

    public static function maxBulkSourcePdfKb(): int
    {
        return PdfBulkImportService::maxSourcePdfKb();
    }

    public function paperBulkCreateFormData(): array
    {
        return ['types' => $this->paperTypeOptions()];
    }

    /** @param  array  $rows  @return Collection<int, Assessment> */
    public function paperBulkSplit(User $teacher, UploadedFile $sourcePdf, array $rows): Collection
    {
        return $this->pdfBulkImport->splitIntoAssessments($teacher, OwnerType::Teacher, $teacher->id, $sourcePdf, $rows);
    }

    /**
     * @param  array<int, UploadedFile>  $files
     * @param  array  $meta
     * @return Collection<int, Assessment>
     */
    public function paperBulkMulti(User $teacher, array $files, array $meta): Collection
    {
        return $this->pdfBulkImport->createFromMultipleFiles($teacher, OwnerType::Teacher, $teacher->id, $files, $meta);
    }
}
