<?php

namespace App\Services\Public;

use App\Enums\CompetitionStatus;
use App\Models\Competition;
use App\Models\CompetitionExam;
use App\Models\Role;
use App\Models\User;
use App\Repositories\Contracts\CompetitionRepositoryInterface;
use Illuminate\Support\Carbon;

/**
 * Cuộc thi công khai (PUB-08, 11.1 "Menu Cuộc thi": lịch, thể lệ, đề/bộ bài, quy tắc công
 * bố, trạng thái Sắp diễn ra→Đang diễn ra→Chờ công bố→Đã công bố→Lưu trữ).
 */
class CompetitionService
{
    private const STATUS_META = [
        'upcoming' => ['label' => 'Sắp diễn ra', 'tone' => 'info'],
        'ongoing' => ['label' => 'Đang diễn ra', 'tone' => 'success'],
        'pending_publish' => ['label' => 'Chờ công bố', 'tone' => 'neutral'],
        'published' => ['label' => 'Đã công bố', 'tone' => 'neutral'],
        'archived' => ['label' => 'Lưu trữ', 'tone' => 'neutral'],
    ];

    public function __construct(private CompetitionRepositoryInterface $competitions) {}

    /** competitions.index — danh sách cuộc thi/khảo sát công khai. */
    public function indexData(): array
    {
        return [
            'competitions' => $this->competitions->withLeaderboardCounts(30)->map(fn ($c) => $this->mapCard($c))->all(),
        ];
    }

    /**
     * competitions.show — chi tiết cuộc thi thật + đề tham chiếu + đơn vị tổ chức/cố vấn
     * (note họp 13/8, mục 1) + CTA theo trạng thái/vai trò.
     */
    public function showData(int $competitionId, ?User $viewer): array
    {
        $competition = $this->competitions->query()
            ->with(['assessment', 'advisors', 'examSittings.assessment'])
            ->withCount('leaderboardEntries')
            ->findOrFail($competitionId);

        $meta = self::STATUS_META[$competition->status->value] ?? ['label' => $competition->status->value, 'tone' => 'neutral'];
        $countdown = $this->startCountdown($competition->starts_at);

        return [
            'competition' => $competition,
            'statusLabel' => $meta['label'],
            'statusTone' => $meta['tone'],
            'rankingRule' => $competition->ranking_rule ?? [],
            'daysUntilStart' => $countdown['value'],
            'daysUntilStartUnit' => $countdown['unit'],
            /*
             * "Vào thi" ở đây = làm đề tham chiếu thật (11.1: "cuộc thi chỉ tham chiếu đề để
             * tổ chức sự kiện") qua hạ tầng student.assessment.take sẵn có. Việc TỰ ĐỘNG ghi
             * nhận lượt làm bài này vào leaderboard_entries chưa được nối (cần sửa
             * AttemptService để biết attempt thuộc cuộc thi nào) — đây là phạm vi riêng, rộng
             * hơn việc dựng trang khám phá/chi tiết cuộc thi lần này nên chưa làm ở đây.
             *
             * status=ongoing hiện do Admin tự tay chuyển (không có job/scheduler tự đồng bộ
             * theo starts_at/ends_at) — thêm $isWithinWindow() làm lớp phòng vệ thứ 2: nếu
             * Admin quên chuyển trạng thái đúng lúc (quên mở, hoặc quên đóng sau khi hết
             * giờ), nút "Vào thi" vẫn không hiện sai ngoài khung thời gian thật. Cuộc thi
             * chưa đặt starts_at/ends_at (null) thì không bị chặn thêm — giữ đúng hành vi cũ
             * (chỉ dựa vào status) để không phá cuộc thi đã tạo trước khi có luật này.
             */
            'canJoinDirectly' => $viewer !== null
                && $viewer->hasRole(Role::STUDENT)
                && $competition->assessment_id !== null
                && $competition->status->value === 'ongoing'
                && $this->isWithinWindow($competition),
            /*
             * examSittings (App\Models\CompetitionExam) — 1 cuộc thi có thể gồm NHIỀU kỳ thi
             * (vd Vòng 1/Vòng 2), mỗi kỳ tham chiếu 1 đề riêng + có CTA/bảng xếp hạng riêng.
             * Cuộc thi cũ (tạo trước tính năng này) đã được backfill 1 kỳ thi tương ứng với
             * assessment_id cũ (xem migration create_competition_exams_table) nên luôn có ít
             * nhất 1 phần tử nếu Competition từng gắn đề — không cần fallback UI riêng ở view.
             */
            'examSittings' => $competition->examSittings->map(fn (CompetitionExam $exam) => [
                'id' => $exam->id,
                'title' => $exam->displayTitle(),
                'assessmentId' => $exam->assessment_id,
                'startsAt' => $exam->starts_at,
                'endsAt' => $exam->ends_at,
                'ongoing' => $exam->isOngoing(),
                'canJoinDirectly' => $viewer !== null
                    && $viewer->hasRole(Role::STUDENT)
                    && $exam->assessment_id !== null
                    && $competition->status->value === 'ongoing'
                    && $exam->isOngoing(),
            ])->all(),
        ];
    }

    /**
     * Trang chủ (PUB-01/02, 12.1) — "Cuộc thi sắp tới": CHỈ status=upcoming, xếp gần nhất
     * trước (starts_at TĂNG dần) — khác competitions.index vốn liệt kê MỌI trạng thái, mới
     * TẠO trước (starts_at GIẢM dần qua withLeaderboardCounts()). Không dùng
     * withLeaderboardCounts() ở đây vì cuộc thi sắp diễn ra chưa có lượt tham gia nào để đếm.
     */
    public function upcomingData(int $limit = 4): array
    {
        $competitions = $this->competitions->query()
            ->where('status', CompetitionStatus::Upcoming->value)
            ->orderBy('starts_at')
            ->limit($limit)
            ->get();

        return $competitions->map(fn (Competition $c) => $this->mapCard($c))->all();
    }

    /** now() có nằm trong [starts_at, ends_at] không — cột nào null thì bỏ qua điều kiện đó (không chặn thêm khi chưa đặt lịch cụ thể). */
    private function isWithinWindow(Competition $competition): bool
    {
        if ($competition->starts_at !== null && now()->lt($competition->starts_at)) {
            return false;
        }

        if ($competition->ends_at !== null && now()->gt($competition->ends_at)) {
            return false;
        }

        return true;
    }

    /**
     * "Còn bao lâu nữa bắt đầu" hiển thị cho người xem — CHỈ 1 đơn vị (ngày HOẶC giờ), luôn
     * là số nguyên dễ đọc. Carbon 3 (Laravel 13) trả về diffInDays()/diffInHours() dạng SỐ
     * THỰC có phần thập phân (vd còn ~2 tiếng ra "0.0858..." ngày) — hiển thị thẳng ra UI như
     * cũ vừa khó hiểu vừa trông như lỗi. Quy tắc: còn >= 1 ngày trọn thì hiện NGÀY (làm tròn
     * xuống — "còn ít nhất N ngày trọn"); dưới 1 ngày thì đổi sang hiện GIỜ (cũng làm tròn
     * xuống theo giờ trọn, tối thiểu 1 để không hiện "0 giờ nữa" khi thật ra vẫn còn vài phút
     * trước giờ bắt đầu). Đã bắt đầu/qua giờ hoặc chưa đặt lịch (null) → 0 ngày.
     *
     * @return array{value: int, unit: string} unit là "ngày" hoặc "giờ".
     */
    private function startCountdown(?Carbon $startsAt): array
    {
        if ($startsAt === null) {
            return ['value' => 0, 'unit' => 'ngày'];
        }

        // Carbon trả diffInMinutes() dạng float (có phần thập phân) — ép về int TRƯỚC khi
        // đưa vào intdiv() ở dưới, tránh PHP báo deprecation "implicit conversion from float
        // to int loses precision" mỗi lần gọi (gần như luôn có phần thập phân).
        $totalMinutes = (int) now()->diffInMinutes($startsAt, false);

        if ($totalMinutes <= 0) {
            return ['value' => 0, 'unit' => 'ngày'];
        }

        $days = intdiv($totalMinutes, 1440);

        if ($days >= 1) {
            return ['value' => $days, 'unit' => 'ngày'];
        }

        return ['value' => max(1, intdiv($totalMinutes, 60)), 'unit' => 'giờ'];
    }

    private function mapCard(Competition $c): array
    {
        $meta = self::STATUS_META[$c->status->value] ?? ['label' => $c->status->value, 'tone' => 'neutral'];

        return [
            'id' => $c->id,
            'title' => $c->title,
            'typeLabel' => $c->type->value === 'contest' ? 'Cuộc thi' : 'Khảo sát',
            'statusLabel' => $meta['label'],
            'statusTone' => $meta['tone'],
            'startsAt' => $c->starts_at,
            'endsAt' => $c->ends_at,
            'startCountdown' => $this->startCountdown($c->starts_at),
            'participants' => $c->leaderboard_entries_count,
        ];
    }
}
