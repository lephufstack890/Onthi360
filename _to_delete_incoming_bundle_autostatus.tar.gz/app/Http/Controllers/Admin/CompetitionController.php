<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Competition;
use App\Models\CompetitionExam;
use App\Services\Admin\CompetitionService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;

class CompetitionController extends Controller
{
    public function __construct(private CompetitionService $competitionService) {}

    /** admin.competitions.index (ADM-05) — 11.1: vòng đời cuộc thi. */
    public function index(Request $request): View
    {
        return view('admin.competitions.index', $this->competitionService->indexData());
    }

    private function validationRules(): array
    {
        return [
            'title' => ['required', 'string', 'max:255'],
            'type' => ['required', 'string', 'in:contest,survey'],
            'assessment_id' => ['nullable', 'integer', 'exists:assessments,id'],
            'rules' => ['nullable', 'string', 'max:5000'],
            'starts_at' => ['nullable', 'date'],
            'ends_at' => ['nullable', 'date'],
            'publish_result_at' => ['nullable', 'date'],
            // 'status' KHÔNG còn nhận từ form nữa — CompetitionService::store()/update() tự
            // tính theo giờ hiện tại (xem Competition::computeStatusFor()), chỉ "Lưu trữ" là
            // admin tự bấm qua route admin.competitions.archive riêng.
            'scoring_note' => ['nullable', 'string', 'max:500'],
            'penalty_note' => ['nullable', 'string', 'max:500'],
            'tie_break_note' => ['nullable', 'string', 'max:500'],
            'organizer_type' => ['required', 'string', 'in:internal,external'],
            'organizer_name' => ['nullable', 'string', 'max:255'],
            'advisor_teacher_ids' => ['nullable', 'array'],
            'advisor_teacher_ids.*' => ['integer', 'exists:users,id'],
        ];
    }

    /**
     * Form dùng 5 dropdown Ngày/Tháng/Năm/Giờ/Phút ("{field}_day/_month/_year/_hour/
     * _minute") thay HOÀN TOÀN cho <input type="datetime-local"|"date"|"time"> native (bị
     * phản ánh không bấm chọn được trên máy một số người dùng — xem
     * resources/views/components/date-time-fields.blade.php). Ghép lại thành 1 field gốc
     * "{field}" chuẩn "Y-m-d\TH:i" NGAY TRƯỚC KHI validate(), để validationRules()/
     * examValidationRules() và toàn bộ Service layer phía sau không phải đổi gì (vẫn nhận
     * đúng 1 field 'date' như cũ). Thiếu bất kỳ 1 trong 3 phần Ngày/Tháng/Năm → cả mốc
     * thời gian này thành null (giờ/phút luôn có mặc định 00:00 nếu bỏ trống).
     */
    private function combineDateTimeInputs(Request $request, array $fields): void
    {
        foreach ($fields as $field) {
            $day = trim((string) $request->input($field.'_day'));
            $month = trim((string) $request->input($field.'_month'));
            $year = trim((string) $request->input($field.'_year'));

            if ($day === '' || $month === '' || $year === '') {
                $request->merge([$field => null]);

                continue;
            }

            $day = str_pad($day, 2, '0', STR_PAD_LEFT);
            $month = str_pad($month, 2, '0', STR_PAD_LEFT);

            $hour = trim((string) $request->input($field.'_hour'));
            $minute = trim((string) $request->input($field.'_minute'));
            $hour = $hour !== '' ? str_pad($hour, 2, '0', STR_PAD_LEFT) : '00';
            $minute = $minute !== '' ? str_pad($minute, 2, '0', STR_PAD_LEFT) : '00';

            $request->merge([$field => "{$year}-{$month}-{$day}T{$hour}:{$minute}"]);
        }
    }

    public function create(): View
    {
        return view('admin.competitions.create', $this->competitionService->createFormData());
    }

    public function store(Request $request): RedirectResponse
    {
        $this->combineDateTimeInputs($request, ['starts_at', 'ends_at', 'publish_result_at']);
        $data = $request->validate($this->validationRules());

        try {
            $competition = $this->competitionService->store($data);
        } catch (ValidationException $e) {
            return redirect()->route('admin.competitions.create')->withErrors($e->errors())->withInput();
        }

        return redirect()->route('admin.competitions.show', $competition->id)->with('status', 'competition-created');
    }

    public function edit(int $competition): View
    {
        return view('admin.competitions.edit', $this->competitionService->editFormData($competition));
    }

    public function update(Request $request, Competition $competition): RedirectResponse
    {
        $this->combineDateTimeInputs($request, ['starts_at', 'ends_at', 'publish_result_at']);
        $data = $request->validate($this->validationRules());

        try {
            $this->competitionService->update($competition, $data);
        } catch (ValidationException $e) {
            return redirect()->route('admin.competitions.edit', $competition->id)->withErrors($e->errors())->withInput();
        }

        return redirect()->route('admin.competitions.show', $competition->id)->with('status', 'competition-updated');
    }

    /** admin.competitions.archive — không xóa mềm được (không có deleted_at), chỉ chuyển "Lưu trữ" (11.1). */
    public function archive(Request $request, Competition $competition): RedirectResponse
    {
        $this->competitionService->archive($competition);

        return redirect()->route('admin.competitions.index')->with('status', 'competition-archived');
    }

    public function show(Request $request, int $competition): View
    {
        return view('admin.competitions.show', $this->competitionService->showData($competition));
    }

    /** admin.competitions.exams.store — thêm 1 kỳ thi (vòng) mới vào cuộc thi. */
    public function examStore(Request $request, Competition $competition): RedirectResponse
    {
        $this->combineDateTimeInputs($request, ['starts_at', 'ends_at']);
        $data = $request->validate($this->competitionService->examValidationRules());

        try {
            $this->competitionService->storeExam($competition, $data);
        } catch (ValidationException $e) {
            return redirect()->route('admin.competitions.show', $competition->id)->withErrors($e->errors())->withInput();
        }

        return redirect()->route('admin.competitions.show', $competition->id)->with('status', 'exam-added');
    }

    /** admin.competitions.exams.update. */
    public function examUpdate(Request $request, CompetitionExam $competitionExam): RedirectResponse
    {
        $competitionId = $competitionExam->competition_id;

        $this->combineDateTimeInputs($request, ['starts_at', 'ends_at']);
        $data = $request->validate($this->competitionService->examValidationRules());

        try {
            $this->competitionService->updateExam($competitionExam, $data);
        } catch (ValidationException $e) {
            return redirect()->route('admin.competitions.show', $competitionId)->withErrors($e->errors())->withInput();
        }

        return redirect()->route('admin.competitions.show', $competitionId)->with('status', 'exam-updated');
    }

    /** admin.competitions.exams.destroy — chặn xoá nếu kỳ thi đã có lượt xếp hạng riêng. */
    public function examDestroy(Request $request, CompetitionExam $competitionExam): RedirectResponse
    {
        $competitionId = $competitionExam->competition_id;

        try {
            $this->competitionService->deleteExam($competitionExam);
        } catch (ValidationException $e) {
            return redirect()->route('admin.competitions.show', $competitionId)->withErrors($e->errors());
        }

        return redirect()->route('admin.competitions.show', $competitionId)->with('status', 'exam-deleted');
    }

    /** admin.competitions.recompute-aggregate — "Tính tổng từ các kỳ thi" (dual leaderboard). */
    public function recomputeAggregate(Request $request, Competition $competition): RedirectResponse
    {
        try {
            $this->competitionService->recomputeAggregateFromExams($competition);
        } catch (ValidationException $e) {
            return redirect()->route('admin.competitions.show', $competition->id)->withErrors($e->errors());
        }

        return redirect()->route('admin.competitions.show', $competition->id)->with('status', 'aggregate-recomputed');
    }
}
