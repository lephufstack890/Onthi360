{{--
  Route: student.schedule.index | Controller: App\Http\Controllers\Student\ScheduleController
  Service: App\Services\Student\ScheduleService::buildWeekData()

  Thời khoá biểu dạng lưới tuần (Thứ Hai → Chủ Nhật, mỗi cột có ngày cụ thể), GỘP buổi học
  của TẤT CẢ lớp học sinh đang tham gia — khác với tab "Lịch học" trong student.classes.show
  (chỉ hiển thị buổi học của MỘT lớp dạng danh sách phẳng).
--}}
@extends('layouts.student')

@section('title', 'Thời khoá biểu')
@section('page-title', 'Thời khoá biểu')

@section('content')
    @php
        $days = $days ?? [];
    @endphp

    <x-page-header title="Thời khoá biểu" subtitle="Lịch học gộp từ tất cả lớp bạn đang tham gia, xem theo tuần." />

    <div class="flex items-center justify-between gap-3 mb-4 flex-wrap">
        <div class="flex items-center gap-2">
            <a href="{{ route('student.schedule.index', ['week' => $weekOffset - 1]) }}"
               class="w-9 h-9 rounded-lg border border-slate-200 bg-white flex items-center justify-center text-slate-500 hover:bg-slate-50" aria-label="Tuần trước">‹</a>
            <p class="text-sm font-medium text-slate-700 min-w-[160px] text-center">
                {{ $weekStart->format('d/m') }} – {{ $weekEnd->format('d/m/Y') }}
            </p>
            <a href="{{ route('student.schedule.index', ['week' => $weekOffset + 1]) }}"
               class="w-9 h-9 rounded-lg border border-slate-200 bg-white flex items-center justify-center text-slate-500 hover:bg-slate-50" aria-label="Tuần sau">›</a>
        </div>
        @if ($weekOffset !== 0)
            <a href="{{ route('student.schedule.index') }}" class="text-sm text-rose-600 font-medium">Về tuần này</a>
        @endif
    </div>

    @if (! $hasAnyClass)
        <x-empty-state title="Bạn chưa tham gia lớp học nào"
                        description="Thời khoá biểu sẽ hiện ra khi bạn được ghi danh vào một lớp học."
                        actionLabel="Xem khóa học của tôi" :actionHref="route('student.courses.index')" />
    @else
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-7 gap-3">
            @foreach ($days as $day)
                <div class="rounded-2xl border p-3 min-h-[150px] {{ $day['isToday'] ? 'border-rose-300 bg-rose-50/40' : 'border-slate-200 bg-white' }}">
                    <div class="mb-2 flex items-center justify-between lg:block">
                        <p class="text-xs font-semibold uppercase tracking-wide {{ $day['isToday'] ? 'text-rose-600' : 'text-slate-500' }}">{{ $day['label'] }}</p>
                        <p class="text-sm font-medium text-slate-700">{{ $day['date']->format('d/m') }}</p>
                    </div>
                    <div class="space-y-2">
                        @forelse ($day['sessions'] as $s)
                            <div class="rounded-xl bg-slate-50 border border-slate-100 p-2.5">
                                <p class="text-xs font-semibold text-slate-700 truncate" title="{{ $s['className'] }}">{{ $s['className'] }}</p>
                                <p class="text-xs text-slate-500 mt-0.5 truncate" title="{{ $s['topic'] }}">{{ $s['topic'] ?? 'Buổi học' }}</p>
                                <p class="text-xs text-slate-400 mt-1">🕐 {{ $s['timeRangeLabel'] }}</p>
                                @if (! empty($s['location']))
                                    <p class="text-xs text-slate-400 truncate" title="{{ $s['location'] }}">📍 {{ $s['location'] }}</p>
                                @endif
                                <div class="flex flex-wrap items-center gap-1 mt-1.5">
                                    <x-status-badge :tone="$s['timeStatusTone']">{{ $s['timeStatusLabel'] }}</x-status-badge>
                                    <x-status-badge :tone="$s['attendanceTone']">{{ $s['attendanceLabel'] }}</x-status-badge>
                                </div>
                                <a href="{{ route('student.classes.show', ['class' => $s['classRoomId'], 'tab' => 'schedule']) }}"
                                   class="block text-xs text-rose-600 font-medium mt-1.5">Xem lớp ›</a>
                            </div>
                        @empty
                            <p class="text-xs text-slate-300 italic">Không có buổi học</p>
                        @endforelse
                    </div>
                </div>
            @endforeach
        </div>
    @endif
@endsection
